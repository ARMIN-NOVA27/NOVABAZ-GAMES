# Gaming Hub — پلتفرم گیمرهای فارسی

A full-featured Persian gaming hub with game catalog, gaming tools, articles, user accounts, and search.

## Tech Stack

- **Frontend:** React 18 + TypeScript + Vite
- **Styling:** Tailwind CSS (RTL, dark theme, Vazirmatn font)
- **Routing:** React Router DOM v7
- **Icons:** lucide-react
- **Backend:** Supabase (PostgreSQL + Auth + RLS)

## Prerequisites

- Node.js 18+
- A Supabase project (free tier works)

## Setup Instructions

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment Variables

Create a `.env` file in the project root:

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

Find these in your Supabase dashboard: **Project Settings → API**.

### 3. Apply Database Migration

The SQL migration is in `supabase/migrations/20260829051455_create_gaming_hub_schema.sql`.

**Option A — Supabase Dashboard (easiest):**
1. Go to your Supabase project → **SQL Editor**
2. Open the file `supabase/migrations/20260829051455_create_gaming_hub_schema.sql`
3. Copy its contents into the SQL Editor and click **Run**

**Option B — Supabase CLI:**
```bash
npx supabase db push
```

### 4. Seed Sample Data

After the migration, run the seed SQL to populate games and articles.

**In Supabase SQL Editor**, open and run `supabase/seed.sql`.

### 5. Start the Dev Server

```bash
npm run dev
```

The site will be available at `http://localhost:5173`.

### 6. Build for Production

```bash
npm run build
```

Output goes to `dist/`. Preview with:

```bash
npm run preview
```

## Project Structure

```
src/
├── components/        # Reusable UI components
│   ├── ArticleCard.tsx
│   ├── Footer.tsx
│   ├── GameCard.tsx
│   ├── Header.tsx
│   ├── Layout.tsx
│   ├── SectionHeading.tsx
│   └── ToolCard.tsx
├── lib/               # Utilities, data access, types
│   ├── auth.tsx       # Auth context provider
│   ├── bioData.ts     # Bio generator logic
│   ├── data.ts        # Supabase data access functions
│   ├── ideaData.ts    # Idea generator sample data
│   ├── nameData.ts    # Name generator logic
│   ├── supabase.ts    # Supabase client singleton
│   ├── tools.ts       # Tool metadata
│   ├── types.ts       # TypeScript interfaces
│   └── utils.ts       # Helpers (clipboard, formatting)
├── pages/             # Route pages
│   ├── tools/         # Individual tool pages
│   │   ├── BioGenerator.tsx
│   │   ├── DpiCalculator.tsx
│   │   ├── DownloadTime.tsx
│   │   ├── FpsConverter.tsx
│   │   ├── IdeaGenerator.tsx
│   │   ├── NameGenerator.tsx
│   │   ├── SystemCheck.tsx
│   │   └── UnitConverter.tsx
│   ├── ArticleDetail.tsx
│   ├── Articles.tsx
│   ├── Auth.tsx
│   ├── GameDetail.tsx
│   ├── Games.tsx
│   ├── Home.tsx
│   ├── NotFound.tsx
│   ├── Profile.tsx
│   ├── Search.tsx
│   ├── ToolDetail.tsx
│   └── Tools.tsx
├── App.tsx            # Router + routes
├── index.css          # Tailwind + RTL + font + animations
└── main.tsx           # Entry point
supabase/
└── migrations/
    └── 20260829051455_create_gaming_hub_schema.sql
```

## Features

- **Game Catalog:** Browse games by genre/platform, detailed pages with system requirements and similar games
- **Gaming Tools:**
  - Idea Generator (video, shorts, stream, challenge, channel, game ideas)
  - Gaming Name Generator (gaming, team, clan, Roblox, Discord names with copy)
  - Bio Generator (custom gaming bios with copy)
  - System Check (enter your specs, get compatible game recommendations)
  - DPI/eDPI Calculator
  - Download Time Calculator
  - FPS Converter (frame time + frame budget)
  - Unit Converter (digital storage)
- **Articles:** News, guides, tutorials, reviews, best-of lists with categories
- **Search:** Central search across games, tools, and articles
- **User Accounts:** Email/password auth, profile with display name + bio, save favorite games and tools
- **RTL + Persian:** Fully right-to-left layout with Vazirmatn font
- **Responsive:** Works on mobile, tablet, and desktop
- **Dark Gaming Theme:** Modern dark UI with gradient accents

## Database Schema

5 tables with Row Level Security:

| Table | Purpose | RLS |
|-------|---------|-----|
| `games` | Game catalog | Public read |
| `articles` | Gaming content | Public read |
| `user_profiles` | Extended user info | Owner-scoped |
| `user_favorites` | Saved games | Owner-scoped |
| `user_tool_favorites` | Saved tools | Owner-scoped |

## Notes

- The idea generator uses sample data. It's architected so you can swap in a real AI API later via an edge function.
- Email confirmation is OFF (standard for dev). Turn it on in Supabase settings for production.
- Cover images use Pexels stock photos as placeholders.
