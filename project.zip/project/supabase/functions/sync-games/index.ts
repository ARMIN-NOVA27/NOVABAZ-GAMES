// supabase/functions/sync-games/index.ts
//
// Pulls REAL games, screenshots, and trailers from:
//   - SteamSpy (https://steamspy.com) — free, no key, gives ranked lists
//     of popular Steam app ids by genre / recent popularity.
//   - Steam's own public Store API (store.steampowered.com/api/appdetails)
//     — free, no key, gives full game details including screenshots and
//     trailer video URLs.
//
// No fake data is ever inserted: if Steam doesn't have a field (e.g. no
// trailer for a game), we simply leave it null instead of making one up.
//
// Deploy: supabase functions deploy sync-games
// Schedule: see the pg_cron snippet in the accompanying migration/README.
// Manual test: supabase functions invoke sync-games

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

// How many NEW games to fully process per invocation. Kept modest so a
// single run finishes comfortably within the Edge Function time limit and
// so we don't hammer Steam's unofficial rate limits. The cron job runs
// this repeatedly, so the catalog keeps growing run after run.
const BATCH_SIZE = 20;
const STEAM_DELAY_MS = 350;

const GENRE_MAP: Record<string, string> = {
  Action: 'Action',
  Adventure: 'Adventure',
  RPG: 'RPG',
  Strategy: 'Strategy',
  Simulation: 'Simulation',
  Sports: 'Sports',
  Racing: 'Racing',
  Casual: 'Adventure',
  Indie: 'Adventure',
  'Massively Multiplayer': 'MMO',
  'Free to Play': 'Action',
};

const SOURCE_LISTS = [
  'top100in2weeks',
  'top100forever',
  'top100owned',
];

const GENRE_LISTS = ['Action', 'RPG', 'Strategy', 'Adventure', 'Simulation', 'Sports', 'Racing'];

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function stripHtml(html: string | undefined): string {
  if (!html) return '';
  return html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}

async function fetchSteamSpyAppIds(): Promise<Set<number>> {
  const ids = new Set<number>();

  for (const list of SOURCE_LISTS) {
    try {
      const res = await fetch(`https://steamspy.com/api.php?request=${list}`);
      if (!res.ok) continue;
      const json = await res.json();
      for (const key of Object.keys(json)) {
        const id = parseInt(key, 10);
        if (!isNaN(id)) ids.add(id);
      }
    } catch {
      // SteamSpy occasionally times out; skip that list and keep going.
    }
    await delay(200);
  }

  for (const genre of GENRE_LISTS) {
    try {
      const res = await fetch(`https://steamspy.com/api.php?request=genre&genre=${encodeURIComponent(genre)}`);
      if (!res.ok) continue;
      const json = await res.json();
      for (const key of Object.keys(json)) {
        const id = parseInt(key, 10);
        if (!isNaN(id)) ids.add(id);
      }
    } catch {
      // ignore and continue
    }
    await delay(200);
  }

  return ids;
}

interface SteamAppDetails {
  type: string;
  name: string;
  header_image: string;
  short_description: string;
  detailed_description: string;
  genres?: { description: string }[];
  developers?: string[];
  publishers?: string[];
  release_date?: { date: string };
  screenshots?: { path_thumbnail: string; path_full: string }[];
  movies?: { webm?: { max: string }; mp4?: { max: string } }[];
  platforms?: { windows: boolean; mac: boolean; linux: boolean };
  metacritic?: { score: number };
  is_free?: boolean;
}

async function fetchAppDetails(appid: number): Promise<SteamAppDetails | null> {
  try {
    const res = await fetch(
      `https://store.steampowered.com/api/appdetails?appids=${appid}&l=english&cc=us`
    );
    if (!res.ok) return null;
    const json = await res.json();
    const entry = json[String(appid)];
    if (!entry?.success || !entry.data) return null;
    if (entry.data.type !== 'game') return null; // skip DLC, soundtracks, tools, demos
    return entry.data as SteamAppDetails;
  } catch {
    return null;
  }
}

function slugify(title: string, appid: number): string {
  const base = title
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
  return base ? `${base}-${appid}` : `game-${appid}`;
}

Deno.serve(async () => {
  const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

  const { data: existingRows, error: existingErr } = await supabase
    .from('games')
    .select('steam_appid')
    .not('steam_appid', 'is', null);

  if (existingErr) {
    return new Response(JSON.stringify({ error: existingErr.message }), { status: 500 });
  }

  const existingIds = new Set((existingRows ?? []).map((r) => r.steam_appid as number));
  const candidateIds = await fetchSteamSpyAppIds();
  const newIds = [...candidateIds].filter((id) => !existingIds.has(id)).slice(0, BATCH_SIZE);

  let inserted = 0;
  const skipped: number[] = [];

  for (const appid of newIds) {
    const details = await fetchAppDetails(appid);
    await delay(STEAM_DELAY_MS);

    if (!details) {
      skipped.push(appid);
      continue;
    }

    const genreNames = (details.genres ?? [])
      .map((g) => GENRE_MAP[g.description] || null)
      .filter((g): g is string => !!g);
    const uniqueGenres = [...new Set(genreNames)];

    const platforms: string[] = [];
    if (details.platforms?.windows) platforms.push('PC');
    if (details.platforms?.mac) platforms.push('Mac');
    if (details.platforms?.linux) platforms.push('Linux');
    if (platforms.length === 0) platforms.push('PC'); // Steam data omits this occasionally; PC is the safe default for a Steam game

    const trailer =
      details.movies?.[0]?.mp4?.max || details.movies?.[0]?.webm?.max || null;

    const { data: insertedGame, error: insertErr } = await supabase
      .from('games')
      .insert({
        steam_appid: appid,
        slug: slugify(details.name, appid),
        title: details.name,
        cover_url: details.header_image || null,
        genre: uniqueGenres[0] || 'Action',
        genres: uniqueGenres,
        platforms,
        description: stripHtml(details.short_description || details.detailed_description),
        release_date: details.release_date?.date ? parseSteamDate(details.release_date.date) : null,
        developer: details.developers?.[0] || null,
        publisher: details.publishers?.[0] || null,
        rating: details.metacritic?.score ? Math.round((details.metacritic.score / 20) * 10) / 10 : 0,
        trailer_url: trailer,
        is_free: !!details.is_free,
        is_new: false,
        is_popular: true,
      })
      .select('id')
      .single();

    if (insertErr || !insertedGame) {
      skipped.push(appid);
      continue;
    }

    const images = (details.screenshots ?? []).slice(0, 5).map((s, i) => ({
      game_id: insertedGame.id,
      image_url: s.path_full,
      thumbnail_url: s.path_thumbnail || s.path_full,
      sort_order: i,
    }));

    if (images.length > 0) {
      await supabase.from('game_images').insert(images);
    }

    inserted++;
  }

  return new Response(
    JSON.stringify({ inserted, skipped: skipped.length, candidatesFound: candidateIds.size }),
    { headers: { 'Content-Type': 'application/json' } }
  );
});

function parseSteamDate(raw: string): string | null {
  // Steam dates come as "17 Aug, 2023" or similar; best-effort parse only,
  // never fabricated when it fails.
  const parsed = new Date(raw);
  if (isNaN(parsed.getTime())) return null;
  return parsed.toISOString().slice(0, 10);
}
