/*
# Gaming Hub — Phase 2 Step 3: Admin RLS policies

Adds admin write policies for games, articles, ads, and reports
using the is_admin() SECURITY DEFINER function.
*/

-- ===================== GAMES: admin write =====================
DROP POLICY IF EXISTS "admin_insert_games" ON games;
CREATE POLICY "admin_insert_games" ON games FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_games" ON games;
CREATE POLICY "admin_update_games" ON games FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_delete_games" ON games;
CREATE POLICY "admin_delete_games" ON games FOR DELETE
  TO authenticated USING (is_admin());

-- ===================== ARTICLES: admin write =====================
DROP POLICY IF EXISTS "admin_insert_articles" ON articles;
CREATE POLICY "admin_insert_articles" ON articles FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_articles" ON articles;
CREATE POLICY "admin_update_articles" ON articles FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_delete_articles" ON articles;
CREATE POLICY "admin_delete_articles" ON articles FOR DELETE
  TO authenticated USING (is_admin());

-- ===================== ADS: admin write =====================
DROP POLICY IF EXISTS "admin_insert_ads" ON ads;
CREATE POLICY "admin_insert_ads" ON ads FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_ads" ON ads;
CREATE POLICY "admin_update_ads" ON ads FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_delete_ads" ON ads;
CREATE POLICY "admin_delete_ads" ON ads FOR DELETE
  TO authenticated USING (is_admin());

-- ===================== REPORTS: admin read/update =====================
DROP POLICY IF EXISTS "admin_read_reports" ON reports;
CREATE POLICY "admin_read_reports" ON reports FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_update_reports" ON reports;
CREATE POLICY "admin_update_reports" ON reports FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- ===================== GAME VIEWS: admin read =====================
DROP POLICY IF EXISTS "admin_read_views" ON game_views;
CREATE POLICY "admin_read_views" ON game_views FOR SELECT
  TO authenticated USING (is_admin());

-- ===================== USER ROLES: admin read all =====================
DROP POLICY IF EXISTS "admin_read_roles" ON user_roles;
CREATE POLICY "admin_read_roles" ON user_roles FOR SELECT
  TO authenticated USING (is_admin());
