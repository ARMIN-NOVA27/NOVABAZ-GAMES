/*
# Real per-user notifications system

Replaces the previous fake "Notifications" UI (which just showed the
newest games/articles to every visitor, logged in or not, with no
per-user state) with an actual notifications table.

1. New table
   - `notifications`: user_id, type, title, body, url, is_read, created_at.
     Owner-scoped RLS — a user can only ever see/update their own rows.

2. Real triggers (no fake/demo data)
   - `award_achievement()` now also inserts a notification when it grants
     a new achievement.
   - A new trigger on `reports` fires when an admin changes a report's
     status away from 'pending', notifying the original reporter.

3. Security
   - INSERT is NOT granted to anon/authenticated directly — only internal
     SECURITY DEFINER functions create notifications. Users can only
     SELECT and UPDATE (mark as read) their own rows.
*/

-- ===================== TABLE =====================
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('achievement', 'report_update')),
  title text NOT NULL,
  body text,
  url text,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_notifications" ON notifications;
CREATE POLICY "select_own_notifications" ON notifications FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_notifications" ON notifications;
CREATE POLICY "update_own_notifications" ON notifications FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- No INSERT/DELETE policy for anon/authenticated: rows are only created by
-- the SECURITY DEFINER functions below, and users don't need to delete them.

CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(user_id) WHERE is_read = false;

-- Enable Supabase Realtime for this table so the client can subscribe to
-- new notifications live (used by the Notifications bell in the header).
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'notifications'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
  END IF;
END $$;

-- ===================== INTERNAL HELPER =====================
CREATE OR REPLACE FUNCTION create_notification(
  p_user_id uuid,
  p_type text,
  p_title text,
  p_body text,
  p_url text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO notifications (user_id, type, title, body, url)
  VALUES (p_user_id, p_type, p_title, p_body, p_url);
END;
$$;

REVOKE EXECUTE ON FUNCTION create_notification(uuid, text, text, text, text) FROM PUBLIC;
-- Intentionally not granted to anon/authenticated: only called from other
-- SECURITY DEFINER functions/triggers below, never directly from the client.

-- ===================== ACHIEVEMENT NOTIFICATIONS =====================
CREATE OR REPLACE FUNCTION award_achievement(p_user_id uuid, p_achievement_slug text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  ach_id uuid;
  ach_title text;
  inserted_id uuid;
BEGIN
  SELECT id, title INTO ach_id, ach_title FROM achievements WHERE slug = p_achievement_slug;
  IF ach_id IS NOT NULL THEN
    INSERT INTO user_achievements (user_id, achievement_id)
    VALUES (p_user_id, ach_id)
    ON CONFLICT (user_id, achievement_id) DO NOTHING
    RETURNING id INTO inserted_id;

    IF inserted_id IS NOT NULL THEN
      PERFORM create_notification(
        p_user_id,
        'achievement',
        'دستاورد جدید: ' || ach_title,
        'یک دستاورد جدید کسب کردی!',
        '/profile'
      );
    END IF;
  END IF;
END;
$$;

-- ===================== REPORT STATUS NOTIFICATIONS =====================
CREATE OR REPLACE FUNCTION notify_report_status_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.reporter_id IS NOT NULL
     AND NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('resolved', 'dismissed') THEN
    PERFORM create_notification(
      NEW.reporter_id,
      'report_update',
      CASE WHEN NEW.status = 'resolved' THEN 'گزارش شما بررسی شد' ELSE 'گزارش شما رد شد' END,
      NEW.admin_note,
      NULL
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_notify_report_status ON reports;
CREATE TRIGGER trigger_notify_report_status
  AFTER UPDATE ON reports
  FOR EACH ROW EXECUTE FUNCTION notify_report_status_change();

REVOKE EXECUTE ON FUNCTION notify_report_status_change() FROM PUBLIC;
