/*
# Gaming Hub - Initial Schema

1. New Tables
- `games` — catalog of games with details, genres, platforms, system requirements, ratings
- `articles` — gaming content (news, reviews, guides, tutorials, best-of lists)
- `user_favorites` — saved games per authenticated user
- `user_tool_favorites` — saved tools per authenticated user
- `user_profiles` — extended profile info (display name, bio, avatar)

2. Security
- `games`: public read (anon+authenticated), no writes (managed via service role / seed)
- `articles`: public read, no writes
- `user_favorites`: owner-scoped CRUD (authenticated only)
- `user_tool_favorites`: owner-scoped CRUD (authenticated only)
- `user_profiles`: owner-scoped CRUD (authenticated only)

3. Notes
- Games and articles are seeded with sample data for the MVP.
- User-specific tables use auth.uid() ownership with DEFAULT auth.uid() on owner columns.
- RLS enabled on every table.
*/

-- ===================== GAMES =====================
CREATE TABLE IF NOT EXISTS games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  title text NOT NULL,
  title_fa text,
  cover_url text,
  genre text NOT NULL,
  genres text[] DEFAULT '{}',
  platforms text[] DEFAULT '{}',
  description text,
  description_fa text,
  release_date date,
  developer text,
  publisher text,
  min_cpu text,
  min_gpu text,
  min_ram text,
  min_storage text,
  min_os text,
  rec_cpu text,
  rec_gpu text,
  rec_ram text,
  rec_storage text,
  rec_os text,
  rating numeric DEFAULT 0,
  rating_count integer DEFAULT 0,
  is_popular boolean DEFAULT false,
  is_new boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE games ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_games" ON games;
CREATE POLICY "public_read_games" ON games FOR SELECT
  TO anon, authenticated USING (true);

-- ===================== ARTICLES =====================
CREATE TABLE IF NOT EXISTS articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  title text NOT NULL,
  title_fa text,
  excerpt text,
  excerpt_fa text,
  content text,
  content_fa text,
  category text NOT NULL,
  cover_url text,
  author text,
  published_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE articles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_articles" ON articles;
CREATE POLICY "public_read_articles" ON articles FOR SELECT
  TO anon, authenticated USING (true);

-- ===================== USER PROFILES =====================
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text,
  bio text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (user_id)
);

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON user_profiles;
CREATE POLICY "select_own_profile" ON user_profiles FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_profile" ON user_profiles;
CREATE POLICY "insert_own_profile" ON user_profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_profile" ON user_profiles;
CREATE POLICY "update_own_profile" ON user_profiles FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_profile" ON user_profiles;
CREATE POLICY "delete_own_profile" ON user_profiles FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ===================== USER FAVORITES (GAMES) =====================
CREATE TABLE IF NOT EXISTS user_favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  game_id uuid REFERENCES games(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE (user_id, game_id)
);

ALTER TABLE user_favorites ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_favorites" ON user_favorites;
CREATE POLICY "select_own_favorites" ON user_favorites FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_favorites" ON user_favorites;
CREATE POLICY "insert_own_favorites" ON user_favorites FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_favorites" ON user_favorites;
CREATE POLICY "delete_own_favorites" ON user_favorites FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ===================== USER TOOL FAVORITES =====================
CREATE TABLE IF NOT EXISTS user_tool_favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  tool_slug text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE (user_id, tool_slug)
);

ALTER TABLE user_tool_favorites ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_tool_favorites" ON user_tool_favorites;
CREATE POLICY "select_own_tool_favorites" ON user_tool_favorites FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_tool_favorites" ON user_tool_favorites;
CREATE POLICY "insert_own_tool_favorites" ON user_tool_favorites FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_tool_favorites" ON user_tool_favorites;
CREATE POLICY "delete_own_tool_favorites" ON user_tool_favorites FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ===================== INDEXES =====================
CREATE INDEX IF NOT EXISTS idx_games_slug ON games(slug);
CREATE INDEX IF NOT EXISTS idx_games_popular ON games(is_popular);
CREATE INDEX IF NOT EXISTS idx_games_new ON games(is_new);
CREATE INDEX IF NOT EXISTS idx_articles_slug ON articles(slug);
CREATE INDEX IF NOT EXISTS idx_articles_category ON articles(category);
CREATE INDEX IF NOT EXISTS idx_user_favorites_user ON user_favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_user_tool_fav_user ON user_tool_favorites(user_id);
