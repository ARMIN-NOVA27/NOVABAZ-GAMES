-- Fix: Revoke EXECUTE from PUBLIC on SECURITY DEFINER functions that should not be publicly callable
-- Supabase grants EXECUTE to PUBLIC by default; need to revoke that explicitly

-- award_achievement: only authenticated users (function checks auth.uid() = p_user_id)
REVOKE EXECUTE ON FUNCTION award_achievement(uuid, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION award_achievement(uuid, text) TO authenticated;

-- get_admin_stats: admin-only (function checks is_admin internally)
REVOKE EXECUTE ON FUNCTION get_admin_stats() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION get_admin_stats() TO authenticated;

-- handle_new_user: trigger function, should not be directly callable by anyone
REVOKE EXECUTE ON FUNCTION handle_new_user() FROM PUBLIC;

-- increment_ad_clicks: public-facing (all visitors see ads, clicks tracked)
-- Keep PUBLIC grant - this is intentionally public

-- increment_ad_impressions: public-facing (all visitors see ads, impressions tracked)
-- Keep PUBLIC grant - this is intentionally public

-- is_admin: used in RLS policies, callable by authenticated
REVOKE EXECUTE ON FUNCTION is_admin() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION is_admin() TO authenticated;

-- recalc_game_rating: internal trigger function, should not be directly callable
REVOKE EXECUTE ON FUNCTION recalc_game_rating() FROM PUBLIC;
