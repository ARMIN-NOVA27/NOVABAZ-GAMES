/*
# Support install/download buttons: free-Steam-only for PC, store links for mobile

- `games.is_free`: populated by the Steam sync (details.is_free). The PC
  "Install via Steam" button only ever shows for free games — paid games
  never get a purchase/download link from this site.
- `games.app_store_url` / `play_store_url` / `myket_url`: filled in
  manually by the admin when adding a mobile game (Steam has no mobile
  games, so these are never auto-populated).
*/

ALTER TABLE games ADD COLUMN IF NOT EXISTS is_free boolean NOT NULL DEFAULT false;
ALTER TABLE games ADD COLUMN IF NOT EXISTS app_store_url text;
ALTER TABLE games ADD COLUMN IF NOT EXISTS play_store_url text;
ALTER TABLE games ADD COLUMN IF NOT EXISTS myket_url text;
