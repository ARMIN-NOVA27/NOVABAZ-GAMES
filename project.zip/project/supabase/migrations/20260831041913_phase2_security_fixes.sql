-- Fix security advisor findings: restrict EXECUTE on SECURITY DEFINER functions

-- award_achievement: should only be callable by authenticated users (for self-achievement)
-- But the function itself checks auth.uid() = p_user_id, so authenticated is fine
REVOKE EXECUTE ON FUNCTION award_achievement(uuid, text) FROM anon;

-- get_admin_stats: admin-only function, should NOT be callable by anon or authenticated
-- Only admins should call this. Revoke from both, grant to authenticated (function checks is_admin internally)
REVOKE EXECUTE ON FUNCTION get_admin_stats() FROM anon;
REVOKE EXECUTE ON FUNCTION get_admin_stats() FROM authenticated;
GRANT EXECUTE ON FUNCTION get_admin_stats() TO authenticated;

-- handle_new_user: trigger function, should not be directly callable
REVOKE EXECUTE ON FUNCTION handle_new_user() FROM anon;
REVOKE EXECUTE ON FUNCTION handle_new_user() FROM authenticated;

-- increment_ad_clicks: public-facing (ad tracking), anon needs to call this
-- Keep anon access since ads are shown to all visitors

-- increment_ad_impressions: same as above, public-facing
-- Keep anon access since ads are shown to all visitors

-- is_admin: used in RLS policies, should be callable by authenticated
REVOKE EXECUTE ON FUNCTION is_admin() FROM anon;

-- recalc_game_rating: internal trigger function, should not be directly callable
REVOKE EXECUTE ON FUNCTION recalc_game_rating() FROM anon;
REVOKE EXECUTE ON FUNCTION recalc_game_rating() FROM authenticated;
