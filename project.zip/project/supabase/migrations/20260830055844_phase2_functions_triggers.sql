/*
# Gaming Hub — Phase 2 Step 2: Security functions & triggers

Creates SECURITY DEFINER functions:
- is_admin(): checks user_roles table for admin role
- award_achievement(): grants achievement to a user (RPC only)
- recalc_game_rating(): trigger to update game rating/count from reviews
- handle_new_user(): trigger to auto-create profile on signup
- get_admin_stats(): returns dashboard counts for admin panel

Also creates triggers for rating recalculation and new-user profile creation.
*/

-- ===================== IS_ADMIN =====================
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid() AND role = 'admin'
  );
$$;

-- ===================== AWARD ACHIEVEMENT =====================
CREATE OR REPLACE FUNCTION award_achievement(p_user_id uuid, p_achievement_slug text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  ach_id uuid;
BEGIN
  SELECT id INTO ach_id FROM achievements WHERE slug = p_achievement_slug;
  IF ach_id IS NOT NULL THEN
    INSERT INTO user_achievements (user_id, achievement_id)
    VALUES (p_user_id, ach_id)
    ON CONFLICT (user_id, achievement_id) DO NOTHING;
  END IF;
END;
$$;

-- ===================== RECALC GAME RATING =====================
CREATE OR REPLACE FUNCTION recalc_game_rating()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  avg_rating numeric;
  review_count integer;
BEGIN
  SELECT COALESCE(avg(rating), 0), count(*)
  INTO avg_rating, review_count
  FROM reviews WHERE game_id = COALESCE(NEW.game_id, OLD.game_id);

  UPDATE games
  SET rating = avg_rating, rating_count = review_count
  WHERE id = COALESCE(NEW.game_id, OLD.game_id);

  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trigger_recalc_rating_ins ON reviews;
CREATE TRIGGER trigger_recalc_rating_ins
  AFTER INSERT ON reviews
  FOR EACH ROW EXECUTE FUNCTION recalc_game_rating();

DROP TRIGGER IF EXISTS trigger_recalc_rating_upd ON reviews;
CREATE TRIGGER trigger_recalc_rating_upd
  AFTER UPDATE ON reviews
  FOR EACH ROW EXECUTE FUNCTION recalc_game_rating();

DROP TRIGGER IF EXISTS trigger_recalc_rating_del ON reviews;
CREATE TRIGGER trigger_recalc_rating_del
  AFTER DELETE ON reviews
  FOR EACH ROW EXECUTE FUNCTION recalc_game_rating();

-- ===================== AUTO-CREATE PROFILE ON SIGNUP =====================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO user_profiles (user_id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', ''))
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ===================== GET ADMIN STATS =====================
CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS json
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT json_build_object(
    'games', (SELECT count(*) FROM games),
    'articles', (SELECT count(*) FROM articles),
    'users', (SELECT count(*) FROM auth.users),
    'reviews', (SELECT count(*) FROM reviews),
    'favorites', (SELECT count(*) FROM user_favorites),
    'watchlist', (SELECT count(*) FROM user_watchlist),
    'ads', (SELECT count(*) FROM ads),
    'active_ads', (SELECT count(*) FROM ads WHERE is_active = true),
    'reports', (SELECT count(*) FROM reports),
    'pending_reports', (SELECT count(*) FROM reports WHERE status = 'pending'),
    'achievements_earned', (SELECT count(*) FROM user_achievements)
  );
$$;
