/*
# Fix: get_admin_stats() had no internal admin check

The function was granted only to `authenticated` under the assumption
that "the function checks is_admin internally" (see migration
20260831041937), but the function body never actually called is_admin().
Any authenticated (non-admin) user could call this RPC and read
platform-wide stats (user counts, report counts, etc).

This migration adds the missing check: non-admins now get an exception
instead of data.
*/

CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;

  RETURN json_build_object(
    'games', (SELECT count(*) FROM games),
    'articles', (SELECT count(*) FROM articles),
    'users', (SELECT count(*) FROM auth.users),
    'reviews', (SELECT count(*) FROM reviews),
    'favorites', (SELECT count(*) FROM user_favorites),
    'watchlist', (SELECT count(*) FROM user_watchlist),
    'ads', (SELECT count(*) FROM ads),
    'active_ads', (SELECT count(*) FROM ads WHERE is_active = true),
    'reports', (SELECT count(*) FROM reports),
    'pending_reports', (SELECT count(*) FROM reports WHERE status = 'pending'),
    'achievements_earned', (SELECT count(*) FROM user_achievements)
  );
END;
$$;
