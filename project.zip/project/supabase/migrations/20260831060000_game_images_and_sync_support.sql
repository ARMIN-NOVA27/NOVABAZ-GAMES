/*
# Game catalog expansion: multiple images, trailers, external sync support

Prepares the schema for an automated game-catalog sync job (pulling real
games, real screenshots, and trailers from the public Steam Store API +
SteamSpy — no API key or account required — via a scheduled Edge
Function). No fake/placeholder game data is inserted here — this
migration only adds the columns/tables the sync job needs.

1. `games` table changes
   - `steam_appid`: Steam's own app id, used to upsert without duplicating
     a game that's already been synced.
   - `trailer_url`: optional; populated only when Steam actually has one.

2. New `game_images` table
   - Multiple real screenshots per game (at least 3, when the source has
     them), ordered, each game's images owned by that game via FK cascade.
   - Public read-only, same as `games` — writes only via the sync job's
     service-role key, never from the client.
*/

ALTER TABLE games ADD COLUMN IF NOT EXISTS steam_appid integer UNIQUE;
ALTER TABLE games ADD COLUMN IF NOT EXISTS trailer_url text;

CREATE TABLE IF NOT EXISTS game_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE game_images ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_game_images" ON game_images;
CREATE POLICY "public_read_game_images" ON game_images FOR SELECT
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_game_images_game ON game_images(game_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_games_steam_appid ON games(steam_appid);
