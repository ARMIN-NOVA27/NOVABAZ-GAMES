/*
# Schedule automatic game catalog sync

Runs the sync-games Edge Function every 6 hours so the catalog keeps
picking up new popular Steam games over time, without any manual
trigger. Uses pg_cron + pg_net (both available on Supabase).

Note: this migration hard-codes this project's URL and public anon key
(the same anon key already used in the frontend's .env — not a secret).
The Edge Function itself only performs read calls to Steam/SteamSpy and
writes via its own service-role key, so the anon key here is only used
to pass Supabase's function-invocation auth check, not to authorize the
writes themselves.
*/

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

SELECT cron.unschedule('sync-games-every-6-hours')
WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'sync-games-every-6-hours');

SELECT cron.schedule(
  'sync-games-every-6-hours',
  '0 */6 * * *',
  $$
  SELECT net.http_post(
    url := 'https://osxbyxumfpsarkhldfza.supabase.co/functions/v1/sync-games',
    headers := jsonb_build_object(
      'Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9zeGJ5eHVtZnBzYXJraGxkZnphIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc5NzcxMzYsImV4cCI6MjEwMzU1MzEzNn0.npQm63xRo-0EP4XHULBv_FqoUHYv38bEht-YnmqW2I4',
      'Content-Type', 'application/json'
    ),
    body := '{}'::jsonb
  );
  $$
);
