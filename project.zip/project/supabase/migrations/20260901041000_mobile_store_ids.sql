/*
# Fix mobile install links: store IDs instead of raw URLs

Raw URL fields let an admin accidentally paste a store homepage instead
of the exact game page. Google Play and Myket both key apps by Android
package name, and Myket's own docs confirm its app-page URL is
myket.ir/app/{package_name} — so storing the package name once and
building both URLs from it guarantees they always point at the specific
game, never a generic store page. App Store pages are keyed by a
numeric app id instead.
*/

ALTER TABLE games DROP COLUMN IF EXISTS app_store_url;
ALTER TABLE games DROP COLUMN IF EXISTS play_store_url;
ALTER TABLE games DROP COLUMN IF EXISTS myket_url;

ALTER TABLE games ADD COLUMN IF NOT EXISTS android_package_name text;
ALTER TABLE games ADD COLUMN IF NOT EXISTS ios_app_id text;
