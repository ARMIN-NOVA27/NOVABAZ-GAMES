/*
# Add thumbnail_url to game_images for faster gallery loading

Steam's screenshot data includes both a full-resolution URL and a small
thumbnail URL. Previously only the full-res URL was stored and reused
for the small thumbnail strip too, meaning the browser downloaded a
full screenshot just to display it at ~96px wide. Storing the real
thumbnail URL fixes that.
*/

ALTER TABLE game_images ADD COLUMN IF NOT EXISTS thumbnail_url text;
