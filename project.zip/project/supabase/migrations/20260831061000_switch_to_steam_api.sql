/*
# Switch external game-sync source from RAWG to Steam's public API

RAWG's signup flow was unreachable, so the sync job now uses Steam's
public Storefront API instead (store.steampowered.com/api/appdetails),
which requires no API key or account at all. Renaming the dedup column
accordingly so it isn't misleading.
*/

ALTER TABLE games RENAME COLUMN rawg_id TO steam_appid;
