/*
# Gaming Hub — Phase 2 Step 4: Ad counter functions

Creates SECURITY DEFINER functions to atomically increment
ad impressions and clicks. These are called from the frontend
to track ad engagement.
*/

CREATE OR REPLACE FUNCTION increment_ad_impressions(p_ad_id uuid)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE ads SET impressions = impressions + 1 WHERE id = p_ad_id;
$$;

CREATE OR REPLACE FUNCTION increment_ad_clicks(p_ad_id uuid)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE ads SET clicks = clicks + 1 WHERE id = p_ad_id;
$$;
