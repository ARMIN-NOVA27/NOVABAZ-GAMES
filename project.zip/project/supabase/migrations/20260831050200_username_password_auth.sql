/*
# Replace phone-OTP auth with username + password

Supabase Auth is built around email/phone identities, not usernames.
The standard workaround: store a real `username` on the profile, and
internally map it to a synthetic, never-shown email
(`<username>@gaminghub.internal`) that Supabase Auth uses under the hood.
The user only ever sees/enters their username and password.

Trade-off (documented, not a bug): since there is no real email or phone
on file, there is no password-recovery channel. A forgotten password
requires manual admin intervention.

1. Schema changes
   - `user_profiles.username`: unique, lowercase, 3-20 chars, [a-z0-9_] only.
   - `handle_new_user()` updated to read username from signup metadata
     instead of display_name-only.

2. New RPCs (needed because login requires resolving username -> email
   BEFORE the user is authenticated)
   - `check_username_available(p_username text)`: public, read-only,
     case-insensitive availability check for the signup form.
   - `get_auth_email_for_username(p_username text)`: public, returns the
     synthetic email for a given username (or null). This only ever
     returns the synthetic, meaningless email — never a real one — so
     exposing it to anon is not a data leak.
*/

-- ===================== USERNAME COLUMN =====================
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS username text;

-- Backfill safety: any pre-existing rows without a username get a
-- placeholder derived from their id so the UNIQUE constraint can apply.
-- (Only matters for accounts created before this migration, e.g. via the
-- old phone-OTP flow.)
UPDATE user_profiles SET username = 'user_' || substr(user_id::text, 1, 8)
WHERE username IS NULL;

ALTER TABLE user_profiles ALTER COLUMN username SET NOT NULL;
ALTER TABLE user_profiles ADD CONSTRAINT username_format
  CHECK (username ~ '^[a-z0-9_]{3,20}$');

CREATE UNIQUE INDEX IF NOT EXISTS idx_user_profiles_username ON user_profiles(username);

-- ===================== UPDATED SIGNUP TRIGGER =====================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO user_profiles (user_id, username, display_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'user_' || substr(NEW.id::text, 1, 8)),
    COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.raw_user_meta_data->>'username', '')
  )
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

-- ===================== USERNAME AVAILABILITY (public, pre-auth) =====================
CREATE OR REPLACE FUNCTION check_username_available(p_username text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT NOT EXISTS (
    SELECT 1 FROM user_profiles WHERE username = lower(p_username)
  );
$$;

REVOKE EXECUTE ON FUNCTION check_username_available(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION check_username_available(text) TO anon, authenticated;

-- ===================== RESOLVE USERNAME -> SYNTHETIC EMAIL (public, pre-auth) =====================
-- Needed because the client must call supabase.auth.signInWithPassword({email, password}),
-- but only has a username at that point. Only ever returns the synthetic,
-- meaningless email (never a real one), so this is safe to expose to anon.
CREATE OR REPLACE FUNCTION get_auth_email_for_username(p_username text)
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT au.email
  FROM user_profiles up
  JOIN auth.users au ON au.id = up.user_id
  WHERE up.username = lower(p_username)
  LIMIT 1;
$$;

REVOKE EXECUTE ON FUNCTION get_auth_email_for_username(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION get_auth_email_for_username(text) TO anon, authenticated;
