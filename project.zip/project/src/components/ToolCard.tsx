import { Link } from 'react-router-dom';
import * as Icons from 'lucide-react';
import type { ToolMeta } from '@/lib/types';

export default function ToolCard({ tool }: { tool: ToolMeta }) {
  const Icon = (Icons as unknown as Record<string, Icons.LucideIcon>)[tool.icon] || Icons.Wrench;

  return (
    <Link
      to={`/tools/${tool.slug}`}
      className="group block bg-slate-800/50 rounded-xl p-5 border border-slate-700/50 hover:border-slate-600 transition-all duration-300 hover:-translate-y-1"
    >
      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${tool.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <h3 className="font-bold text-white group-hover:text-cyan-400 transition-colors">
        {tool.title}
      </h3>
      <p className="text-sm text-slate-400 mt-1.5 leading-relaxed">
        {tool.description}
      </p>
    </Link>
  );
}
