import { useEffect, useState } from 'react';
import { X, ExternalLink } from 'lucide-react';
import { fetchAds, recordAdImpression, recordAdClick } from '@/lib/data';
import type { Ad } from '@/lib/types';

export default function AdBanner({ placement }: { placement: 'home' | 'games' | 'articles' | 'tools' | 'sidebar' }) {
  const [ads, setAds] = useState<Ad[]>([]);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    fetchAds(placement)
      .then((data) => {
        setAds(data);
        if (data.length > 0) {
          recordAdImpression(data[0].id);
        }
      })
      .catch(() => setAds([]));
  }, [placement]);

  if (ads.length === 0 || dismissed) return null;

  const ad = ads[0];

  const handleClick = () => {
    recordAdClick(ad.id);
    if (ad.link_url) {
      window.open(ad.link_url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="relative group">
      <button
        onClick={() => setDismissed(true)}
        className="absolute top-2 left-2 z-10 p-1 rounded bg-slate-900/80 text-slate-500 hover:text-slate-300 transition-colors"
        aria-label="بستن تبلیغ"
      >
        <X className="w-3.5 h-3.5" />
      </button>
      <span className="absolute top-2 right-2 z-10 text-[10px] text-slate-600 bg-slate-900/80 px-1.5 py-0.5 rounded">
        تبلیغ
      </span>
      <div
        onClick={handleClick}
        className="cursor-pointer overflow-hidden rounded-xl border border-slate-700/50 bg-slate-800/50 hover:border-cyan-500/30 transition-all"
      >
        {ad.image_url ? (
          <div className="relative">
            <img src={ad.image_url} alt={ad.title} loading="lazy" className="w-full h-24 sm:h-28 object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 to-transparent flex items-end p-3">
              <div className="flex items-center gap-2">
                <span className="text-white font-bold text-sm">{ad.title}</span>
                {ad.link_url && <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />}
              </div>
            </div>
          </div>
        ) : (
          <div className="p-4 flex items-center justify-between">
            <div>
              <p className="text-white font-bold text-sm">{ad.title}</p>
              {ad.link_url && (
                <span className="text-cyan-400 text-xs flex items-center gap-1 mt-1">
                  مشاهده <ExternalLink className="w-3 h-3" />
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
