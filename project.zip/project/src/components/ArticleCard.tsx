import { Link } from 'react-router-dom';
import { Calendar, User } from 'lucide-react';
import type { Article } from '@/lib/types';
import { formatDate } from '@/lib/utils';

const CATEGORY_LABELS: Record<string, string> = {
  news: 'اخبار',
  guide: 'راهنما',
  tutorial: 'آموزش',
  review: 'معرفی',
  'best-of': 'بهترین‌ها',
};

export default function ArticleCard({ article }: { article: Article }) {
  return (
    <Link
      to={`/articles/${article.slug}`}
      className="group block bg-slate-800/50 rounded-xl overflow-hidden border border-slate-700/50 hover:border-cyan-500/50 transition-all duration-300 hover:-translate-y-1"
    >
      <div className="relative aspect-video overflow-hidden bg-slate-900">
        {article.cover_url ? (
          <img
            src={article.cover_url}
            alt={article.title_fa || article.title}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : null}
        <div className="absolute bottom-2 right-2 bg-cyan-500/90 px-2.5 py-1 rounded text-xs font-bold text-white">
          {CATEGORY_LABELS[article.category] || article.category}
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-white group-hover:text-cyan-400 transition-colors line-clamp-2">
          {article.title_fa || article.title}
        </h3>
        <p className="text-sm text-slate-400 mt-2 line-clamp-2">
          {article.excerpt_fa || article.excerpt}
        </p>
        <div className="flex items-center gap-3 mt-3 text-xs text-slate-500">
          {article.author && (
            <span className="flex items-center gap-1">
              <User className="w-3 h-3" />
              {article.author}
            </span>
          )}
          <span className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            {formatDate(article.published_at)}
          </span>
        </div>
      </div>
    </Link>
  );
}
