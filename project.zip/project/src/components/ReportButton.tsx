import { useState } from 'react';
import { Flag, X, Loader2, Send } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { submitReport } from '@/lib/data';
import { Link } from 'react-router-dom';

interface Props {
  targetType: 'game' | 'article' | 'review';
  targetId: string;
  targetLabel?: string;
}

const REASONS = [
  'محتوای نامناسب',
  'اطلاعات نادرست',
  'هرزنامه یا تبلیغ',
  'توهین یا رفتار نامناسب',
  'مشکل دیگر',
];

export default function ReportButton({ targetType, targetId, targetLabel }: Props) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState('');
  const [customReason, setCustomReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const { user } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const finalReason = reason === 'مشکل دیگر' ? customReason : reason;
    if (!finalReason.trim()) {
      setError('دلیل گزارش را انتخاب کنید.');
      return;
    }
    setLoading(true);
    setError('');
    const { error: err } = await submitReport(user.id, targetType, targetId, finalReason);
    setLoading(false);
    if (err) {
      setError(err);
    } else {
      setSuccess(true);
      setTimeout(() => {
        setOpen(false);
        setSuccess(false);
        setReason('');
        setCustomReason('');
      }, 2000);
    }
  };

  if (!user) {
    return (
      <Link
        to="/auth"
        className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-rose-400 transition-colors"
      >
        <Flag className="w-3 h-3" />
        گزارش
      </Link>
    );
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-rose-400 transition-colors"
      >
        <Flag className="w-3 h-3" />
        گزارش
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60" onClick={() => setOpen(false)}>
          <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Flag className="w-5 h-5 text-rose-400" />
                گزارش {targetLabel || 'محتوا'}
              </h2>
              <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {success ? (
              <div className="text-center py-8">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-3">
                  <Send className="w-6 h-6 text-emerald-400" />
                </div>
                <p className="text-white font-medium">گزارش شما ثبت شد</p>
                <p className="text-slate-400 text-sm mt-1">به‌زودی بررسی خواهد شد.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3">
                <div className="space-y-2">
                  {REASONS.map((r) => (
                    <label key={r} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="reason"
                        value={r}
                        checked={reason === r}
                        onChange={(e) => setReason(e.target.value)}
                        className="accent-rose-500"
                      />
                      <span className="text-sm text-slate-300">{r}</span>
                    </label>
                  ))}
                </div>
                {reason === 'مشکل دیگر' && (
                  <textarea
                    value={customReason}
                    onChange={(e) => setCustomReason(e.target.value)}
                    placeholder="توضیح مشکل..."
                    rows={3}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-rose-500 resize-none text-sm"
                  />
                )}
                {error && <p className="text-rose-400 text-sm">{error}</p>}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 px-6 py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-medium rounded-lg transition-all disabled:opacity-50"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  ارسال گزارش
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </>
  );
}
