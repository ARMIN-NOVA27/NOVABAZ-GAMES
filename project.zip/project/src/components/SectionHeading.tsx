import { Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

interface Props {
  title: string;
  linkTo?: string;
  linkLabel?: string;
}

export default function SectionHeading({ title, linkTo, linkLabel = 'مشاهده همه' }: Props) {
  return (
    <div className="flex items-center justify-between mb-6">
      <h2 className="text-xl sm:text-2xl font-bold text-white">{title}</h2>
      {linkTo && (
        <Link
          to={linkTo}
          className="flex items-center gap-1 text-sm text-cyan-400 hover:text-cyan-300 transition-colors"
        >
          {linkLabel}
          <ChevronLeft className="w-4 h-4" />
        </Link>
      )}
    </div>
  );
}
