import { Link } from 'react-router-dom';
import { Gamepad2, Github, Twitter, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                <Gamepad2 className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg font-bold text-white">
                Gaming <span className="text-cyan-400">Hub</span>
              </span>
            </Link>
            <p className="text-slate-400 text-sm leading-relaxed max-w-md">
              پلتفرم همه‌کاره گیمرهای فارسی‌زبان. ابزارهای کاربردی، معرفی بازی‌ها،
              مطالب گیمینگ و خیلی بیشتر — همه در یکجا.
            </p>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">دسترسی سریع</h4>
            <ul className="space-y-2">
              <li><Link to="/games" className="text-slate-400 hover:text-cyan-400 text-sm transition-colors">بازی‌ها</Link></li>
              <li><Link to="/tools" className="text-slate-400 hover:text-cyan-400 text-sm transition-colors">ابزارها</Link></li>
              <li><Link to="/articles" className="text-slate-400 hover:text-cyan-400 text-sm transition-colors">مطالب</Link></li>
              <li><Link to="/search" className="text-slate-400 hover:text-cyan-400 text-sm transition-colors">جستجو</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">ما را دنبال کنید</h4>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center transition-colors" aria-label="Github">
                <Github className="w-5 h-5 text-slate-300" />
              </a>
              <a href="#" className="w-10 h-10 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center transition-colors" aria-label="Twitter">
                <Twitter className="w-5 h-5 text-slate-300" />
              </a>
              <a href="#" className="w-10 h-10 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center transition-colors" aria-label="Youtube">
                <Youtube className="w-5 h-5 text-slate-300" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-slate-800 text-center">
          <p className="text-slate-500 text-sm">
            © {new Date().getFullYear()} Gaming Hub. ساخته‌شده با عشق برای گیمرها.
          </p>
        </div>
      </div>
    </footer>
  );
}
