import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, X, Award, Flag, CheckCheck } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { fetchNotifications, markNotificationRead, markAllNotificationsRead } from '@/lib/data';
import { supabase } from '@/lib/supabase';
import type { Notification } from '@/lib/types';
import { formatDate } from '@/lib/utils';

export default function Notifications() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const unreadCount = items.filter((i) => !i.is_read).length;

  const load = useCallback(() => {
    if (!user) {
      setItems([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(false);
    fetchNotifications(user.id)
      .then(setItems)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [user]);

  useEffect(() => {
    load();
  }, [load]);

  // Live updates: new notifications appear without a page reload.
  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel(`notifications-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` },
        (payload) => {
          setItems((prev) => [payload.new as Notification, ...prev].slice(0, 20));
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleItemClick = async (item: Notification) => {
    setOpen(false);
    if (!item.is_read) {
      setItems((prev) => prev.map((i) => (i.id === item.id ? { ...i, is_read: true } : i)));
      markNotificationRead(item.id).catch(() => {});
    }
    if (item.url) navigate(item.url);
  };

  const handleMarkAllRead = async () => {
    if (!user || unreadCount === 0) return;
    setItems((prev) => prev.map((i) => ({ ...i, is_read: true })));
    markAllNotificationsRead(user.id).catch(() => {});
  };

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="relative p-2 text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-lg transition-colors"
        aria-label="اعلان‌ها"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute top-1 left-1 w-2 h-2 bg-cyan-400 rounded-full" />
        )}
      </button>

      {open && (
        <div className="absolute left-0 mt-2 w-80 max-w-[calc(100vw-2rem)] bg-slate-800 border border-slate-700 rounded-xl shadow-xl overflow-hidden z-50">
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700">
            <h3 className="text-sm font-bold text-white">اعلان‌ها</h3>
            <div className="flex items-center gap-1">
              {user && unreadCount > 0 && (
                <button
                  onClick={handleMarkAllRead}
                  className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 px-2 py-1 rounded transition-colors"
                >
                  <CheckCheck className="w-3.5 h-3.5" />
                  خواندن همه
                </button>
              )}
              <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className="max-h-80 overflow-y-auto">
            {!user ? (
              <div className="p-6 text-center text-slate-500 text-sm">
                برای دیدن اعلان‌ها ابتدا وارد حساب خود شو.
              </div>
            ) : loading ? (
              <div className="p-6 text-center text-slate-500 text-sm">در حال بارگذاری...</div>
            ) : error ? (
              <div className="p-6 text-center text-rose-400 text-sm">خطا در بارگذاری اعلان‌ها.</div>
            ) : items.length === 0 ? (
              <div className="p-6 text-center text-slate-500 text-sm">اعلانی وجود ندارد</div>
            ) : (
              items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item)}
                  className={`w-full flex items-start gap-3 px-4 py-3 hover:bg-slate-700/50 transition-colors border-b border-slate-700/50 text-right ${
                    !item.is_read ? 'bg-slate-700/20' : ''
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      item.type === 'achievement' ? 'bg-amber-500/20' : 'bg-cyan-500/20'
                    }`}
                  >
                    {item.type === 'achievement' ? (
                      <Award className="w-4 h-4 text-amber-400" />
                    ) : (
                      <Flag className="w-4 h-4 text-cyan-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm truncate ${!item.is_read ? 'text-white font-medium' : 'text-slate-300'}`}>
                      {item.title}
                    </p>
                    {item.body && <p className="text-xs text-slate-500 truncate">{item.body}</p>}
                    <p className="text-xs text-slate-600 mt-0.5">{formatDate(item.created_at)}</p>
                  </div>
                  {!item.is_read && <span className="w-2 h-2 mt-1.5 bg-cyan-400 rounded-full flex-shrink-0" />}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
