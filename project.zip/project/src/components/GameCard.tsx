import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Star, Calendar } from 'lucide-react';
import type { Game } from '@/lib/types';
import { formatRating } from '@/lib/utils';

export default function GameCard({ game }: { game: Game }) {
  const [imgFailed, setImgFailed] = useState(false);
  return (
    <Link
      to={`/games/${game.slug}`}
      className="group block bg-slate-800/50 rounded-xl overflow-hidden border border-slate-700/50 hover:border-cyan-500/50 transition-all duration-300 hover:-translate-y-1"
    >
      <div className="relative aspect-[3/4] overflow-hidden bg-slate-900">
        {game.cover_url && !imgFailed ? (
          <img
            src={game.cover_url}
            alt={game.title_fa || game.title}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            onError={() => setImgFailed(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-slate-600">
            <Star className="w-12 h-12" />
          </div>
        )}
        <div className="absolute top-2 right-2 bg-slate-950/80 backdrop-blur-sm px-2 py-1 rounded-lg flex items-center gap-1">
          <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span className="text-xs font-bold text-white">{formatRating(game.rating)}</span>
        </div>
        {game.is_new && (
          <div className="absolute top-2 left-2 bg-cyan-500 px-2 py-0.5 rounded text-xs font-bold text-white">
            جدید
          </div>
        )}
      </div>
      <div className="p-3">
        <h3 className="font-bold text-white text-sm truncate group-hover:text-cyan-400 transition-colors">
          {game.title_fa || game.title}
        </h3>
        <div className="flex items-center gap-2 mt-1.5">
          <span className="text-xs text-slate-400">{game.genre}</span>
          {game.release_date && (
            <span className="flex items-center gap-1 text-xs text-slate-500">
              <Calendar className="w-3 h-3" />
              {new Date(game.release_date).getFullYear()}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
