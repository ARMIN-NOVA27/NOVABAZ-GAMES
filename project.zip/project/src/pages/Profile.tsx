import { useEffect, useState } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { User, Heart, Wrench, LogOut, Save, Loader2, Bookmark, Star, Award, MessageSquare, Trash2 } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { fetchGames, fetchUserAchievements, fetchAllAchievements, deleteReview } from '@/lib/data';
import { TOOLS } from '@/lib/tools';
import type { Game, UserProfile, Review, Achievement, UserAchievement } from '@/lib/types';
import GameCard from '@/components/GameCard';
import { formatDate, formatRating } from '@/lib/utils';
import { useSEO } from '@/lib/useSEO';

export default function Profile() {
  useSEO({ title: 'پروفایل کاربری', description: 'مدیریت حساب، علاقه‌مندی‌ها، نظرات و دستاوردها' });
  const { user, loading, signOut } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [saving, setSaving] = useState(false);
  const [savedGames, setSavedGames] = useState<Game[]>([]);
  const [watchlistGames, setWatchlistGames] = useState<Game[]>([]);
  const [userReviews, setUserReviews] = useState<Review[]>([]);
  const [savedToolSlugs, setSavedToolSlugs] = useState<string[]>([]);
  const [allAchievements, setAllAchievements] = useState<Achievement[]>([]);
  const [userAchs, setUserAchs] = useState<UserAchievement[]>([]);
  const [tab, setTab] = useState<'info' | 'favorites' | 'watchlist' | 'reviews' | 'tools' | 'achievements'>('info');

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: prof } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();
      if (prof) {
        setProfile(prof);
        setDisplayName(prof.display_name || '');
        setBio(prof.bio || '');
      }

      const [allGames, { data: favs }, { data: watchlist }, { data: reviews }] = await Promise.all([
        fetchGames(),
        supabase.from('user_favorites').select('game_id').eq('user_id', user.id),
        supabase.from('user_watchlist').select('game_id').eq('user_id', user.id),
        supabase.from('reviews').select('*, games(slug, title, title_fa)').eq('user_id', user.id).order('created_at', { ascending: false }),
      ]);
      const favIds = (favs || []).map((f) => f.game_id);
      const wlIds = (watchlist || []).map((w) => w.game_id);
      setSavedGames(allGames.filter((g) => favIds.includes(g.id)));
      setWatchlistGames(allGames.filter((g) => wlIds.includes(g.id)));
      setUserReviews((reviews || []) as Review[]);

      supabase
        .from('user_tool_favorites')
        .select('tool_slug')
        .eq('user_id', user.id)
        .then(({ data }) => setSavedToolSlugs((data || []).map((t) => t.tool_slug)));

      const [achs, uAchs] = await Promise.all([
        fetchAllAchievements(),
        fetchUserAchievements(user.id),
      ]);
      setAllAchievements(achs);
      setUserAchs(uAchs);
    })();
  }, [user]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    const payload = { user_id: user.id, display_name: displayName, bio, updated_at: new Date().toISOString() };
    if (profile) {
      await supabase.from('user_profiles').update(payload).eq('user_id', user.id);
    } else {
      await supabase.from('user_profiles').insert(payload);
    }
    setSaving(false);
  };

  const handleDeleteReview = async (reviewId: string) => {
    await deleteReview(reviewId);
    setUserReviews((prev) => prev.filter((r) => r.id !== reviewId));
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 text-cyan-500 animate-spin" />
      </div>
    );
  }

  if (!user) return <Navigate to="/auth" replace />;

  const savedTools = TOOLS.filter((t) => savedToolSlugs.includes(t.slug));
  const earnedSlugs = new Set(userAchs.map((ua) => ua.achievements?.slug));

  const tabs = [
    { key: 'info' as const, label: 'اطلاعات حساب', icon: User },
    { key: 'favorites' as const, label: `علاقه‌مندی‌ها (${savedGames.length})`, icon: Heart },
    { key: 'watchlist' as const, label: `بعداً بازی می‌کنم (${watchlistGames.length})`, icon: Bookmark },
    { key: 'reviews' as const, label: `نظرات (${userReviews.length})`, icon: MessageSquare },
    { key: 'tools' as const, label: `ابزارها (${savedTools.length})`, icon: Wrench },
    { key: 'achievements' as const, label: `دستاوردها (${userAchs.length})`, icon: Award },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center flex-shrink-0">
          <User className="w-8 h-8 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-bold text-white truncate">{profile?.display_name || 'کاربر'}</h1>
          <p className="text-slate-400 text-sm truncate" dir="ltr">{profile?.username ? `@${profile.username}` : ''}</p>
        </div>
        <button
          onClick={signOut}
          className="flex items-center gap-2 px-4 py-2 text-sm text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors flex-shrink-0"
        >
          <LogOut className="w-4 h-4" />
          <span className="hidden sm:inline">خروج</span>
        </button>
      </div>

      <div className="flex gap-1 mb-6 border-b border-slate-800 overflow-x-auto pb-px">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              tab === t.key
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'info' && (
        <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50 space-y-4 max-w-lg">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">نام نمایشی</label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="نام شما"
              className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">بیو</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="چند کلمه درباره خودت..."
              rows={4}
              className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none"
            />
          </div>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-medium rounded-lg transition-all disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            ذخیره تغییرات
          </button>
        </div>
      )}

      {tab === 'favorites' && (
        <div>
          {savedGames.length === 0 ? (
            <p className="text-slate-400 text-center py-12">
              هنوز بازی‌ای ذخیره نکرده‌اید.{' '}
              <Link to="/games" className="text-cyan-400 hover:text-cyan-300">مرور بازی‌ها</Link>
            </p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {savedGames.map((g) => <GameCard key={g.id} game={g} />)}
            </div>
          )}
        </div>
      )}

      {tab === 'watchlist' && (
        <div>
          {watchlistGames.length === 0 ? (
            <p className="text-slate-400 text-center py-12">
              لیست «بعداً بازی می‌کنم» خالی است.{' '}
              <Link to="/games" className="text-cyan-400 hover:text-cyan-300">مرور بازی‌ها</Link>
            </p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {watchlistGames.map((g) => <GameCard key={g.id} game={g} />)}
            </div>
          )}
        </div>
      )}

      {tab === 'reviews' && (
        <div>
          {userReviews.length === 0 ? (
            <p className="text-slate-400 text-center py-12">
              هنوز نظری ثبت نکرده‌اید.{' '}
              <Link to="/games" className="text-cyan-400 hover:text-cyan-300">مرور بازی‌ها</Link>
            </p>
          ) : (
            <div className="space-y-3">
              {userReviews.map((r) => {
                const gameData = (r as Review & { games?: { slug: string; title: string; title_fa: string | null } }).games;
                return (
                  <div key={r.id} className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                    <div className="flex items-center justify-between gap-3">
                      <Link to={`/games/${gameData?.slug || ''}`} className="font-medium text-white hover:text-cyan-400 transition-colors text-sm">
                        {gameData?.title_fa || gameData?.title || 'بازی'}
                      </Link>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-0.5">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star key={s} className={`w-3.5 h-3.5 ${s <= r.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-700'}`} />
                          ))}
                        </div>
                        <button
                          onClick={() => handleDeleteReview(r.id)}
                          className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    {r.comment && <p className="text-slate-300 text-sm mt-2 leading-relaxed">{r.comment}</p>}
                    <p className="text-slate-600 text-xs mt-2">{formatDate(r.created_at)}</p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {tab === 'tools' && (
        <div>
          {savedTools.length === 0 ? (
            <p className="text-slate-400 text-center py-12">
              هنوز ابزاری ذخیره نکرده‌اید.{' '}
              <Link to="/tools" className="text-cyan-400 hover:text-cyan-300">مرور ابزارها</Link>
            </p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {savedTools.map((t) => (
                <Link key={t.slug} to={`/tools/${t.slug}`} className="bg-slate-800/50 rounded-xl p-5 border border-slate-700/50 hover:border-slate-600 transition-all">
                  <h3 className="font-bold text-white">{t.title}</h3>
                  <p className="text-sm text-slate-400 mt-1">{t.description}</p>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'achievements' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {allAchievements.map((a) => {
            const earned = earnedSlugs.has(a.slug);
            return (
              <div
                key={a.id}
                className={`rounded-xl p-5 border text-center transition-all ${
                  earned
                    ? 'bg-amber-500/10 border-amber-500/30'
                    : 'bg-slate-800/30 border-slate-700/50 opacity-50'
                }`}
              >
                <div className={`w-14 h-14 rounded-full mx-auto mb-3 flex items-center justify-center ${
                  earned ? 'bg-gradient-to-br from-amber-400 to-orange-500' : 'bg-slate-700'
                }`}>
                  <Award className={`w-7 h-7 ${earned ? 'text-white' : 'text-slate-500'}`} />
                </div>
                <h3 className="font-bold text-white text-sm">{a.title}</h3>
                <p className="text-xs text-slate-400 mt-1">{a.description}</p>
                {earned && <p className="text-amber-400 text-xs font-bold mt-2">کسب شده</p>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
