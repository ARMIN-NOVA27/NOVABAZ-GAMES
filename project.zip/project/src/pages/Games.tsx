import { useEffect, useState, useMemo } from 'react';
import { fetchGames } from '@/lib/data';
import type { Game } from '@/lib/types';
import GameCard from '@/components/GameCard';
import AdBanner from '@/components/AdBanner';
import { useSEO } from '@/lib/useSEO';

export default function Games() {
  useSEO({ title: 'بازی‌ها', description: 'مرور و فیلتر تمام بازی‌ها بر اساس ژانر، پلتفرم و امتیاز' });
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [genreFilter, setGenreFilter] = useState<string>('all');
  const [platformFilter, setPlatformFilter] = useState<string>('all');
  const [sort, setSort] = useState<string>('rating');

  useEffect(() => {
    fetchGames()
      .then(setGames)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, []);

  const allGenres = useMemo(() => {
    const set = new Set<string>();
    games.forEach((g) => g.genres.forEach((x) => set.add(x)));
    return Array.from(set).sort();
  }, [games]);

  const allPlatforms = useMemo(() => {
    const set = new Set<string>();
    games.forEach((g) => g.platforms.forEach((x) => set.add(x)));
    return Array.from(set).sort();
  }, [games]);

  const filtered = useMemo(() => {
    let result = games;
    if (genreFilter !== 'all') result = result.filter((g) => g.genres.includes(genreFilter));
    if (platformFilter !== 'all') result = result.filter((g) => g.platforms.includes(platformFilter));
    if (sort === 'rating') result = [...result].sort((a, b) => b.rating - a.rating);
    if (sort === 'name') result = [...result].sort((a, b) => (a.title_fa || a.title).localeCompare(b.title_fa || b.title));
    if (sort === 'newest') result = [...result].sort((a, b) => (b.release_date || '').localeCompare(a.release_date || ''));
    return result;
  }, [games, genreFilter, platformFilter, sort]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-3">
        <p className="text-rose-400 text-lg">خطا در بارگذاری بازی‌ها</p>
        <button onClick={() => window.location.reload()} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm transition-colors">
          تلاش مجدد
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <h1 className="text-2xl sm:text-3xl font-bold text-white mb-6">همه بازی‌ها</h1>

      <div className="mb-6">
        <AdBanner placement="games" />
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-8">
        <select
          value={genreFilter}
          onChange={(e) => setGenreFilter(e.target.value)}
          className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500"
        >
          <option value="all">همه ژانرها</option>
          {allGenres.map((g) => (
            <option key={g} value={g}>{g}</option>
          ))}
        </select>
        <select
          value={platformFilter}
          onChange={(e) => setPlatformFilter(e.target.value)}
          className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500"
        >
          <option value="all">همه پلتفرم‌ها</option>
          {allPlatforms.map((p) => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500"
        >
          <option value="rating">بالاترین امتیاز</option>
          <option value="newest">جدیدترین</option>
          <option value="name">نام</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <p className="text-slate-400 text-center py-12">بازی‌ای با این فیلترها یافت نشد.</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {filtered.map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      )}
    </div>
  );
}
