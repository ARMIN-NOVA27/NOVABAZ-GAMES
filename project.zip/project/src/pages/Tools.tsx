import { TOOLS } from '@/lib/tools';
import ToolCard from '@/components/ToolCard';
import AdBanner from '@/components/AdBanner';
import { useSEO } from '@/lib/useSEO';

export default function Tools() {
  useSEO({ title: 'ابزارهای گیمینگ', description: 'مجموعه‌ای از ابزارهای کاربردی برای گیمرها' });
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">ابزارهای گیمینگ</h1>
        <p className="text-slate-400">مجموعه‌ای از ابزارهای کاربردی برای گیمرها</p>
      </div>
      <div className="mb-6">
        <AdBanner placement="tools" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {TOOLS.map((tool) => (
          <ToolCard key={tool.slug} tool={tool} />
        ))}
      </div>
    </div>
  );
}
