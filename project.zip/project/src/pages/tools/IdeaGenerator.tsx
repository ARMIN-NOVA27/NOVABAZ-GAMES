import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Lightbulb, Sparkles, RefreshCw, Copy, Check } from 'lucide-react';
import { IDEA_CATEGORIES } from '@/lib/ideaData';
import { copyToClipboard } from '@/lib/utils';
import { useSEO } from '@/lib/useSEO';

export default function IdeaGenerator() {
  useSEO({ title: 'ایده‌ساز گیمینگ', description: 'ایده‌های ویدئو، شورتس، استریم، چالش و کانال تولید کن' });
  const [selected, setSelected] = useState(IDEA_CATEGORIES[0].key);
  const [ideas, setIdeas] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const generate = () => {
    setLoading(true);
    const category = IDEA_CATEGORIES.find((c) => c.key === selected);
    if (!category) return;
    setTimeout(() => {
      const shuffled = [...category.ideas].sort(() => Math.random() - 0.5);
      setIdeas(shuffled.slice(0, 10));
      setLoading(false);
    }, 500);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" /> بازگشت به ابزارها
      </Link>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
          <Lightbulb className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">ایده‌ساز گیمینگ</h1>
          <p className="text-slate-400 text-sm">نوع ایده را انتخاب کن و دکمه را بزن</p>
        </div>
      </div>

      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50">
        <label className="block text-sm font-medium text-slate-300 mb-3">نوع ایده</label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
          {IDEA_CATEGORIES.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setSelected(cat.key)}
              className={`px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                selected === cat.key
                  ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <button
          onClick={generate}
          disabled={loading}
          className="w-full flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-bold rounded-xl transition-all disabled:opacity-50"
        >
          {loading ? (
            <RefreshCw className="w-5 h-5 animate-spin" />
          ) : (
            <Sparkles className="w-5 h-5" />
          )}
          {loading ? 'در حال تولید...' : 'ایده تولید کن'}
        </button>
      </div>

      {ideas.length > 0 && (
        <div className="mt-6 space-y-3">
          {ideas.map((idea, i) => (
            <div
              key={i}
              className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50 flex items-start gap-3 animate-fadeIn"
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <span className="w-7 h-7 flex-shrink-0 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center text-sm font-bold">
                {i + 1}
              </span>
              <div className="flex-1">
                <p className="text-slate-200 leading-relaxed">{idea}</p>
              </div>
              <button
                onClick={async () => {
                  const ok = await copyToClipboard(idea);
                  if (ok) { setCopiedIdx(i); setTimeout(() => setCopiedIdx(null), 2000); }
                }}
                className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 transition-colors flex-shrink-0"
                aria-label="کپی"
              >
                {copiedIdx === i ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
