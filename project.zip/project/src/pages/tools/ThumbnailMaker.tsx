import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Download, Type, Palette, Image as ImageIcon, Shapes } from 'lucide-react';
import { copyToClipboard } from '@/lib/utils';
import { useSEO } from '@/lib/useSEO';

const BACKGROUNDS = [
  { id: 'gaming-dark', label: 'تیره گیمینگ', colors: ['#0f172a', '#1e3a5f'] },
  { id: 'neon-cyan', label: 'نئون آبی', colors: ['#0c4a6e', '#06b6d4'] },
  { id: 'fire', label: 'آتشین', colors: ['#7c2d12', '#f97316'] },
  { id: 'purple', label: 'بنفش', colors: ['#3b0764', '#a855f7'] },
  { id: 'green', label: 'سبز نئونی', colors: ['#052e16', '#22c55e'] },
  { id: 'sunset', label: 'غروب', colors: ['#7f1d1d', '#f59e0b'] },
  { id: 'ocean', label: 'اقیانوس', colors: ['#0c4a6e', '#3b82f6'] },
  { id: 'crimson', label: 'قرمز', colors: ['#450a0a', '#dc2626'] },
];

const ICONS = ['🎮', '🔥', '⚔️', '🏆', '💥', '🎯', '🚀', '⚡', '🛡️', '👑', '💎', '🎮'];

export default function ThumbnailMaker() {
  useSEO({ title: 'سازنده تصویر بندانگشتی', description: 'تصویر بندانگشتی جذاب برای ویدئوهای گیمینگ بساز' });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [title, setTitle] = useState('عنوان ویدئو');
  const [subtitle, setSubtitle] = useState('زیرعنوان');
  const [bgIndex, setBgIndex] = useState(0);
  const [icon, setIcon] = useState('🎮');
  const [titleSize, setTitleSize] = useState(48);
  const [subtitleSize, setSubtitleSize] = useState(24);
  const [textColor, setTextColor] = useState('#ffffff');
  const [accentColor, setAccentColor] = useState('#06b6d4');

  useEffect(() => {
    drawCanvas();
  }, [title, subtitle, bgIndex, icon, titleSize, subtitleSize, textColor, accentColor]);

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 1280;
    canvas.height = 720;
    const maxTextWidth = canvas.width - 120;

    // Background gradient
    const bg = BACKGROUNDS[bgIndex];
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, bg.colors[0]);
    grad.addColorStop(1, bg.colors[1]);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Accent bar
    ctx.fillStyle = accentColor;
    ctx.fillRect(0, 0, 12, canvas.height);

    // Icon
    ctx.font = '120px sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillText(icon, canvas.width - 80, 200);

    // Wrap text (by word, falling back to hard character breaks for
    // single very-long words) so long titles never overflow the canvas.
    const wrapText = (text: string, font: string, maxWidth: number, maxLines: number): string[] => {
      ctx.font = font;
      const words = text.split(/\s+/).filter(Boolean);
      if (words.length === 0) return [];
      const lines: string[] = [];
      let current = '';
      for (const word of words) {
        const test = current ? `${current} ${word}` : word;
        if (ctx.measureText(test).width <= maxWidth || !current) {
          current = test;
        } else {
          lines.push(current);
          current = word;
        }
        if (lines.length === maxLines - 1 && current) {
          // Reserve the last line for whatever remains, truncated with an ellipsis.
          break;
        }
      }
      if (current) lines.push(current);
      if (lines.length > maxLines) lines.length = maxLines;
      const last = lines[lines.length - 1];
      if (last && ctx.measureText(last).width > maxWidth) {
        let truncated = last;
        while (truncated.length > 1 && ctx.measureText(truncated + '…').width > maxWidth) {
          truncated = truncated.slice(0, -1);
        }
        lines[lines.length - 1] = truncated + '…';
      }
      return lines;
    };

    // Title (up to 2 lines, growing upward from its baseline)
    const titleFont = `bold ${titleSize * 2}px sans-serif`;
    const titleLines = wrapText(title, titleFont, maxTextWidth, 2);
    ctx.fillStyle = textColor;
    ctx.font = titleFont;
    ctx.textAlign = 'right';
    ctx.textBaseline = 'bottom';
    const titleLineHeight = titleSize * 2.3;
    const titleBaseY = canvas.height - 120;
    titleLines.forEach((line, i) => {
      const y = titleBaseY - (titleLines.length - 1 - i) * titleLineHeight;
      ctx.fillText(line, canvas.width - 60, y);
    });

    // Subtitle (single line, truncated if needed)
    const subtitleFont = `${subtitleSize * 2}px sans-serif`;
    const subtitleLines = wrapText(subtitle, subtitleFont, maxTextWidth, 1);
    ctx.fillStyle = accentColor;
    ctx.font = subtitleFont;
    if (subtitleLines[0]) ctx.fillText(subtitleLines[0], canvas.width - 60, canvas.height - 50);

    // Bottom bar
    ctx.fillStyle = accentColor;
    ctx.globalAlpha = 0.3;
    ctx.fillRect(0, canvas.height - 8, canvas.width, 8);
    ctx.globalAlpha = 1;
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = 'thumbnail.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" /> بازگشت به ابزارها
      </Link>

      <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2 flex items-center gap-2">
        <ImageIcon className="w-6 h-6 text-orange-400" /> سازنده تصویر بندانگشتی
      </h1>
      <p className="text-slate-400 mb-8">برای ویدئوهای یوتیوب، تصویر بندانگشتی جذاب بساز</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Preview */}
        <div>
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
            <canvas ref={canvasRef} className="w-full rounded-lg" style={{ aspectRatio: '16/9' }} />
            <button
              onClick={handleDownload}
              className="w-full mt-4 flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-400 hover:to-red-500 text-white font-bold rounded-lg transition-all"
            >
              <Download className="w-5 h-5" /> دانلود تصویر
            </button>
          </div>
        </div>

        {/* Controls */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-1"><Type className="w-4 h-4" /> عنوان</label>
            <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">زیرعنوان</label>
            <input type="text" value={subtitle} onChange={(e) => setSubtitle(e.target.value)} className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500" />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-1"><Palette className="w-4 h-4" /> پس‌زمینه</label>
            <div className="grid grid-cols-4 gap-2">
              {BACKGROUNDS.map((bg, i) => (
                <button
                  key={bg.id}
                  onClick={() => setBgIndex(i)}
                  className={`h-12 rounded-lg border-2 transition-all ${bgIndex === i ? 'border-cyan-500 scale-105' : 'border-transparent'}`}
                  style={{ background: `linear-gradient(135deg, ${bg.colors[0]}, ${bg.colors[1]})` }}
                  title={bg.label}
                />
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-1"><Shapes className="w-4 h-4" /> آیکون</label>
            <div className="flex flex-wrap gap-2">
              {ICONS.map((ic) => (
                <button
                  key={ic}
                  onClick={() => setIcon(ic)}
                  className={`w-10 h-10 rounded-lg text-xl flex items-center justify-center border-2 transition-all ${icon === ic ? 'border-cyan-500 bg-cyan-500/10' : 'border-slate-700 bg-slate-800'}`}
                >
                  {ic}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm text-slate-300 mb-1">اندازه عنوان: {titleSize}</label>
              <input type="range" min="24" max="72" value={titleSize} onChange={(e) => setTitleSize(Number(e.target.value))} className="w-full accent-cyan-500" />
            </div>
            <div>
              <label className="block text-sm text-slate-300 mb-1">اندازه زیرعنوان: {subtitleSize}</label>
              <input type="range" min="14" max="36" value={subtitleSize} onChange={(e) => setSubtitleSize(Number(e.target.value))} className="w-full accent-cyan-500" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm text-slate-300 mb-1">رنگ متن</label>
              <input type="color" value={textColor} onChange={(e) => setTextColor(e.target.value)} className="w-full h-10 rounded-lg bg-slate-900 border border-slate-700 cursor-pointer" />
            </div>
            <div>
              <label className="block text-sm text-slate-300 mb-1">رنگ تاکیدی</label>
              <input type="color" value={accentColor} onChange={(e) => setAccentColor(e.target.value)} className="w-full h-10 rounded-lg bg-slate-900 border border-slate-700 cursor-pointer" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
