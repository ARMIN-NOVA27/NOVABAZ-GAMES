import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles, Loader2, Gamepad2, Wand2 } from 'lucide-react';
import { fetchGames, fetchFavoriteGameIds } from '@/lib/data';
import { useAuth } from '@/lib/auth';
import type { Game } from '@/lib/types';
import { formatRating } from '@/lib/utils';
import GameCard from '@/components/GameCard';
import { useSEO } from '@/lib/useSEO';

const ALL_GENRES = ['Action', 'RPG', 'Strategy', 'Adventure', 'Shooter', 'Simulation', 'Sports', 'Racing', 'Horror', 'Puzzle', 'Open World', 'MMO'];
const ALL_PLATFORMS = ['PC', 'PlayStation', 'Xbox', 'Nintendo Switch', 'Mobile'];

export default function GameRecommender() {
  useSEO({ title: 'پیشنهاد بازی', description: 'بر اساس سلیقه و سیستمت، بازی مناسب پیدا کن' });
  const { user } = useAuth();
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [favoriteIds, setFavoriteIds] = useState<string[]>([]);
  const [suggestedGenres, setSuggestedGenres] = useState<string[]>([]);
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [minRating, setMinRating] = useState(0);
  const [maxStorage, setMaxStorage] = useState<string>('');
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    fetchGames().then(setGames).catch(() => setError(true)).finally(() => setLoading(false));
  }, []);

  // Real personalization: derive the user's most-favorited genres from
  // their actual favorites, once games are loaded.
  useEffect(() => {
    if (!user || games.length === 0) return;
    fetchFavoriteGameIds(user.id).then((ids) => {
      setFavoriteIds(ids);
      const favGames = games.filter((g) => ids.includes(g.id));
      const counts: Record<string, number> = {};
      favGames.forEach((g) => g.genres.forEach((genre) => { counts[genre] = (counts[genre] || 0) + 1; }));
      const top = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([g]) => g);
      setSuggestedGenres(top);
    }).catch(() => {});
  }, [user, games]);

  const toggleGenre = (g: string) => {
    setSelectedGenres((prev) => prev.includes(g) ? prev.filter((x) => x !== g) : [...prev, g]);
  };
  const togglePlatform = (p: string) => {
    setSelectedPlatforms((prev) => prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]);
  };
  const applySuggestedGenres = () => setSelectedGenres(suggestedGenres);

  // Score-based ranking with explainability: every selected preference
  // adds to a game's score AND records *why* it matched, so results are
  // never a black box. Games with zero real matches are kept separate
  // from the ranked list instead of padding it with unrelated titles.
  const { matched, fallback } = useMemo(() => {
    if (!searched) return { matched: [], fallback: [] };
    const maxStorageNum = maxStorage ? parseInt(maxStorage) : null;
    const hasAnyFilter = selectedGenres.length > 0 || selectedPlatforms.length > 0 || minRating > 0 || !!maxStorageNum;

    const scored = games
      .filter((g) => !favoriteIds.includes(g.id)) // don't recommend what they already favorited
      .map((game) => {
        let score = 0;
        const reasons: string[] = [];

        if (selectedGenres.length > 0) {
          const genreMatches = game.genres.filter((x) => selectedGenres.includes(x));
          if (genreMatches.length > 0) {
            score += genreMatches.length * 3;
            reasons.push(...genreMatches);
          }
        }
        if (selectedPlatforms.length > 0) {
          const platformMatches = game.platforms.filter((x) => selectedPlatforms.includes(x));
          if (platformMatches.length > 0) {
            score += 2;
            reasons.push(...platformMatches);
          }
        }
        if (minRating > 0 && game.rating >= minRating) {
          score += 2;
          reasons.push(`امتیاز ${formatRating(game.rating)}+`);
        }
        if (maxStorageNum) {
          const storage = parseInt((game.min_storage || '').replace(/[^0-9]/g, '') || '0');
          if (storage > 0 && storage <= maxStorageNum) {
            score += 1;
            reasons.push(`فضای کم (${storage} گیگ)`);
          } else if (storage > maxStorageNum) {
            score -= 5; // clearly too big for their system — push firmly down
          }
        }
        score += game.rating * 0.3; // slight overall-quality tiebreaker, never the main driver

        return { game, score, reasons: [...new Set(reasons)] };
      })
      .sort((a, b) => b.score - a.score);

    // A "real" match is one that actually satisfied at least one thing
    // the user asked for (has a reason), not just the quality tiebreaker.
    const realMatches = scored.filter((s) => s.reasons.length > 0).slice(0, 8);

    if (!hasAnyFilter) {
      // No filters selected at all: honest top-rated fallback, clearly labeled as such.
      return { matched: [], fallback: scored.slice(0, 8).map((s) => s.game) };
    }

    return { matched: realMatches, fallback: [] };
  }, [searched, games, selectedGenres, selectedPlatforms, minRating, maxStorage, favoriteIds]);

  if (loading) {
    return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 text-cyan-500 animate-spin" /></div>;
  }
  if (error) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center text-rose-400">
        خطا در بارگذاری بازی‌ها. لطفاً صفحه را رفرش کنید.
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" /> بازگشت به ابزارها
      </Link>

      <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2 flex items-center gap-2">
        <Sparkles className="w-6 h-6 text-cyan-400" /> پیشنهاد بازی
      </h1>
      <p className="text-slate-400 mb-8">بر اساس سلیقه و سیستمت، بازی مناسب پیدا کن</p>

      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50 space-y-6">
        {suggestedGenres.length > 0 && (
          <button
            onClick={applySuggestedGenres}
            className="flex items-center gap-2 px-4 py-2 bg-violet-500/10 border border-violet-500/30 text-violet-300 rounded-lg text-sm hover:bg-violet-500/20 transition-colors"
          >
            <Wand2 className="w-4 h-4" />
            بر اساس بازی‌های موردعلاقه‌ات: {suggestedGenres.join('، ')}
          </button>
        )}

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-3">ژانرهای موردعلاقه</label>
          <div className="flex flex-wrap gap-2">
            {ALL_GENRES.map((g) => (
              <button
                key={g}
                onClick={() => toggleGenre(g)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  selectedGenres.includes(g)
                    ? 'bg-cyan-500 text-white'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-300 border border-slate-700'
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-3">پلتفرم</label>
          <div className="flex flex-wrap gap-2">
            {ALL_PLATFORMS.map((p) => (
              <button
                key={p}
                onClick={() => togglePlatform(p)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  selectedPlatforms.includes(p)
                    ? 'bg-cyan-500 text-white'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-300 border border-slate-700'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">حداقل امتیاز: {minRating}</label>
            <input type="range" min="0" max="5" step="0.5" value={minRating} onChange={(e) => setMinRating(Number(e.target.value))} className="w-full accent-cyan-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">حداکثر فضای ذخیره (GB)</label>
            <input type="number" value={maxStorage} onChange={(e) => setMaxStorage(e.target.value)} placeholder="مثلاً 50" className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500" />
          </div>
        </div>

        <button
          onClick={() => setSearched(true)}
          className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl transition-all"
        >
          <Gamepad2 className="w-5 h-5" /> پیشنهاد بازی
        </button>
      </div>

      {searched && (
        <div className="mt-8">
          {matched.length > 0 ? (
            <>
              <h2 className="text-lg font-bold text-white mb-4">{matched.length} بازی پیشنهادی بر اساس انتخاب‌های تو</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {matched.map(({ game, reasons }) => (
                  <div key={game.id}>
                    <GameCard game={game} />
                    {reasons.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {reasons.slice(0, 3).map((r) => (
                          <span key={r} className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                            {r}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          ) : fallback.length > 0 ? (
            <>
              <h2 className="text-lg font-bold text-white mb-1">بهترین بازی‌های کاتالوگ</h2>
              <p className="text-slate-500 text-sm mb-4">فیلتری انتخاب نکردی، پس بر اساس بالاترین امتیازها نشونت می‌دیم.</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {fallback.map((g) => <GameCard key={g.id} game={g} />)}
              </div>
            </>
          ) : (
            <>
              <h2 className="text-lg font-bold text-white mb-4">بازی‌ای دقیقاً مطابق انتخاب‌هات پیدا نشد</h2>
              <p className="text-slate-400 text-center py-8">فیلترها را کمی بازتر کن (مثلاً امتیاز حداقل یا ژانر کمتری انتخاب کن) و دوباره امتحان کن.</p>
            </>
          )}
        </div>
      )}
    </div>
  );
}
