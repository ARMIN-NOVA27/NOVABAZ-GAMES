import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Cpu, Monitor, MemoryStick, HardDrive, Tv, Check, X, Gamepad2 } from 'lucide-react';
import { fetchGames } from '@/lib/data';
import type { Game } from '@/lib/types';
import { useSEO } from '@/lib/useSEO';

interface SystemInput {
  cpu: string;
  gpu: string;
  ram: string;
  storage: string;
  os: string;
}

function parseRam(ram: string): number {
  const match = ram.match(/(\d+)/);
  return match ? parseInt(match[1], 10) : 0;
}

function canRunGame(game: Game, sys: SystemInput): { canRun: boolean; meetsRecommended: boolean } {
  const sysRam = parseRam(sys.ram);
  const minRam = parseRam(game.min_ram || '');
  const recRam = parseRam(game.rec_ram || '');

  const minStorage = parseRam(game.min_storage || '');

  const meetsMinRam = sysRam >= minRam;
  const meetsRecRam = recRam > 0 ? sysRam >= recRam : sysRam >= minRam;

  const hasStorage = sys.storage === '' || minStorage === 0 || parseRam(sys.storage) >= minStorage;

  const meetsMin = meetsMinRam && hasStorage;
  const meetsRec = meetsRecRam && hasStorage;

  return { canRun: meetsMin, meetsRecommended: meetsRec };
}

export default function SystemCheck() {
  useSEO({ title: 'بررسی سیستم و پیشنهاد بازی', description: 'سیستم خود را وارد کن و بازی‌های مناسب بگیر' });
  const [games, setGames] = useState<Game[]>([]);
  const [gamesLoading, setGamesLoading] = useState(true);
  const [gamesError, setGamesError] = useState(false);
  const [sys, setSys] = useState<SystemInput>({ cpu: '', gpu: '', ram: '', storage: '', os: '' });
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    fetchGames()
      .then(setGames)
      .catch(() => setGamesError(true))
      .finally(() => setGamesLoading(false));
  }, []);

  const handleCheck = (e: React.FormEvent) => {
    e.preventDefault();
    setChecked(true);
  };

  const runnable = games
    .map((g) => ({ game: g, ...canRunGame(g, sys) }))
    .filter((x) => x.canRun)
    .sort((a, b) => (b.meetsRecommended ? 1 : 0) - (a.meetsRecommended ? 1 : 0));

  const fields = [
    { key: 'cpu' as const, label: 'پردازنده (CPU)', placeholder: 'مثلاً Intel Core i5-10400', icon: Cpu },
    { key: 'gpu' as const, label: 'کارت گرافیک (GPU)', placeholder: 'مثلاً NVIDIA GTX 1660', icon: Monitor },
    { key: 'ram' as const, label: 'حافظه (RAM)', placeholder: 'مثلاً 16 GB', icon: MemoryStick },
    { key: 'storage' as const, label: 'فضا (اختیاری)', placeholder: 'مثلاً 500 GB SSD', icon: HardDrive },
    { key: 'os' as const, label: 'سیستم‌عامل (اختیاری)', placeholder: 'مثلاً Windows 11', icon: Tv },
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" /> بازگشت به ابزارها
      </Link>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-rose-500 to-red-600 flex items-center justify-center">
          <Cpu className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">بررسی سیستم و پیشنهاد بازی</h1>
          <p className="text-slate-400 text-sm">سیستم خود را وارد کن تا بازی‌های مناسب بگیری</p>
        </div>
      </div>

      <form onSubmit={handleCheck} className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50 space-y-4">
        {fields.map((field) => {
          const Icon = field.icon;
          return (
            <div key={field.key}>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                <span className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-slate-500" />
                  {field.label}
                </span>
              </label>
              <input
                type="text"
                value={sys[field.key]}
                onChange={(e) => setSys({ ...sys, [field.key]: e.target.value })}
                placeholder={field.placeholder}
                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
              />
            </div>
          );
        })}
        {gamesError && (
          <p className="text-rose-400 text-sm bg-rose-500/10 border border-rose-500/30 rounded-lg p-3">
            خطا در بارگذاری لیست بازی‌ها. لطفاً صفحه را رفرش کنید.
          </p>
        )}
        <button
          type="submit"
          disabled={gamesLoading || gamesError}
          className="w-full flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-rose-500 to-red-600 hover:from-rose-400 hover:to-red-500 text-white font-bold rounded-xl transition-all disabled:opacity-50"
        >
          <Gamepad2 className="w-5 h-5" />
          {gamesLoading ? 'در حال بارگذاری بازی‌ها...' : 'بررسی و پیشنهاد بازی'}
        </button>
      </form>

      {checked && (
        <div className="mt-8">
          {/* System assessment */}
          {runnable.length > 0 && (() => {
            const recCount = runnable.filter((r) => r.meetsRecommended).length;
            const ratio = recCount / runnable.length;
            let tier: { label: string; color: string; desc: string };
            if (ratio >= 0.7) {
              tier = { label: 'سیستم قدرتمند', color: 'from-emerald-500 to-green-600', desc: 'سیستم شما می‌تواند اکثر بازی‌ها با بالاترین کیفیت اجرا کند.' };
            } else if (ratio >= 0.4) {
              tier = { label: 'سیستم متوسط', color: 'from-cyan-500 to-blue-600', desc: 'سیستم شما برای اکثر بازی‌ها مناسب است، اما شاید برای برخی نیاز به کاهش تنظیمات داشته باشید.' };
            } else if (runnable.length > 0) {
              tier = { label: 'سیستم پایه', color: 'from-amber-500 to-orange-600', desc: 'سیستم شما می‌تواند بازی‌های سبک‌تر را اجرا کند، اما برای بازی‌های سنگین‌تر ارتقا لازم است.' };
            } else {
              tier = { label: 'سیستم ضعیف', color: 'from-rose-500 to-red-600', desc: 'با اطلاعات واردشده، بازی‌ای قابل اجرا نیست. RAM را بررسی کنید.' };
            }
            return (
              <div className={`bg-gradient-to-r ${tier.color} rounded-xl p-5 mb-6`}>
                <h3 className="text-white font-bold text-lg">{tier.label}</h3>
                <p className="text-white/80 text-sm mt-1">{tier.desc}</p>
                <p className="text-white/60 text-xs mt-2">{recCount} از {runnable.length} بازی با تنظیمات پیشنهادی قابل اجرا</p>
              </div>
            );
          })()}

          <h2 className="text-lg font-bold text-white mb-4">
            بازی‌های قابل‌اجرا روی سیستم شما ({runnable.length} بازی)
          </h2>
          {runnable.length === 0 ? (
            <p className="text-slate-400 text-center py-8 bg-slate-800/30 rounded-xl">
              با اطلاعات واردشده بازی‌ای یافت نشد. لطفاً RAM را حتماً وارد کنید.
            </p>
          ) : (
            <div className="space-y-2">
              {runnable.map(({ game, meetsRecommended }) => (
                <div
                  key={game.id}
                  className="flex items-center gap-3 bg-slate-800/50 rounded-xl p-3 border border-slate-700/50"
                >
                  <div className="w-10 h-10 rounded-lg overflow-hidden bg-slate-900 flex-shrink-0">
                    {game.cover_url && <img src={game.cover_url} alt={game.title} className="w-full h-full object-cover" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-medium truncate">{game.title_fa || game.title}</p>
                    <p className="text-xs text-slate-500">حداقل RAM: {game.min_ram}</p>
                  </div>
                  {meetsRecommended ? (
                    <span className="flex items-center gap-1 px-2.5 py-1 bg-emerald-500/10 text-emerald-400 text-xs rounded-full">
                      <Check className="w-3 h-3" />
                      پیشنهادی
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 px-2.5 py-1 bg-amber-500/10 text-amber-400 text-xs rounded-full">
                      <X className="w-3 h-3" />
                      حداقل
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
