import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, FileText, Sparkles, Copy, Check } from 'lucide-react';
import { generateBios, type BioInput } from '@/lib/bioData';
import { copyToClipboard } from '@/lib/utils';
import { useSEO } from '@/lib/useSEO';

const PLATFORMS = ['PC', 'PlayStation', 'Xbox', 'Nintendo Switch', 'Mobile'];

export default function BioGenerator() {
  useSEO({ title: 'سازنده بیو گیمینگ', description: 'با چند اطلاعات ساده، بیوهای جذاب گیمینگ بساز' });
  const [input, setInput] = useState<BioInput>({
    gamingName: '',
    favoriteGame: '',
    platform: 'PC',
    playStyle: '',
  });
  const [bios, setBios] = useState<string[]>([]);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const [error, setError] = useState('');

  const generate = () => {
    if (!input.gamingName.trim() || !input.favoriteGame.trim()) {
      setError('نام گیمینگ و بازی محبوب را وارد کنید.');
      return;
    }
    setError('');
    setBios(generateBios(input));
    setCopiedIdx(null);
  };

  const handleCopy = async (bio: string, idx: number) => {
    const ok = await copyToClipboard(bio);
    if (ok) {
      setCopiedIdx(idx);
      setTimeout(() => setCopiedIdx(null), 2000);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" /> بازگشت به ابزارها
      </Link>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 flex items-center justify-center">
          <FileText className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">سازنده بیو گیمینگ</h1>
          <p className="text-slate-400 text-sm">با چند اطلاعات ساده، بیوهای جذاب بساز</p>
        </div>
      </div>

      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50 space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">نام گیمینگ</label>
          <input
            type="text"
            value={input.gamingName}
            onChange={(e) => setInput({ ...input, gamingName: e.target.value })}
            placeholder="مثلاً ShadowHunter"
            className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">بازی محبوب</label>
          <input
            type="text"
            value={input.favoriteGame}
            onChange={(e) => setInput({ ...input, favoriteGame: e.target.value })}
            placeholder="مثلاً Valorant"
            className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">پلتفرم</label>
            <select
              value={input.platform}
              onChange={(e) => setInput({ ...input, platform: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
            >
              {PLATFORMS.map((p) => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">سبک بازی (اختیاری)</label>
            <input
              type="text"
              value={input.playStyle}
              onChange={(e) => setInput({ ...input, playStyle: e.target.value })}
              placeholder="مثلاً حمله‌گر"
              className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {error && <p className="text-rose-400 text-sm">{error}</p>}

        <button
          onClick={generate}
          className="w-full flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white font-bold rounded-xl transition-all"
        >
          <Sparkles className="w-5 h-5" />
          بیو تولید کن
        </button>
      </div>

      {bios.length > 0 && (
        <div className="mt-6 space-y-3">
          {bios.map((bio, i) => (
            <div
              key={i}
              className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50 animate-fadeIn"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className="flex items-start justify-between gap-3">
                <p className="text-slate-200 leading-relaxed whitespace-pre-line flex-1">{bio}</p>
                <button
                  onClick={() => handleCopy(bio, i)}
                  className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 transition-colors flex-shrink-0"
                  aria-label="کپی"
                >
                  {copiedIdx === i ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
