import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, MousePointer2 } from 'lucide-react';
import { useSEO } from '@/lib/useSEO';

export default function DpiCalculator() {
  useSEO({ title: 'محاسبه DPI / eDPI', description: 'محاسبه دقیق DPI، eDPI و تبدیل حساسیت بین بازی‌ها' });

  const [dpi, setDpi] = useState(800);
  const [sensitivity, setSensitivity] = useState(1.0);
  const [fromGame, setFromGame] = useState('Valorant');
  const [fromSens, setFromSens] = useState(0.4);
  const [toGame, setToGame] = useState('CS2');

  const edpi = useMemo(() => Math.round(dpi * sensitivity * 100) / 100, [dpi, sensitivity]);

  const presets = [
    { game: 'Valorant', sens: 0.4 },
    { game: 'CS2', sens: 1.0 },
    { game: 'Apex Legends', sens: 1.0 },
    { game: 'Fortnite', sens: 0.07 },
  ];

  const GAME_YAW = {
    'Valorant': 0.07,
    'CS2': 0.022,
    'Apex Legends': 0.022,
    'Fortnite': 0.5555,
    'Overwatch 2': 0.0066,
    'PUBG': 0.0066,
    'Rainbow Six Siege': 0.00572957795,
    'Call of Duty': 0.0066,
  };

  const fromYaw = GAME_YAW[fromGame as keyof typeof GAME_YAW] || 0.022;
  const toYaw = GAME_YAW[toGame as keyof typeof GAME_YAW] || 0.022;
  const convertedSens = useMemo(
    () => Math.round((fromSens * fromYaw / toYaw) * 10000) / 10000,
    [fromSens, fromYaw, toYaw]
  );

  const cmPer360 = useMemo(
    () => Math.round((360 / (dpi * convertedSens * toYaw)) * 2.54 * 10) / 10,
    [dpi, convertedSens, toYaw]
  );

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" /> بازگشت به ابزارها
      </Link>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
          <MousePointer2 className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">محاسبه DPI / eDPI</h1>
          <p className="text-slate-400 text-sm">eDPI = DPI × حساسیت</p>
        </div>
      </div>

      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50 space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">DPI موس: {dpi}</label>
          <input
            type="range"
            min={100}
            max={3200}
            step={50}
            value={dpi}
            onChange={(e) => setDpi(Number(e.target.value))}
            className="w-full accent-violet-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">حساسیت بازی: {sensitivity}</label>
          <input
            type="range"
            min={0.01}
            max={5}
            step={0.01}
            value={sensitivity}
            onChange={(e) => setSensitivity(Number(e.target.value))}
            className="w-full accent-violet-500"
          />
        </div>

        <div className="text-center bg-slate-900 rounded-xl p-6">
          <p className="text-slate-400 text-sm mb-1">eDPI شما</p>
          <p className="text-4xl font-extrabold text-violet-400">{edpi}</p>
        </div>

        <div>
          <h3 className="text-sm font-medium text-slate-300 mb-3">پیش‌تنظیم‌های بازی</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {presets.map((p) => (
              <button
                key={p.game}
                onClick={() => setSensitivity(p.sens)}
                className="px-3 py-2 bg-slate-900 hover:bg-slate-700 rounded-lg text-sm text-slate-300 transition-colors"
              >
                {p.game}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50 mt-6">
        <h2 className="text-lg font-bold text-white mb-4">تبدیل حساسیت بین بازی‌ها</h2>
        <p className="text-slate-400 text-sm mb-4">حساسیت یک بازی را وارد کن تا معادل آن در بازی دیگر را بگیری. cm/360 نیز محاسبه می‌شود.</p>
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-slate-300 mb-1">از بازی</label>
              <select value={fromGame} onChange={(e) => setFromGame(e.target.value)} className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-violet-500">
                {Object.keys(GAME_YAW).map((g) => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-slate-300 mb-1">حساسیت فعلی</label>
              <input type="number" step="0.01" value={fromSens} onChange={(e) => setFromSens(Number(e.target.value))} className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-violet-500" />
            </div>
          </div>
          <div>
            <label className="block text-sm text-slate-300 mb-1">به بازی</label>
            <select value={toGame} onChange={(e) => setToGame(e.target.value)} className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-violet-500">
              {Object.keys(GAME_YAW).map((g) => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-900 rounded-xl p-4 text-center">
              <p className="text-slate-400 text-xs mb-1">حساسیت جدید</p>
              <p className="text-2xl font-bold text-violet-400">{convertedSens}</p>
            </div>
            <div className="bg-slate-900 rounded-xl p-4 text-center">
              <p className="text-slate-400 text-xs mb-1">cm/360</p>
              <p className="text-2xl font-bold text-violet-400">{cmPer360} cm</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
