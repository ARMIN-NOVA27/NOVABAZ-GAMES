import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Gauge } from 'lucide-react';
import { useSEO } from '@/lib/useSEO';

export default function FpsConverter() {
  useSEO({ title: 'ابزار FPS', description: 'تبدیل فریم‌ریت و محاسبه زمان فریم و بودجه رندرینگ' });

  const [fps, setFps] = useState(60);

  const frameTime = useMemo(() => (1000 / fps).toFixed(2), [fps]);
  const frameBudget = useMemo(() => {
    const target = 1000 / fps;
    return {
      render: (target * 0.5).toFixed(2),
      cpu: (target * 0.3).toFixed(2),
      other: (target * 0.2).toFixed(2),
    };
  }, [fps]);

  const presets = [30, 60, 120, 144, 165, 240, 360];

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" /> بازگشت به ابزارها
      </Link>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-fuchsia-500 to-pink-600 flex items-center justify-center">
          <Gauge className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">ابزار FPS</h1>
          <p className="text-slate-400 text-sm">تبدیل فریم‌ریت و محاسبه زمان فریم</p>
        </div>
      </div>

      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50 space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-3">FPS هدف: {fps}</label>
          <div className="flex flex-wrap gap-2 mb-4">
            {presets.map((p) => (
              <button
                key={p}
                onClick={() => setFps(p)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  fps === p
                    ? 'bg-gradient-to-r from-fuchsia-500 to-pink-600 text-white'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {p} FPS
              </button>
            ))}
          </div>
          <input
            type="range"
            min={15}
            max={500}
            step={1}
            value={fps}
            onChange={(e) => setFps(Number(e.target.value))}
            className="w-full accent-fuchsia-500"
          />
        </div>

        <div className="text-center bg-slate-900 rounded-xl p-6">
          <p className="text-slate-400 text-sm mb-1">زمان هر فریم</p>
          <p className="text-4xl font-extrabold text-fuchsia-400">{frameTime} <span className="text-lg text-slate-500">ms</span></p>
        </div>

        <div>
          <h3 className="text-sm font-medium text-slate-300 mb-3">بودجه زمانی فریم (تقسیم پیشنهادی)</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between bg-slate-900 rounded-lg px-4 py-2.5">
              <span className="text-slate-400 text-sm">رندر (GPU)</span>
              <span className="text-white font-mono">{frameBudget.render} ms</span>
            </div>
            <div className="flex items-center justify-between bg-slate-900 rounded-lg px-4 py-2.5">
              <span className="text-slate-400 text-sm">پردازش (CPU)</span>
              <span className="text-white font-mono">{frameBudget.cpu} ms</span>
            </div>
            <div className="flex items-center justify-between bg-slate-900 rounded-lg px-4 py-2.5">
              <span className="text-slate-400 text-sm">سایر</span>
              <span className="text-white font-mono">{frameBudget.other} ms</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/50 rounded-xl p-5 border border-slate-700/30">
          <h3 className="text-sm font-bold text-white mb-3">آموزش: فریم‌ریت و زمان فریم</h3>
          <div className="space-y-2 text-sm text-slate-400 leading-relaxed">
            <p>FPS (فریم بر ثانیه) تعداد تصاویری است که کارت گرافیک در هر ثانیه تولید می‌کند. هرچه FPS بالاتر، حرکت روان‌تر.</p>
            <p>زمان فریم (Frame Time) مدت زمان تولید هر فریم است: <span className="text-fuchsia-400 font-mono">1000 ÷ FPS = میلی‌ثانیه</span></p>
            <p>برای ۶۰ FPS، هر فریم باید در ۱۶.۶۷ ms رندر شود. اگر بیشتر طول بکشد، افت فریم (stutter) اتفاق می‌افتد.</p>
            <p>برای ۱۴۴ FPS، این زمان به ۶.۹۴ ms می‌رسد — یعنی GPU و CPU باید بیش از دو برابر سریع‌تر کار کنند.</p>
            <p>بودجه رندرینگ: ~۵۰٪ GPU، ~۳۰٪ CPU، ~۲۰٪ سایر (ورودی، صدا، فیزیک). این تقسیم تقریبی است و بسته به بازی متفاوت می‌شود.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
