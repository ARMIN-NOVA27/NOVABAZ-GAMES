import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Download } from 'lucide-react';
import { useSEO } from '@/lib/useSEO';

export default function DownloadTime() {
  useSEO({ title: 'محاسبه زمان دانلود', description: 'زمان دانلود بازی‌ها را بر اساس حجم و سرعت اینترنت محاسبه کن' });

  const [size, setSize] = useState(50);
  const [speed, setSpeed] = useState(10);

  const time = useMemo(() => {
    const sizeMB = size * 1024;
    const speedMBps = speed / 8;
    const seconds = sizeMB / speedMBps;
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.round(seconds % 60);
    return { hrs, mins, secs, total: seconds };
  }, [size, speed]);

  const formatTime = (t: { hrs: number; mins: number; secs: number }) =>
    [t.hrs > 0 ? `${t.hrs} ساعت` : null, t.mins > 0 ? `${t.mins} دقیقه` : null, `${t.secs} ثانیه`]
      .filter(Boolean)
      .join(' و ');

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" /> بازگشت به ابزارها
      </Link>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center">
          <Download className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">محاسبه زمان دانلود</h1>
          <p className="text-slate-400 text-sm">زمان دانلود را بر اساس حجم و سرعت محاسبه کن</p>
        </div>
      </div>

      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50 space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">حجم بازی: {size} GB</label>
          <input
            type="range"
            min={1}
            max={500}
            step={1}
            value={size}
            onChange={(e) => setSize(Number(e.target.value))}
            className="w-full accent-sky-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">سرعت اینترنت: {speed} Mbps</label>
          <input
            type="range"
            min={1}
            max={1000}
            step={1}
            value={speed}
            onChange={(e) => setSpeed(Number(e.target.value))}
            className="w-full accent-sky-500"
          />
        </div>

        <div className="text-center bg-slate-900 rounded-xl p-6">
          <p className="text-slate-400 text-sm mb-1">زمان تخمینی دانلود</p>
          <p className="text-3xl font-extrabold text-sky-400">{formatTime(time)}</p>
          <p className="text-slate-500 text-sm mt-2">سرعت واقعی: {(speed / 8).toFixed(1)} MB/s</p>
        </div>

        <div className="bg-slate-900/50 rounded-xl p-5 border border-slate-700/30">
          <h3 className="text-sm font-bold text-white mb-3">Mbps در برابر MB/s — چه فرقی دارند؟</h3>
          <div className="space-y-2 text-sm text-slate-400 leading-relaxed">
            <p>ISPها سرعت اینترنت را با <span className="text-sky-400 font-bold">Mbps</span> (مگابیت بر ثانیه) اعلام می‌کنند، اما دانلود منیجرها سرعت را با <span className="text-sky-400 font-bold">MB/s</span> (مگابایت بر ثانیه) نشان می‌دهند.</p>
            <p>هر بایت ۸ بیت است. پس: <span className="text-sky-400 font-mono">MB/s = Mbps ÷ 8</span></p>
            <p>مثال: اینترنت ۱۰۰ Mbps در واقع ۱۲.۵ MB/s سرعت دانلود دارد.</p>
            <p>این یعنی یک بازی ۱۰۰ گیگابایتی با اینترنت ۱۰۰ Mbps حدود <span className="text-sky-400 font-bold">۲ ساعت و ۱۶ دقیقه</span> طول می‌کشد — نه ۱۷ دقیقه!</p>
          </div>
        </div>
      </div>
    </div>
  );
}
