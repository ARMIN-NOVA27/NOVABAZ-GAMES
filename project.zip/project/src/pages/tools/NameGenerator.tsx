import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Type, RefreshCw, Copy, Check } from 'lucide-react';
import { NAME_CONFIGS, generateNames } from '@/lib/nameData';
import { copyToClipboard } from '@/lib/utils';
import { useSEO } from '@/lib/useSEO';

export default function NameGenerator() {
  useSEO({ title: 'سازنده اسم گیمینگ', description: 'اسم گیمینگ، تیم، کلن، روبلاکس و دیسکورد بساز' });
  const [selected, setSelected] = useState(NAME_CONFIGS[0].key);
  const [names, setNames] = useState<string[]>([]);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const generate = () => {
    setNames(generateNames(selected, 8));
    setCopiedIdx(null);
  };

  const handleCopy = async (name: string, idx: number) => {
    const ok = await copyToClipboard(name);
    if (ok) {
      setCopiedIdx(idx);
      setTimeout(() => setCopiedIdx(null), 2000);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" /> بازگشت به ابزارها
      </Link>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
          <Type className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">سازنده اسم گیمینگ</h1>
          <p className="text-slate-400 text-sm">اسم گیمینگ، تیم، کلن و بیشتر بساز</p>
        </div>
      </div>

      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50">
        <label className="block text-sm font-medium text-slate-300 mb-3">نوع اسم</label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
          {NAME_CONFIGS.map((c) => (
            <button
              key={c.key}
              onClick={() => setSelected(c.key)}
              className={`px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                selected === c.key
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        <button
          onClick={generate}
          className="w-full flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl transition-all"
        >
          <RefreshCw className="w-5 h-5" />
          اسم تولید کن
        </button>
      </div>

      {names.length > 0 && (
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {names.map((name, i) => (
            <div
              key={i}
              className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50 flex items-center justify-between gap-3 animate-fadeIn"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <span className="text-white font-bold font-mono">{name}</span>
              <button
                onClick={() => handleCopy(name, i)}
                className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 transition-colors"
                aria-label="کپی"
              >
                {copiedIdx === i ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
