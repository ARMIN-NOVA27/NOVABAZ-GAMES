import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ArrowLeftRight } from 'lucide-react';
import { useSEO } from '@/lib/useSEO';

type UnitType = 'storage' | 'speed' | 'resolution';

const UNIT_GROUPS: Record<UnitType, { key: string; label: string; toBase: number }[]> = {
  storage: [
    { key: 'bit', label: 'بیت (bit)', toBase: 0.00000011920929 },
    { key: 'kb', label: 'کیلوبایت (KB)', toBase: 0.0009765625 },
    { key: 'mb', label: 'مگابایت (MB)', toBase: 1 },
    { key: 'gb', label: 'گیگابایت (GB)', toBase: 1024 },
    { key: 'tb', label: 'ترابایت (TB)', toBase: 1024 * 1024 },
  ],
  speed: [
    { key: 'kbps', label: 'Kbps (کیلوبیت/ث)', toBase: 0.001 },
    { key: 'mbps', label: 'Mbps (مگابیت/ث)', toBase: 1 },
    { key: 'gbps', label: 'Gbps (گیگابیت/ث)', toBase: 1000 },
    { key: 'mbps_dl', label: 'MB/s (مگابایت/ث)', toBase: 8 },
    { key: 'gbps_dl', label: 'GB/s (گیگابایت/ث)', toBase: 8000 },
  ],
  resolution: [
    { key: '720p', label: 'HD 720p (1280×720)', toBase: 921600 },
    { key: '1080p', label: 'Full HD 1080p (1920×1080)', toBase: 2073600 },
    { key: '1440p', label: 'QHD 1440p (2560×1440)', toBase: 3686400 },
    { key: '4k', label: '4K UHD (3840×2160)', toBase: 8294400 },
    { key: '8k', label: '8K (7680×4320)', toBase: 33177600 },
  ],
};

const TYPE_LABELS: Record<UnitType, string> = {
  storage: 'حجم دیجیتال',
  speed: 'سرعت اینترنت',
  resolution: 'رزولوشن تصویر',
};

export default function UnitConverter() {
  useSEO({ title: 'تبدیل واحدهای گیمینگ', description: 'تبدیل واحدهای حجم، سرعت اینترنت و رزولوشن تصویر' });

  const [type, setType] = useState<UnitType>('storage');
  const [value, setValue] = useState(1);
  const [from, setFrom] = useState('gb');
  const [to, setTo] = useState('mb');

  const units = UNIT_GROUPS[type];

  const result = useMemo(() => {
    const fromUnit = units.find((u) => u.key === from);
    const toUnit = units.find((u) => u.key === to);
    if (!fromUnit || !toUnit) return 0;
    const inBase = value * fromUnit.toBase;
    return inBase / toUnit.toBase;
  }, [value, from, to, units]);

  const swap = () => {
    setFrom(to);
    setTo(from);
  };

  const handleTypeChange = (newType: UnitType) => {
    setType(newType);
    const newUnits = UNIT_GROUPS[newType];
    setFrom(newUnits[0].key);
    setTo(newUnits[1]?.key || newUnits[0].key);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" /> بازگشت به ابزارها
      </Link>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center">
          <ArrowLeftRight className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">تبدیل واحدهای گیمینگ</h1>
          <p className="text-slate-400 text-sm">حجم، سرعت اینترنت و رزولوشن</p>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        {(Object.keys(UNIT_GROUPS) as UnitType[]).map((t) => (
          <button
            key={t}
            onClick={() => handleTypeChange(t)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              type === t ? 'bg-teal-500 text-white' : 'bg-slate-800 text-slate-400 hover:text-slate-300 border border-slate-700'
            }`}
          >
            {TYPE_LABELS[t]}
          </button>
        ))}
      </div>

      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50 space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">مقدار</label>
          <input
            type="number"
            value={value}
            onChange={(e) => setValue(Number(e.target.value))}
            className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">از</label>
            <select
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-500"
            >
              {units.map((u) => (
                <option key={u.key} value={u.key}>{u.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">به</label>
            <select
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-500"
            >
              {units.map((u) => (
                <option key={u.key} value={u.key}>{u.label}</option>
              ))}
            </select>
          </div>
        </div>

        <button
          onClick={swap}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors text-sm"
        >
          <ArrowLeftRight className="w-4 h-4" />
          جابجا کردن
        </button>

        <div className="text-center bg-slate-900 rounded-xl p-6">
          <p className="text-slate-400 text-sm mb-1">نتیجه</p>
          <p className="text-3xl font-extrabold text-teal-400">
            {result.toLocaleString('en-US', { maximumFractionDigits: 4 })}
          </p>
          <p className="text-slate-500 text-sm mt-1">{units.find((u) => u.key === to)?.label}</p>
        </div>
      </div>
    </div>
  );
}
