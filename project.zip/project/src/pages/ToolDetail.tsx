import { useParams, Navigate } from 'react-router-dom';
import IdeaGenerator from './tools/IdeaGenerator';
import NameGenerator from './tools/NameGenerator';
import BioGenerator from './tools/BioGenerator';
import SystemCheck from './tools/SystemCheck';
import DpiCalculator from './tools/DpiCalculator';
import DownloadTime from './tools/DownloadTime';
import FpsConverter from './tools/FpsConverter';
import UnitConverter from './tools/UnitConverter';
import ThumbnailMaker from './tools/ThumbnailMaker';
import GameRecommender from './tools/GameRecommender';

const TOOL_ROUTES: Record<string, React.ComponentType> = {
  'idea-generator': IdeaGenerator,
  'name-generator': NameGenerator,
  'bio-generator': BioGenerator,
  'system-check': SystemCheck,
  'dpi-calculator': DpiCalculator,
  'download-time': DownloadTime,
  'fps-converter': FpsConverter,
  'unit-converter': UnitConverter,
  'thumbnail-maker': ThumbnailMaker,
  'game-recommender': GameRecommender,
};

export default function ToolDetail() {
  const { slug } = useParams<{ slug: string }>();
  const Component = slug ? TOOL_ROUTES[slug] : null;

  if (!Component) return <Navigate to="/tools" replace />;
  return <Component />;
}
