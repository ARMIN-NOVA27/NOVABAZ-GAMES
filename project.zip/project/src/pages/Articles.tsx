import { useEffect, useState, useMemo } from 'react';
import { fetchArticles } from '@/lib/data';
import type { Article } from '@/lib/types';
import ArticleCard from '@/components/ArticleCard';
import AdBanner from '@/components/AdBanner';
import { useSEO } from '@/lib/useSEO';
import { Search } from 'lucide-react';

const CATEGORIES = [
  { key: 'all', label: 'همه' },
  { key: 'news', label: 'اخبار' },
  { key: 'review', label: 'معرفی بازی' },
  { key: 'guide', label: 'راهنما' },
  { key: 'tutorial', label: 'آموزش' },
  { key: 'best-of', label: 'بهترین‌ها' },
];

export default function Articles() {
  useSEO({ title: 'مطالب گیمینگ', description: 'اخبار، راهنما، آموزش و لیست بهترین بازی‌ها' });
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [category, setCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchArticles()
      .then(setArticles)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    let result = category === 'all' ? articles : articles.filter((a) => a.category === category);
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          (a.title_fa || '').toLowerCase().includes(q) ||
          (a.excerpt || '').toLowerCase().includes(q) ||
          (a.excerpt_fa || '').toLowerCase().includes(q)
      );
    }
    return result;
  }, [articles, category, searchQuery]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-3">
        <p className="text-rose-400 text-lg">خطا در بارگذاری مطالب</p>
        <button onClick={() => window.location.reload()} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm transition-colors">
          تلاش مجدد
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <h1 className="text-2xl sm:text-3xl font-bold text-white mb-6">مطالب گیمینگ</h1>

      <div className="mb-6">
        <AdBanner placement="articles" />
      </div>

      {/* Search */}
      <div className="relative max-w-xl mb-6">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="جستجو در مطالب..."
          className="w-full pr-11 pl-4 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
        />
      </div>

      <div className="flex flex-wrap gap-2 mb-8">
        {CATEGORIES.map((c) => (
          <button
            key={c.key}
            onClick={() => setCategory(c.key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              category === c.key
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <p className="text-slate-400 text-center py-12">مطلبی در این دسته یافت نشد.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      )}
    </div>
  );
}
