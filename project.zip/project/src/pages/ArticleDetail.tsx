import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Calendar, User, ArrowRight } from 'lucide-react';
import { fetchArticleBySlug, fetchArticles } from '@/lib/data';
import type { Article } from '@/lib/types';
import { formatDate } from '@/lib/utils';
import ArticleCard from '@/components/ArticleCard';
import ReportButton from '@/components/ReportButton';
import { useSEO } from '@/lib/useSEO';

const CATEGORY_LABELS: Record<string, string> = {
  news: 'اخبار',
  guide: 'راهنما',
  tutorial: 'آموزش',
  review: 'معرفی',
  'best-of': 'بهترین‌ها',
};

export default function ArticleDetail() {
  const { slug } = useParams<{ slug: string }>();
  const [article, setArticle] = useState<Article | null>(null);
  const [allArticles, setAllArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useSEO({
    title: article ? (article.title_fa || article.title) : 'مطلب',
    description: article?.excerpt_fa || article?.excerpt || undefined,
    image: article?.cover_url || undefined,
  });

  useEffect(() => {
    if (!slug) return;
    Promise.all([fetchArticleBySlug(slug), fetchArticles()])
      .then(([a, all]) => {
        setArticle(a);
        setAllArticles(all);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [slug]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <p className="text-rose-400 mb-4">خطا در بارگذاری مطلب.</p>
        <Link to="/articles" className="text-cyan-400 hover:text-cyan-300">بازگشت به مطالب</Link>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <p className="text-slate-400 mb-4">مطلب موردنظر یافت نشد.</p>
        <Link to="/articles" className="text-cyan-400 hover:text-cyan-300">بازگشت به مطالب</Link>
      </div>
    );
  }

  const similar = allArticles
    .filter((a) => a.id !== article.id && a.category === article.category)
    .slice(0, 3);

  return (
    <article className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/articles" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" />
        بازگشت به مطالب
      </Link>

      <div className="flex items-center gap-2 mb-4">
        <span className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs rounded-full">
          {CATEGORY_LABELS[article.category] || article.category}
        </span>
      </div>

      <h1 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight">
        {article.title_fa || article.title}
      </h1>

      <div className="flex items-center gap-4 mt-4 text-sm text-slate-500">
        {article.author && (
          <span className="flex items-center gap-1">
            <User className="w-4 h-4" />
            {article.author}
          </span>
        )}
        <span className="flex items-center gap-1">
          <Calendar className="w-4 h-4" />
          {formatDate(article.published_at)}
        </span>
      </div>

      {article.cover_url && (
        <div className="mt-6 rounded-xl overflow-hidden">
          <img src={article.cover_url} alt={article.title} className="w-full h-auto" />
        </div>
      )}

      <div className="mt-8 prose prose-invert max-w-none">
        <p className="text-slate-300 text-lg leading-relaxed">
          {article.excerpt_fa || article.excerpt}
        </p>
        <div className="mt-4 text-slate-300 leading-relaxed whitespace-pre-line">
          {article.content_fa || article.content}
        </div>
      </div>

      <div className="mt-6 pt-6 border-t border-slate-800">
        <ReportButton targetType="article" targetId={article.id} targetLabel="مطلب" />
      </div>

      {similar.length > 0 && (
        <div className="mt-12">
          <h2 className="text-lg font-bold text-white mb-4">مطالب مرتبط</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {similar.map((a) => (
              <ArticleCard key={a.id} article={a} />
            ))}
          </div>
        </div>
      )}
    </article>
  );
}
