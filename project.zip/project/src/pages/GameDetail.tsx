import { useEffect, useState, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, Calendar, Cpu, HardDrive, Monitor, MemoryStick, Tv, Gamepad2, Heart, ArrowRight, Bookmark, Loader2, Trash2, Send, GitCompare, Download, Smartphone } from 'lucide-react';
import { fetchGameBySlug, fetchGameImages, fetchSimilarGames, fetchReviewsByGame, fetchUserReview, submitReview, deleteReview, recordGameView, checkFavorite, toggleFavorite, checkWatchlist, toggleWatchlist } from '@/lib/data';
import { useAuth } from '@/lib/auth';
import type { Game, Review, GameImage } from '@/lib/types';
import { formatRating, formatDate } from '@/lib/utils';
import GameCard from '@/components/GameCard';
import ReportButton from '@/components/ReportButton';
import { useSEO } from '@/lib/useSEO';

export default function GameDetail() {
  const { slug } = useParams<{ slug: string }>();
  const [game, setGame] = useState<Game | null>(null);
  const [gallery, setGallery] = useState<GameImage[]>([]);
  const [activeImage, setActiveImage] = useState(0);
  const [similar, setSimilar] = useState<Game[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isWatchlisted, setIsWatchlisted] = useState(false);
  const [favLoading, setFavLoading] = useState(false);
  const [watchLoading, setWatchLoading] = useState(false);
  const [userReview, setUserReview] = useState<Review | null>(null);
  const [reviewRating, setReviewRating] = useState(0);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSaving, setReviewSaving] = useState(false);
  const [reviewError, setReviewError] = useState('');
  const { user } = useAuth();

  useSEO({
    title: game ? (game.title_fa || game.title) : 'بازی',
    description: game?.description_fa || game?.description || undefined,
    image: game?.cover_url || undefined,
  });

  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    setError(false);
    (async () => {
      try {
        const g = await fetchGameBySlug(slug);
        setGame(g);
        if (g) {
          recordGameView(g.id).catch(() => {});
          fetchSimilarGames(g).then(setSimilar).catch(() => setSimilar([]));
          fetchReviewsByGame(g.id).then(setReviews).catch(() => setReviews([]));
          fetchGameImages(g.id).then(setGallery).catch(() => setGallery([]));
          setActiveImage(0);
          if (user) {
            const [fav, wl, ur] = await Promise.all([
              checkFavorite(user.id, g.id),
              checkWatchlist(user.id, g.id),
              fetchUserReview(g.id, user.id),
            ]);
            setIsFavorite(fav);
            setIsWatchlisted(wl);
            setUserReview(ur);
            if (ur) {
              setReviewRating(ur.rating);
              setReviewComment(ur.comment || '');
            }
          }
        }
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    })();
  }, [slug, user]);

  const handleToggleFavorite = useCallback(async () => {
    if (!user || !game) return;
    setFavLoading(true);
    const newState = await toggleFavorite(user.id, game.id, isFavorite);
    setIsFavorite(newState);
    setFavLoading(false);
  }, [user, game, isFavorite]);

  const handleToggleWatchlist = useCallback(async () => {
    if (!user || !game) return;
    setWatchLoading(true);
    const newState = await toggleWatchlist(user.id, game.id, isWatchlisted);
    setIsWatchlisted(newState);
    setWatchLoading(false);
  }, [user, game, isWatchlisted]);

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !game) return;
    if (reviewRating < 1 || reviewRating > 5) {
      setReviewError('لطفاً امتیاز را انتخاب کنید.');
      return;
    }
    setReviewSaving(true);
    setReviewError('');
    const { error } = await submitReview(game.id, user.id, reviewRating, reviewComment);
    setReviewSaving(false);
    if (error) {
      setReviewError(error);
    } else {
      const updated = await fetchReviewsByGame(game.id);
      setReviews(updated);
      const ur = await fetchUserReview(game.id, user.id);
      setUserReview(ur);
    }
  };

  const handleDeleteReview = async () => {
    if (!userReview || !game) return;
    await deleteReview(userReview.id);
    setUserReview(null);
    setReviewRating(0);
    setReviewComment('');
    const updated = await fetchReviewsByGame(game.id);
    setReviews(updated);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <p className="text-rose-400 mb-4">خطا در بارگذاری بازی.</p>
        <Link to="/games" className="text-cyan-400 hover:text-cyan-300">بازگشت به بازی‌ها</Link>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <p className="text-slate-400 mb-4">بازی موردنظر یافت نشد.</p>
        <Link to="/games" className="text-cyan-400 hover:text-cyan-300">بازگشت به بازی‌ها</Link>
      </div>
    );
  }

  const reqRows = [
    { label: 'سیستم‌عامل', min: game.min_os, rec: game.rec_os, icon: Tv },
    { label: 'پردازنده (CPU)', min: game.min_cpu, rec: game.rec_cpu, icon: Cpu },
    { label: 'کارت گرافیک (GPU)', min: game.min_gpu, rec: game.rec_gpu, icon: Monitor },
    { label: 'حافظه (RAM)', min: game.min_ram, rec: game.rec_ram, icon: MemoryStick },
    { label: 'فضا', min: game.min_storage, rec: game.rec_storage, icon: HardDrive },
  ];

  return (
    <div>
      <div className="relative h-64 sm:h-80 overflow-hidden">
        {game.cover_url && (
          <img
            src={game.cover_url}
            alt={game.title}
            loading="lazy"
            className="w-full h-full object-cover"
            onError={(e) => { e.currentTarget.style.display = 'none'; }}
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/70 to-transparent" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-32 relative">
        <Link to="/games" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
          <ArrowRight className="w-4 h-4" />
          بازگشت به بازی‌ها
        </Link>

        <div className="flex flex-col sm:flex-row gap-6">
          <div className="w-40 sm:w-48 flex-shrink-0">
            <div className="aspect-[3/4] rounded-xl overflow-hidden border border-slate-700 bg-slate-800">
              {game.cover_url && (
                <img
                  src={game.cover_url}
                  alt={game.title}
                  loading="lazy"
                  className="w-full h-full object-cover"
                  onError={(e) => { e.currentTarget.style.display = 'none'; }}
                />
              )}
            </div>
          </div>
          <div className="flex-1 pt-2">
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white">{game.title_fa || game.title}</h1>
                {game.title_fa && <p className="text-slate-500 text-sm mt-1">{game.title}</p>}
              </div>
              {user && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleToggleFavorite}
                    disabled={favLoading}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all ${
                      isFavorite
                        ? 'bg-rose-500/10 border-rose-500/50 text-rose-400'
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-rose-500/50'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-400' : ''}`} />
                    <span className="text-sm">{isFavorite ? 'ذخیره‌شده' : 'ذخیره'}</span>
                  </button>
                  <button
                    onClick={handleToggleWatchlist}
                    disabled={watchLoading}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all ${
                      isWatchlisted
                        ? 'bg-cyan-500/10 border-cyan-500/50 text-cyan-400'
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-cyan-500/50'
                    }`}
                  >
                    <Bookmark className={`w-4 h-4 ${isWatchlisted ? 'fill-cyan-400' : ''}`} />
                    <span className="text-sm">{isWatchlisted ? 'در لیست' : 'بعداً بازی می‌کنم'}</span>
                  </button>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-4 mt-4">
              <div className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg">
                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span className="font-bold text-white">{formatRating(game.rating)}</span>
                <span className="text-xs text-slate-500">({game.rating_count} رأی)</span>
              </div>
              {game.release_date && (
                <div className="flex items-center gap-1.5 text-slate-400 text-sm">
                  <Calendar className="w-4 h-4" />
                  {formatDate(game.release_date)}
                </div>
              )}
              {game.developer && (
                <div className="text-slate-400 text-sm">سازنده: {game.developer}</div>
              )}
              {game.publisher && (
                <div className="text-slate-400 text-sm">ناشر: {game.publisher}</div>
              )}
            </div>

            <div className="flex flex-wrap gap-2 mt-4">
              {game.genres.map((g) => (
                <span key={g} className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs rounded-full">{g}</span>
              ))}
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {game.platforms.map((p) => (
                <span key={p} className="px-3 py-1 bg-slate-800 border border-slate-700 text-slate-300 text-xs rounded-full">{p}</span>
              ))}
            </div>

            <InstallSection game={game} />

            <Link
              to={`/compare?g=${game.id}`}
              className="inline-flex items-center gap-2 mt-4 px-4 py-2 bg-slate-800 border border-slate-700 hover:border-cyan-500/50 text-slate-300 hover:text-cyan-400 rounded-lg text-sm transition-all"
            >
              <GitCompare className="w-4 h-4" />
              مقایسه با بازی دیگر
            </Link>

            <div className="mt-3">
              <ReportButton targetType="game" targetId={game.id} targetLabel="بازی" />
            </div>
          </div>
        </div>

        <div className="mt-8">
          <h2 className="text-lg font-bold text-white mb-3">درباره بازی</h2>
          <p className="text-slate-300 leading-relaxed whitespace-pre-line">
            {game.description_fa || game.description || 'اطلاعاتی برای این بازی ثبت نشده است.'}
          </p>
        </div>

        {(gallery.length > 0 || game.trailer_url) && (
          <div className="mt-10">
            <h2 className="text-lg font-bold text-white mb-4">تصاویر و ویدئو</h2>
            {gallery.length > 0 && (
              <div className="mb-4">
                <div className="aspect-video rounded-xl overflow-hidden bg-slate-800 border border-slate-700/50">
                  <img
                    src={gallery[activeImage].image_url}
                    alt={`${game.title} screenshot ${activeImage + 1}`}
                    loading="lazy"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.parentElement?.parentElement?.classList.add('hidden');
                    }}
                  />
                </div>
                {gallery.length > 1 && (
                  <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
                    {gallery.map((img, i) => (
                      <button
                        key={img.image_url}
                        onClick={() => setActiveImage(i)}
                        className={`flex-shrink-0 w-24 aspect-video rounded-lg overflow-hidden border-2 transition-all ${
                          i === activeImage ? 'border-cyan-500' : 'border-transparent opacity-70 hover:opacity-100'
                        }`}
                      >
                        <img src={img.thumbnail_url} alt="" loading="lazy" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
            {game.trailer_url && (
              <video
                controls
                preload="none"
                poster={game.cover_url || undefined}
                className="w-full aspect-video rounded-xl bg-black border border-slate-700/50"
              >
                <source src={game.trailer_url} />
              </video>
            )}
          </div>
        )}

        <div className="mt-10">
          <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Gamepad2 className="w-5 h-5 text-cyan-400" />
            سیستم موردنیاز
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-right py-3 px-4 text-slate-400 font-medium">جزء</th>
                  <th className="text-right py-3 px-4 text-slate-300 font-medium">حداقل</th>
                  <th className="text-right py-3 px-4 text-cyan-300 font-medium">پیشنهادی</th>
                </tr>
              </thead>
              <tbody>
                {reqRows.map((row) => {
                  const Icon = row.icon;
                  return (
                    <tr key={row.label} className="border-b border-slate-800">
                      <td className="py-3 px-4 text-slate-400">
                        <span className="flex items-center gap-2">
                          <Icon className="w-4 h-4 text-slate-500" />
                          {row.label}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-300">{row.min || '—'}</td>
                      <td className="py-3 px-4 text-slate-300">{row.rec || '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Reviews section */}
        <div className="mt-10">
          <h2 className="text-lg font-bold text-white mb-4">نظرات کاربران ({reviews.length})</h2>

          {user ? (
            <form onSubmit={handleSubmitReview} className="bg-slate-800/50 rounded-xl p-5 border border-slate-700/50 mb-6">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-sm text-slate-300 ml-2">امتیاز شما:</span>
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setReviewRating(star)}
                    className="p-0.5"
                  >
                    <Star
                      className={`w-6 h-6 transition-colors ${
                        star <= reviewRating ? 'text-amber-400 fill-amber-400' : 'text-slate-600 hover:text-slate-500'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <textarea
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                placeholder="نظر خود را بنویسید..."
                rows={3}
                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none text-sm"
              />
              {reviewError && <p className="text-rose-400 text-sm mt-2">{reviewError}</p>}
              <div className="flex items-center gap-3 mt-3">
                <button
                  type="submit"
                  disabled={reviewSaving}
                  className="flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-medium rounded-lg text-sm transition-all disabled:opacity-50"
                >
                  {reviewSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  {userReview ? 'به‌روزرسانی نظر' : 'ثبت نظر'}
                </button>
                {userReview && (
                  <button
                    type="button"
                    onClick={handleDeleteReview}
                    className="flex items-center gap-2 px-4 py-2 text-rose-400 hover:bg-rose-500/10 rounded-lg text-sm transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    حذف نظر
                  </button>
                )}
              </div>
            </form>
          ) : (
            <div className="bg-slate-800/50 rounded-xl p-5 border border-slate-700/50 mb-6 text-center">
              <p className="text-slate-400 text-sm">
                برای ثبت نظر <Link to="/auth" className="text-cyan-400 hover:text-cyan-300">وارد شوید</Link>
              </p>
            </div>
          )}

          {reviews.length === 0 ? (
            <p className="text-slate-500 text-center py-8 text-sm">هنوز نظری ثبت نشده است.</p>
          ) : (
            <div className="space-y-3">
              {reviews.map((r) => (
                <div key={r.id} className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white text-xs font-bold">
                        {(r.profiles?.display_name || '؟').charAt(0)}
                      </div>
                      <span className="text-sm font-medium text-white">{r.profiles?.display_name || 'کاربر'}</span>
                    </div>
                    <div className="flex items-center gap-0.5">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star
                          key={s}
                          className={`w-3.5 h-3.5 ${s <= r.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-700'}`}
                        />
                      ))}
                    </div>
                  </div>
                  {r.comment && <p className="text-slate-300 text-sm leading-relaxed">{r.comment}</p>}
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-slate-600 text-xs">{formatDate(r.created_at)}</p>
                    <ReportButton targetType="review" targetId={r.id} targetLabel="نظر" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {similar.length > 0 && (
          <div className="mt-12 mb-8">
            <h2 className="text-lg font-bold text-white mb-4">بازی‌های مشابه</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {similar.map((g) => (
                <GameCard key={g.id} game={g} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function isMobileDevice(): boolean {
  if (typeof navigator === 'undefined') return false;
  return /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
}

function InstallSection({ game }: { game: Game }) {
  const [onMobile] = useState(isMobileDevice());
  const isPcOnly = game.platforms.includes('PC') && !game.platforms.includes('Mobile');
  const hasMobileLinks = !!(game.android_package_name || game.ios_app_id);

  // PC-only game opened on a phone: no install path exists, so explain
  // clearly instead of showing a button that can't do anything useful.
  if (isPcOnly && onMobile) {
    return (
      <div className="mt-4 p-4 bg-slate-800/50 border border-slate-700 rounded-xl flex items-start gap-3">
        <Smartphone className="w-5 h-5 text-slate-500 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-slate-400">
          این بازی مخصوص کامپیوتر است و روی گوشی قابل نصب نیست. برای نصب، از کامپیوتر وارد این صفحه شو.
        </p>
      </div>
    );
  }

  if (isPcOnly && game.steam_appid) {
    return (
      <a
        href={`https://store.steampowered.com/app/${game.steam_appid}`}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-4 flex items-center justify-center gap-2 w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-lg rounded-xl transition-all shadow-lg shadow-emerald-500/20"
      >
        <Download className="w-5 h-5" />
        {game.is_free ? 'نصب رایگان از Steam' : 'مشاهده و خرید در Steam'}
      </a>
    );
  }

  if (hasMobileLinks) {
    const playUrl = game.android_package_name ? `https://play.google.com/store/apps/details?id=${game.android_package_name}` : null;
    const myketUrl = game.android_package_name ? `https://myket.ir/app/${game.android_package_name}` : null;
    const appStoreUrl = game.ios_app_id ? `https://apps.apple.com/app/id${game.ios_app_id}` : null;
    return (
      <div className="mt-4 flex flex-wrap gap-3">
        {playUrl && (
          <a href={playUrl} target="_blank" rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold rounded-xl transition-all">
            <Download className="w-5 h-5" /> Google Play
          </a>
        )}
        {appStoreUrl && (
          <a href={appStoreUrl} target="_blank" rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-6 py-3.5 bg-slate-800 border border-slate-700 hover:border-cyan-500/50 text-white font-bold rounded-xl transition-all">
            <Download className="w-5 h-5" /> App Store
          </a>
        )}
        {myketUrl && (
          <a href={myketUrl} target="_blank" rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-6 py-3.5 bg-amber-500/10 border border-amber-500/40 hover:border-amber-500 text-amber-300 font-bold rounded-xl transition-all">
            <Download className="w-5 h-5" /> مایکت
          </a>
        )}
      </div>
    );
  }

  return null;
}
