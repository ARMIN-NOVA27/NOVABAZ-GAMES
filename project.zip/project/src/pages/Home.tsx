import { useEffect, useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Sparkles, Wrench, Gamepad2, Newspaper, ArrowLeft, Flame } from 'lucide-react';
import { fetchGames, fetchArticles } from '@/lib/data';
import type { Game, Article } from '@/lib/types';
import { TOOLS } from '@/lib/tools';
import GameCard from '@/components/GameCard';
import ArticleCard from '@/components/ArticleCard';
import ToolCard from '@/components/ToolCard';
import SectionHeading from '@/components/SectionHeading';
import AdBanner from '@/components/AdBanner';
import { useSEO } from '@/lib/useSEO';

export default function Home() {
  useSEO({ title: '', description: 'پلتفرم همه‌کاره گیمرهای فارسی‌زبان - ابزارهای کاربردی، معرفی بازی‌ها، مطالب گیمینگ' });
  const [games, setGames] = useState<Game[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([fetchGames(), fetchArticles()])
      .then(([g, a]) => {
        setGames(g);
        setArticles(a);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, []);

  const popularGames = games.filter((g) => g.is_popular).slice(0, 8);
  const newGames = games.filter((g) => g.is_new).slice(0, 4);
  const latestArticles = articles.slice(0, 3);

  const popularThisWeek = useMemo(
    () => [...games].sort((a, b) => b.rating_count - a.rating_count || b.rating - a.rating).slice(0, 5),
    [games]
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-3">
        <p className="text-rose-400 text-lg">خطا در بارگذاری اطلاعات</p>
        <button onClick={() => window.location.reload()} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm transition-colors">
          تلاش مجدد
        </button>
      </div>
    );
  }

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950" />
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(6,182,212,0.15) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(59,130,246,0.15) 0%, transparent 50%)'
        }} />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 mb-6">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span className="text-sm text-cyan-300">پلتفرم همه‌کاره گیمرها</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white leading-tight">
              هرآنچه یک گیمر نیاز دارد،
              <br />
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">یکجا در Gaming Hub</span>
            </h1>
            <p className="mt-5 text-slate-400 text-base sm:text-lg leading-relaxed">
              ابزارهای کاربردی گیمینگ، معرفی بازی‌ها، ایده‌ساز، مطالب و خیلی بیشتر —
              همه برای گیمرهای فارسی‌زبان.
            </p>

            {/* Big search */}
            <form onSubmit={handleSearch} className="mt-8 max-w-2xl mx-auto">
              <div className="relative flex items-center">
                <Search className="absolute right-4 w-5 h-5 text-slate-500" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="نام بازی، ابزار یا مطلب را جستجو کنید..."
                  className="w-full pr-12 pl-32 py-4 bg-slate-800/80 backdrop-blur border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition-all text-right"
                />
                <button
                  type="submit"
                  className="absolute left-2 px-5 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold rounded-lg transition-all"
                >
                  جستجو
                </button>
              </div>
            </form>

            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link to="/games" className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-sm font-medium rounded-lg transition-colors flex items-center gap-2">
                <Gamepad2 className="w-4 h-4" />
                مرور بازی‌ها
              </Link>
              <Link to="/tools" className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-sm font-medium rounded-lg transition-colors flex items-center gap-2">
                <Wrench className="w-4 h-4" />
                ابزارهای گیمینگ
              </Link>
              <Link to="/tools/game-recommender" className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-sm font-medium rounded-lg transition-colors flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                پیشنهاد بازی
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-14">
        {/* Popular this week */}
        {popularThisWeek.length > 0 && (
          <section>
            <SectionHeading title="بازی‌های محبوب هفته" linkTo="/games" />
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
              {popularThisWeek.map((game, i) => (
                <div key={game.id} className="relative">
                  <div className="absolute -top-2 -right-2 z-10 w-7 h-7 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white text-xs font-bold shadow-lg">
                    {i + 1}
                  </div>
                  <GameCard game={game} />
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Ad */}
        <AdBanner placement="home" />

        {/* Popular games */}
        <section>
          <SectionHeading title="بازی‌های محبوب" linkTo="/games" />
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {popularGames.map((game) => (
              <GameCard key={game.id} game={game} />
            ))}
          </div>
        </section>

        {/* New games */}
        {newGames.length > 0 && (
          <section>
            <SectionHeading title="بازی‌های جدید" linkTo="/games" />
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {newGames.map((game) => (
                <GameCard key={game.id} game={game} />
              ))}
            </div>
          </section>
        )}

        {/* Tools */}
        <section>
          <SectionHeading title="ابزارهای گیمینگ" linkTo="/tools" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {TOOLS.map((tool) => (
              <ToolCard key={tool.slug} tool={tool} />
            ))}
          </div>
        </section>

        {/* Idea generator CTA */}
        <section>
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 p-8 sm:p-12">
            <div className="absolute -top-12 -left-12 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl" />
            <div className="relative flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  <span className="text-amber-400 font-semibold text-sm">ابزار ایده‌ساز</span>
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">بدون ایده موندم!</h3>
                <p className="text-slate-400 max-w-lg">
                  برای ویدئو، شورتس، استریم، چالش یا کانالت ایده بگیر. فقط نوع ایده را انتخاب کن و دکمه را بزن.
                </p>
              </div>
              <Link
                to="/tools/idea-generator"
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-bold rounded-xl transition-all whitespace-nowrap"
              >
                شروع ایده‌سازی
                <ArrowLeft className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </section>

        {/* Features intro */}
        <section>
          <SectionHeading title="امکانات سایت" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { icon: Gamepad2, title: 'معرفی بازی‌ها', desc: 'اطلاعات کامل، سیستم موردنیاز و امتیاز کاربران', color: 'from-cyan-500 to-blue-600' },
              { icon: Wrench, title: 'ابزارهای کاربردی', desc: 'ایده‌ساز، سازنده اسم و بیو، محاسبات و تبدیل واحدها', color: 'from-emerald-500 to-green-600' },
              { icon: Newspaper, title: 'مطالب گیمینگ', desc: 'اخبار، راهنما، آموزش و لیست بهترین بازی‌ها', color: 'from-rose-500 to-red-600' },
            ].map((f) => (
              <div key={f.title} className="bg-slate-800/50 rounded-xl p-6 border border-slate-700/50">
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${f.color} flex items-center justify-center mb-4`}>
                  <f.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-white text-lg mb-2">{f.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Latest articles */}
        {latestArticles.length > 0 && (
          <section>
            <SectionHeading title="آخرین مطالب گیمینگ" linkTo="/articles" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {latestArticles.map((article) => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
