import { useEffect, useState, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search as SearchIcon, Gamepad2, Wrench, Newspaper } from 'lucide-react';
import { fetchGames, fetchArticles } from '@/lib/data';
import { TOOLS } from '@/lib/tools';
import type { Game, Article } from '@/lib/types';
import GameCard from '@/components/GameCard';
import ArticleCard from '@/components/ArticleCard';
import { useSEO } from '@/lib/useSEO';

export default function SearchPage() {
  useSEO({ title: 'جستجو', description: 'جستجو در بازی‌ها، مطالب و ابزارهای گیمینگ' });
  const [params, setParams] = useSearchParams();
  const q = params.get('q') || '';
  const [games, setGames] = useState<Game[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [localQuery, setLocalQuery] = useState(q);

  useEffect(() => {
    setLocalQuery(q);
    setError(false);
    Promise.all([fetchGames(), fetchArticles()])
      .then(([g, a]) => {
        setGames(g);
        setArticles(a);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [q]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setLocalQuery(value);
    if (value.trim()) {
      setParams({ q: value.trim() }, { replace: true });
    } else {
      setParams({}, { replace: true });
    }
  };

  const query = q.toLowerCase();

  const matchedGames = useMemo(
    () =>
      games.filter(
        (g) =>
          g.title.toLowerCase().includes(query) ||
          (g.title_fa || '').toLowerCase().includes(query) ||
          g.genre.toLowerCase().includes(query) ||
          g.genres.some((x) => x.toLowerCase().includes(query))
      ),
    [games, query]
  );

  const matchedArticles = useMemo(
    () =>
      articles.filter(
        (a) =>
          a.title.toLowerCase().includes(query) ||
          (a.title_fa || '').toLowerCase().includes(query) ||
          (a.excerpt || '').toLowerCase().includes(query) ||
          (a.excerpt_fa || '').toLowerCase().includes(query) ||
          a.category.toLowerCase().includes(query)
      ),
    [articles, query]
  );

  const matchedTools = useMemo(
    () => TOOLS.filter((t) => t.title.toLowerCase().includes(query) || t.description.toLowerCase().includes(query)),
    [query]
  );

  const hasResults = matchedGames.length > 0 || matchedArticles.length > 0 || matchedTools.length > 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="relative max-w-2xl mb-10">
        <SearchIcon className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
        <input
          type="text"
          value={localQuery}
          onChange={handleInputChange}
          placeholder="جستجو..."
          className="w-full pr-12 pl-4 py-3.5 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
        />
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : error ? (
        <div className="text-center py-20">
          <p className="text-rose-400 mb-2">خطا در بارگذاری اطلاعات.</p>
          <p className="text-slate-500 text-sm">لطفاً دوباره تلاش کنید.</p>
        </div>
      ) : !q ? (
        <p className="text-slate-400 text-center py-20">عبارتی برای جستجو وارد کنید.</p>
      ) : !hasResults ? (
        <div className="text-center py-20">
          <p className="text-slate-400 mb-2">نتیجه‌ای برای «{q}» یافت نشد.</p>
          <p className="text-slate-500 text-sm">عبارت دیگری را امتحان کنید.</p>
        </div>
      ) : (
        <div className="space-y-10">
          {matchedGames.length > 0 && (
            <section>
              <h2 className="flex items-center gap-2 text-xl font-bold text-white mb-4">
                <Gamepad2 className="w-5 h-5 text-cyan-400" />
                بازی‌ها ({matchedGames.length})
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {matchedGames.map((g) => (
                  <GameCard key={g.id} game={g} />
                ))}
              </div>
            </section>
          )}

          {matchedTools.length > 0 && (
            <section>
              <h2 className="flex items-center gap-2 text-xl font-bold text-white mb-4">
                <Wrench className="w-5 h-5 text-emerald-400" />
                ابزارها ({matchedTools.length})
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {matchedTools.map((t) => (
                  <Link
                    key={t.slug}
                    to={`/tools/${t.slug}`}
                    className="bg-slate-800/50 rounded-xl p-5 border border-slate-700/50 hover:border-slate-600 transition-all"
                  >
                    <h3 className="font-bold text-white">{t.title}</h3>
                    <p className="text-sm text-slate-400 mt-1">{t.description}</p>
                  </Link>
                ))}
              </div>
            </section>
          )}

          {matchedArticles.length > 0 && (
            <section>
              <h2 className="flex items-center gap-2 text-xl font-bold text-white mb-4">
                <Newspaper className="w-5 h-5 text-rose-400" />
                مطالب ({matchedArticles.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {matchedArticles.map((a) => (
                  <ArticleCard key={a.id} article={a} />
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}
