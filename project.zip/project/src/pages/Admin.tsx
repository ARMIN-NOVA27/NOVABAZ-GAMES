import { useEffect, useState, useCallback } from 'react';
import { Navigate } from 'react-router-dom';
import { Shield, LayoutDashboard, Gamepad2, Newspaper, Users, Megaphone, Flag, Loader2, Plus, Edit2, Trash2, X, Check, AlertCircle } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { fetchAdminStats, fetchGames, fetchArticles, fetchAllReviewsAdmin, fetchAllReports, fetchAllAdsAdmin, updateReportStatus, createAd, updateAd, deleteAd, createGame, updateGame, deleteGame, createArticle, updateArticle, deleteArticle } from '@/lib/data';
import type { AdminStats, Game, Article, Review, Report, Ad } from '@/lib/types';
import { formatDate, formatRating } from '@/lib/utils';
import { useSEO } from '@/lib/useSEO';

type Tab = 'dashboard' | 'games' | 'articles' | 'users' | 'ads' | 'reports';

export default function Admin() {
  useSEO({ title: 'پنل مدیریت', description: 'مدیریت بازی‌ها، مطالب، تبلیغات و گزارش‌ها' });
  const { user, isAdmin, loading } = useAuth();
  const [tab, setTab] = useState<Tab>('dashboard');
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [games, setGames] = useState<Game[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [ads, setAds] = useState<Ad[]>([]);
  const [dataLoading, setDataLoading] = useState(true);
  const [editingGame, setEditingGame] = useState<Game | null>(null);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [editingAd, setEditingAd] = useState<Ad | null>(null);
  const [showGameForm, setShowGameForm] = useState(false);
  const [showArticleForm, setShowArticleForm] = useState(false);
  const [showAdForm, setShowAdForm] = useState(false);

  const loadAll = useCallback(async () => {
    setDataLoading(true);
    try {
      const [s, g, a, r, reps, adList] = await Promise.all([
        fetchAdminStats(),
        fetchGames(),
        fetchArticles(),
        fetchAllReviewsAdmin(),
        fetchAllReports(),
        fetchAllAdsAdmin(),
      ]);
      setStats(s);
      setGames(g);
      setArticles(a);
      setReviews(r);
      setReports(reps);
      setAds(adList);
    } catch {
      // ignore
    }
    setDataLoading(false);
  }, []);

  useEffect(() => {
    if (user && isAdmin) loadAll();
  }, [user, isAdmin, loadAll]);

  if (loading) {
    return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 text-cyan-500 animate-spin" /></div>;
  }
  if (!user) return <Navigate to="/auth" replace />;
  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center">
        <Shield className="w-12 h-12 text-slate-600 mx-auto mb-4" />
        <h1 className="text-xl font-bold text-white mb-2">دسترسی غیرمجاز</h1>
        <p className="text-slate-400">شما به این بخش دسترسی ندارید.</p>
      </div>
    );
  }

  const tabs = [
    { key: 'dashboard' as const, label: 'داشبورد', icon: LayoutDashboard },
    { key: 'games' as const, label: 'بازی‌ها', icon: Gamepad2 },
    { key: 'articles' as const, label: 'مطالب', icon: Newspaper },
    { key: 'users' as const, label: 'کاربران', icon: Users },
    { key: 'ads' as const, label: 'تبلیغات', icon: Megaphone },
    { key: 'reports' as const, label: 'گزارش‌ها', icon: Flag },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
          <Shield className="w-5 h-5 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-white">پنل مدیریت</h1>
      </div>

      <div className="flex gap-1 mb-6 border-b border-slate-800 overflow-x-auto pb-px">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              tab === t.key ? 'border-amber-500 text-amber-400' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
            {t.key === 'reports' && stats && stats.pending_reports > 0 && (
              <span className="bg-rose-500 text-white text-xs px-1.5 py-0.5 rounded-full">{stats.pending_reports}</span>
            )}
          </button>
        ))}
      </div>

      {dataLoading ? (
        <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 text-cyan-500 animate-spin" /></div>
      ) : (
        <>
          {tab === 'dashboard' && stats && (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[
                { label: 'بازی‌ها', value: stats.games, icon: Gamepad2, color: 'from-cyan-500 to-blue-600' },
                { label: 'مطالب', value: stats.articles, icon: Newspaper, color: 'from-rose-500 to-red-600' },
                { label: 'کاربران', value: stats.users, icon: Users, color: 'from-emerald-500 to-green-600' },
                { label: 'نظرات', value: stats.reviews, icon: AlertCircle, color: 'from-amber-500 to-orange-600' },
                { label: 'علاقه‌مندی‌ها', value: stats.favorites, icon: AlertCircle, color: 'from-violet-500 to-purple-600' },
                { label: 'لیست بازی', value: stats.watchlist, icon: AlertCircle, color: 'from-sky-500 to-indigo-600' },
                { label: 'تبلیغات فعال', value: stats.active_ads, icon: Megaphone, color: 'from-teal-500 to-cyan-600' },
                { label: 'گزارش‌های در انتظار', value: stats.pending_reports, icon: Flag, color: 'from-rose-500 to-red-600' },
              ].map((s) => (
                <div key={s.label} className="bg-slate-800/50 rounded-xl p-5 border border-slate-700/50">
                  <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${s.color} flex items-center justify-center mb-3`}>
                    <s.icon className="w-5 h-5 text-white" />
                  </div>
                  <p className="text-2xl font-bold text-white">{s.value}</p>
                  <p className="text-sm text-slate-400">{s.label}</p>
                </div>
              ))}
            </div>
          )}

          {tab === 'games' && (
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-bold text-white">مدیریت بازی‌ها ({games.length})</h2>
                <button onClick={() => { setEditingGame(null); setShowGameForm(true); }} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-medium rounded-lg">
                  <Plus className="w-4 h-4" /> افزودن بازی
                </button>
              </div>
              <div className="space-y-2">
                {games.map((g) => (
                  <div key={g.id} className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
                    {g.cover_url && <img src={g.cover_url} alt={g.title} className="w-10 h-14 object-cover rounded flex-shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-white text-sm truncate">{g.title_fa || g.title}</h3>
                      <p className="text-xs text-slate-500">{g.genre} • {formatRating(g.rating)} ({g.rating_count} رأی)</p>
                    </div>
                    <button onClick={() => { setEditingGame(g); setShowGameForm(true); }} className="p-2 text-slate-400 hover:text-cyan-400"><Edit2 className="w-4 h-4" /></button>
                    <button onClick={async () => { if (confirm('حذف این بازی؟')) { await deleteGame(g.id); loadAll(); } }} className="p-2 text-slate-400 hover:text-rose-400"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
              </div>
              {showGameForm && <GameForm game={editingGame} onClose={() => setShowGameForm(false)} onSaved={() => { setShowGameForm(false); loadAll(); }} />}
            </div>
          )}

          {tab === 'articles' && (
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-bold text-white">مدیریت مطالب ({articles.length})</h2>
                <button onClick={() => { setEditingArticle(null); setShowArticleForm(true); }} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-medium rounded-lg">
                  <Plus className="w-4 h-4" /> افزودن مطلب
                </button>
              </div>
              <div className="space-y-2">
                {articles.map((a) => (
                  <div key={a.id} className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
                    {a.cover_url && <img src={a.cover_url} alt={a.title} className="w-16 h-10 object-cover rounded flex-shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-white text-sm truncate">{a.title_fa || a.title}</h3>
                      <p className="text-xs text-slate-500">{a.category} • {a.author || '—'}</p>
                    </div>
                    <button onClick={() => { setEditingArticle(a); setShowArticleForm(true); }} className="p-2 text-slate-400 hover:text-cyan-400"><Edit2 className="w-4 h-4" /></button>
                    <button onClick={async () => { if (confirm('حذف این مطلب؟')) { await deleteArticle(a.id); loadAll(); } }} className="p-2 text-slate-400 hover:text-rose-400"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
              </div>
              {showArticleForm && <ArticleForm article={editingArticle} onClose={() => setShowArticleForm(false)} onSaved={() => { setShowArticleForm(false); loadAll(); }} />}
            </div>
          )}

          {tab === 'users' && (
            <div>
              <h2 className="text-lg font-bold text-white mb-4">آمار کاربران</h2>
              <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700/50">
                <p className="text-slate-400 text-sm mb-2">تعداد کل کاربران:</p>
                <p className="text-3xl font-bold text-white">{stats?.users || 0}</p>
                <p className="text-slate-500 text-xs mt-2">برای حریم خصوصی کاربران، اطلاعات فردی نمایش داده نمی‌شود.</p>
              </div>
            </div>
          )}

          {tab === 'ads' && (
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-bold text-white">مدیریت تبلیغات ({ads.length})</h2>
                <button onClick={() => { setEditingAd(null); setShowAdForm(true); }} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-medium rounded-lg">
                  <Plus className="w-4 h-4" /> افزودن تبلیغ
                </button>
              </div>
              <div className="space-y-2">
                {ads.map((ad) => (
                  <div key={ad.id} className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
                    {ad.image_url && <img src={ad.image_url} alt={ad.title} className="w-16 h-10 object-cover rounded flex-shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-white text-sm truncate">{ad.title}</h3>
                      <p className="text-xs text-slate-500">{ad.placement} • {ad.is_active ? 'فعال' : 'غیرفعال'} • {ad.impressions} نمایش • {ad.clicks} کلیک</p>
                    </div>
                    <button onClick={() => { setEditingAd(ad); setShowAdForm(true); }} className="p-2 text-slate-400 hover:text-cyan-400"><Edit2 className="w-4 h-4" /></button>
                    <button onClick={async () => { if (confirm('حذف این تبلیغ؟')) { await deleteAd(ad.id); loadAll(); } }} className="p-2 text-slate-400 hover:text-rose-400"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
              </div>
              {showAdForm && <AdForm ad={editingAd} onClose={() => setShowAdForm(false)} onSaved={() => { setShowAdForm(false); loadAll(); }} />}
            </div>
          )}

          {tab === 'reports' && (
            <div>
              <h2 className="text-lg font-bold text-white mb-4">گزارش‌ها ({reports.length})</h2>
              {reports.length === 0 ? (
                <p className="text-slate-400 text-center py-12">گزارشی وجود ندارد.</p>
              ) : (
                <div className="space-y-3">
                  {reports.map((r) => (
                    <div key={r.id} className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                              r.status === 'pending' ? 'bg-amber-500/20 text-amber-400' :
                              r.status === 'resolved' ? 'bg-emerald-500/20 text-emerald-400' :
                              'bg-slate-700 text-slate-400'
                            }`}>
                              {r.status === 'pending' ? 'در انتظار' : r.status === 'resolved' ? 'حل‌شده' : 'رد شده'}
                            </span>
                            <span className="text-xs text-slate-500">{r.target_type === 'game' ? 'بازی' : r.target_type === 'article' ? 'مطلب' : 'نظر'}</span>
                          </div>
                          <p className="text-slate-300 text-sm">{r.reason}</p>
                          <p className="text-slate-600 text-xs mt-1">{formatDate(r.created_at)}</p>
                          {r.admin_note && <p className="text-slate-400 text-xs mt-2">یادداشت: {r.admin_note}</p>}
                        </div>
                        {r.status === 'pending' && (
                          <div className="flex gap-2 flex-shrink-0">
                            <button onClick={async () => { await updateReportStatus(r.id, 'resolved', null); loadAll(); }} className="flex items-center gap-1 px-3 py-1.5 bg-emerald-500/10 text-emerald-400 rounded-lg text-xs hover:bg-emerald-500/20">
                              <Check className="w-3 h-3" /> حل شد
                            </button>
                            <button onClick={async () => { await updateReportStatus(r.id, 'dismissed', null); loadAll(); }} className="flex items-center gap-1 px-3 py-1.5 bg-slate-700 text-slate-400 rounded-lg text-xs hover:bg-slate-600">
                              <X className="w-3 h-3" /> رد
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ===================== Game Form Modal =====================
function GameForm({ game, onClose, onSaved }: { game: Game | null; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    slug: game?.slug || '',
    title: game?.title || '',
    title_fa: game?.title_fa || '',
    cover_url: game?.cover_url || '',
    genre: game?.genre || '',
    genres: (game?.genres || []).join(', '),
    platforms: (game?.platforms || []).join(', '),
    description: game?.description || '',
    description_fa: game?.description_fa || '',
    release_date: game?.release_date || '',
    developer: game?.developer || '',
    publisher: game?.publisher || '',
    min_cpu: game?.min_cpu || '', min_gpu: game?.min_gpu || '', min_ram: game?.min_ram || '', min_storage: game?.min_storage || '', min_os: game?.min_os || '',
    rec_cpu: game?.rec_cpu || '', rec_gpu: game?.rec_gpu || '', rec_ram: game?.rec_ram || '', rec_storage: game?.rec_storage || '', rec_os: game?.rec_os || '',
    is_popular: game?.is_popular || false, is_new: game?.is_new || false,
    is_free: game?.is_free || false,
    android_package_name: game?.android_package_name || '', ios_app_id: game?.ios_app_id || '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    setSaving(true);
    setError('');
    const payload = {
      ...form,
      genres: form.genres.split(',').map((s) => s.trim()).filter(Boolean),
      platforms: form.platforms.split(',').map((s) => s.trim()).filter(Boolean),
      release_date: form.release_date || null,
    };
    const { error: err } = game ? await updateGame(game.id, payload) : await createGame(payload);
    setSaving(false);
    if (err) setError(err);
    else onSaved();
  };

  return (
    <Modal title={game ? 'ویرایش بازی' : 'افزودن بازی'} onClose={onClose}>
      <div className="space-y-3 max-h-[60vh] overflow-y-auto">
        <div className="grid grid-cols-2 gap-3">
          <Field label="عنوان انگلیسی" value={form.title} onChange={(v) => setForm({ ...form, title: v })} />
          <Field label="عنوان فارسی" value={form.title_fa} onChange={(v) => setForm({ ...form, title_fa: v })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Slug" value={form.slug} onChange={(v) => setForm({ ...form, slug: v })} />
          <Field label="ژانر اصلی" value={form.genre} onChange={(v) => setForm({ ...form, genre: v })} />
        </div>
        <Field label="آدرس کاور" value={form.cover_url} onChange={(v) => setForm({ ...form, cover_url: v })} />
        <Field label="ژانرها (با کاما جدا کنید)" value={form.genres} onChange={(v) => setForm({ ...form, genres: v })} />
        <Field label="پلتفرم‌ها (با کاما جدا کنید)" value={form.platforms} onChange={(v) => setForm({ ...form, platforms: v })} />
        <label className="flex items-center gap-2 text-sm text-slate-300">
          <input type="checkbox" checked={form.is_free} onChange={(e) => setForm({ ...form, is_free: e.target.checked })} />
          بازی رایگان است (فقط بازی‌های رایگان دکمه نصب از Steam می‌گیرند)
        </label>
        {form.platforms.includes('Mobile') && (
          <div className="grid grid-cols-1 gap-3 p-3 bg-slate-900/50 rounded-lg border border-slate-700">
            <p className="text-xs text-slate-500">این‌ها فقط شناسه‌ی برنامه هستن، نه لینک کامل — تا دکمه‌ها همیشه دقیقاً به صفحه‌ی همین بازی برن</p>
            <Field label="نام بسته‌ی اندروید (مثلاً com.company.game)" value={form.android_package_name} onChange={(v) => setForm({ ...form, android_package_name: v })} />
            <Field label="شناسه‌ی عددی اپ در App Store" value={form.ios_app_id} onChange={(v) => setForm({ ...form, ios_app_id: v })} />
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <Field label="سازنده" value={form.developer} onChange={(v) => setForm({ ...form, developer: v })} />
          <Field label="ناشر" value={form.publisher} onChange={(v) => setForm({ ...form, publisher: v })} />
        </div>
        <Field label="تاریخ انتشار (YYYY-MM-DD)" value={form.release_date} onChange={(v) => setForm({ ...form, release_date: v })} />
        <TextArea label="توضیحات انگلیسی" value={form.description} onChange={(v) => setForm({ ...form, description: v })} />
        <TextArea label="توضیحات فارسی" value={form.description_fa} onChange={(v) => setForm({ ...form, description_fa: v })} />
        <div className="grid grid-cols-2 gap-3">
          <Field label="CPU حداقل" value={form.min_cpu} onChange={(v) => setForm({ ...form, min_cpu: v })} />
          <Field label="CPU پیشنهادی" value={form.rec_cpu} onChange={(v) => setForm({ ...form, rec_cpu: v })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="GPU حداقل" value={form.min_gpu} onChange={(v) => setForm({ ...form, min_gpu: v })} />
          <Field label="GPU پیشنهادی" value={form.rec_gpu} onChange={(v) => setForm({ ...form, rec_gpu: v })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="RAM حداقل" value={form.min_ram} onChange={(v) => setForm({ ...form, min_ram: v })} />
          <Field label="RAM پیشنهادی" value={form.rec_ram} onChange={(v) => setForm({ ...form, rec_ram: v })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="فضا حداقل" value={form.min_storage} onChange={(v) => setForm({ ...form, min_storage: v })} />
          <Field label="فضا پیشنهادی" value={form.rec_storage} onChange={(v) => setForm({ ...form, rec_storage: v })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="سیستم‌عامل حداقل" value={form.min_os} onChange={(v) => setForm({ ...form, min_os: v })} />
          <Field label="سیستم‌عامل پیشنهادی" value={form.rec_os} onChange={(v) => setForm({ ...form, rec_os: v })} />
        </div>
        <div className="flex gap-4">
          <label className="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" checked={form.is_popular} onChange={(e) => setForm({ ...form, is_popular: e.target.checked })} /> محبوب</label>
          <label className="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" checked={form.is_new} onChange={(e) => setForm({ ...form, is_new: e.target.checked })} /> جدید</label>
        </div>
        {error && <p className="text-rose-400 text-sm">{error}</p>}
        <button onClick={handleSave} disabled={saving} className="w-full flex items-center justify-center gap-2 px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-lg disabled:opacity-50">
          {saving && <Loader2 className="w-4 h-4 animate-spin" />} ذخیره
        </button>
      </div>
    </Modal>
  );
}

// ===================== Article Form Modal =====================
function ArticleForm({ article, onClose, onSaved }: { article: Article | null; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    slug: article?.slug || '',
    title: article?.title || '',
    title_fa: article?.title_fa || '',
    excerpt: article?.excerpt || '',
    excerpt_fa: article?.excerpt_fa || '',
    content: article?.content || '',
    content_fa: article?.content_fa || '',
    category: article?.category || 'news',
    cover_url: article?.cover_url || '',
    author: article?.author || '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    setSaving(true);
    setError('');
    const { error: err } = article ? await updateArticle(article.id, form) : await createArticle(form);
    setSaving(false);
    if (err) setError(err);
    else onSaved();
  };

  return (
    <Modal title={article ? 'ویرایش مطلب' : 'افزودن مطلب'} onClose={onClose}>
      <div className="space-y-3 max-h-[60vh] overflow-y-auto">
        <div className="grid grid-cols-2 gap-3">
          <Field label="عنوان انگلیسی" value={form.title} onChange={(v) => setForm({ ...form, title: v })} />
          <Field label="عنوان فارسی" value={form.title_fa} onChange={(v) => setForm({ ...form, title_fa: v })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Slug" value={form.slug} onChange={(v) => setForm({ ...form, slug: v })} />
          <div>
            <label className="block text-sm text-slate-300 mb-1">دسته</label>
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm">
              <option value="news">اخبار</option><option value="review">معرفی</option><option value="guide">راهنما</option><option value="tutorial">آموزش</option><option value="best-of">بهترین‌ها</option>
            </select>
          </div>
        </div>
        <Field label="آدرس تصویر" value={form.cover_url} onChange={(v) => setForm({ ...form, cover_url: v })} />
        <Field label="نویسنده" value={form.author} onChange={(v) => setForm({ ...form, author: v })} />
        <TextArea label="خلاصه انگلیسی" value={form.excerpt} onChange={(v) => setForm({ ...form, excerpt: v })} />
        <TextArea label="خلاصه فارسی" value={form.excerpt_fa} onChange={(v) => setForm({ ...form, excerpt_fa: v })} />
        <TextArea label="متن انگلیسی" value={form.content} onChange={(v) => setForm({ ...form, content: v })} rows={5} />
        <TextArea label="متن فارسی" value={form.content_fa} onChange={(v) => setForm({ ...form, content_fa: v })} rows={5} />
        {error && <p className="text-rose-400 text-sm">{error}</p>}
        <button onClick={handleSave} disabled={saving} className="w-full flex items-center justify-center gap-2 px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-lg disabled:opacity-50">
          {saving && <Loader2 className="w-4 h-4 animate-spin" />} ذخیره
        </button>
      </div>
    </Modal>
  );
}

// ===================== Ad Form Modal =====================
function AdForm({ ad, onClose, onSaved }: { ad: Ad | null; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    title: ad?.title || '',
    image_url: ad?.image_url || '',
    link_url: ad?.link_url || '',
    placement: ad?.placement || 'home',
    is_active: ad?.is_active ?? true,
    start_date: ad?.start_date ? ad.start_date.slice(0, 10) : '',
    end_date: ad?.end_date ? ad.end_date.slice(0, 10) : '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    setSaving(true);
    setError('');
    const payload = {
      ...form,
      start_date: form.start_date ? new Date(form.start_date).toISOString() : new Date().toISOString(),
      end_date: form.end_date ? new Date(form.end_date).toISOString() : null,
    };
    const { error: err } = ad ? await updateAd(ad.id, payload) : await createAd(payload);
    setSaving(false);
    if (err) setError(err);
    else onSaved();
  };

  return (
    <Modal title={ad ? 'ویرایش تبلیغ' : 'افزودن تبلیغ'} onClose={onClose}>
      <div className="space-y-3">
        <Field label="عنوان" value={form.title} onChange={(v) => setForm({ ...form, title: v })} />
        <Field label="آدرس تصویر" value={form.image_url} onChange={(v) => setForm({ ...form, image_url: v })} />
        <Field label="لینک" value={form.link_url} onChange={(v) => setForm({ ...form, link_url: v })} />
        <div>
          <label className="block text-sm text-slate-300 mb-1">محل نمایش</label>
          <select value={form.placement} onChange={(e) => setForm({ ...form, placement: e.target.value })} className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm">
            <option value="home">خانه</option><option value="games">بازی‌ها</option><option value="articles">مطالب</option><option value="tools">ابزارها</option><option value="sidebar">کنار</option>
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="تاریخ شروع" value={form.start_date} onChange={(v) => setForm({ ...form, start_date: v })} />
          <Field label="تاریخ پایان" value={form.end_date} onChange={(v) => setForm({ ...form, end_date: v })} />
        </div>
        <label className="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} /> فعال</label>
        {error && <p className="text-rose-400 text-sm">{error}</p>}
        <button onClick={handleSave} disabled={saving} className="w-full flex items-center justify-center gap-2 px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-lg disabled:opacity-50">
          {saving && <Loader2 className="w-4 h-4 animate-spin" />} ذخیره
        </button>
      </div>
    </Modal>
  );
}

// ===================== Helper Components =====================
function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60" onClick={onClose}>
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700 max-w-2xl w-full max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-white">{title}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="block text-sm text-slate-300 mb-1">{label}</label>
      <input type="text" value={value} onChange={(e) => onChange(e.target.value)} className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500" />
    </div>
  );
}

function TextArea({ label, value, onChange, rows = 3 }: { label: string; value: string; onChange: (v: string) => void; rows?: number }) {
  return (
    <div>
      <label className="block text-sm text-slate-300 mb-1">{label}</label>
      <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={rows} className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500 resize-none" />
    </div>
  );
}
