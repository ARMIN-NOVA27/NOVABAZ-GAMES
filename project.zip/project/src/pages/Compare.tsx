import { useEffect, useState, useCallback } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { GitCompare, ArrowRight, Star, Calendar, Cpu, HardDrive, Monitor, MemoryStick, Tv } from 'lucide-react';
import { fetchGames } from '@/lib/data';
import type { Game } from '@/lib/types';
import { formatRating, formatDate } from '@/lib/utils';
import { useSEO } from '@/lib/useSEO';

export default function Compare() {
  useSEO({ title: 'مقایسه بازی‌ها', description: 'دو بازی را side-by-side مقایسه کن: امتیاز، سیستم‌نیازها، ژانر و بیشتر' });
  const [params] = useSearchParams();
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [gameAId, setGameAId] = useState<string>('');
  const [gameBId, setGameBId] = useState<string>('');

  useEffect(() => {
    fetchGames()
      .then((g) => {
        setGames(g);
        const preselect = params.get('g');
        if (preselect) setGameAId(preselect);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [params]);

  const gameA = games.find((g) => g.id === gameAId);
  const gameB = games.find((g) => g.id === gameBId);

  const compareRows = useCallback(() => {
    if (!gameA || !gameB) return [];
    return [
      { label: 'امتیاز', icon: Star, a: formatRating(gameA.rating), b: formatRating(gameB.rating), highlight: gameA.rating > gameB.rating ? 'a' : gameA.rating < gameB.rating ? 'b' : null },
      { label: 'تعداد رأی', icon: Star, a: `${gameA.rating_count}`, b: `${gameB.rating_count}`, highlight: gameA.rating_count > gameB.rating_count ? 'a' : gameA.rating_count < gameB.rating_count ? 'b' : null },
      { label: 'ژانر', icon: GitCompare, a: gameA.genres.join('، ') || '—', b: gameB.genres.join('، ') || '—', highlight: null },
      { label: 'پلتفرم', icon: GitCompare, a: gameA.platforms.join('، ') || '—', b: gameB.platforms.join('، ') || '—', highlight: null },
      { label: 'تاریخ انتشار', icon: Calendar, a: gameA.release_date ? formatDate(gameA.release_date) : '—', b: gameB.release_date ? formatDate(gameB.release_date) : '—', highlight: null },
      { label: 'سازنده', icon: GitCompare, a: gameA.developer || '—', b: gameB.developer || '—', highlight: null },
      { label: 'ناشر', icon: GitCompare, a: gameA.publisher || '—', b: gameB.publisher || '—', highlight: null },
      { label: 'سیستم‌عامل (حداقل)', icon: Tv, a: gameA.min_os || '—', b: gameB.min_os || '—', highlight: null },
      { label: 'CPU (حداقل)', icon: Cpu, a: gameA.min_cpu || '—', b: gameB.min_cpu || '—', highlight: null },
      { label: 'GPU (حداقل)', icon: Monitor, a: gameA.min_gpu || '—', b: gameB.min_gpu || '—', highlight: null },
      { label: 'RAM (حداقل)', icon: MemoryStick, a: gameA.min_ram || '—', b: gameB.min_ram || '—', highlight: null },
      { label: 'فضا (حداقل)', icon: HardDrive, a: gameA.min_storage || '—', b: gameB.min_storage || '—', highlight: null },
      { label: 'CPU (پیشنهادی)', icon: Cpu, a: gameA.rec_cpu || '—', b: gameB.rec_cpu || '—', highlight: null },
      { label: 'GPU (پیشنهادی)', icon: Monitor, a: gameA.rec_gpu || '—', b: gameB.rec_gpu || '—', highlight: null },
      { label: 'RAM (پیشنهادی)', icon: MemoryStick, a: gameA.rec_ram || '—', b: gameB.rec_ram || '—', highlight: null },
    ];
  }, [gameA, gameB]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-3">
        <p className="text-rose-400 text-lg">خطا در بارگذاری بازی‌ها</p>
        <button onClick={() => window.location.reload()} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm transition-colors">
          تلاش مجدد
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/games" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-cyan-400 mb-4 transition-colors">
        <ArrowRight className="w-4 h-4" />
        بازگشت به بازی‌ها
      </Link>

      <h1 className="text-2xl sm:text-3xl font-bold text-white mb-6 flex items-center gap-2">
        <GitCompare className="w-6 h-6 text-cyan-400" />
        مقایسه بازی‌ها
      </h1>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div>
          <label className="block text-sm text-slate-400 mb-2">بازی اول</label>
          <select
            value={gameAId}
            onChange={(e) => setGameAId(e.target.value)}
            className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500"
          >
            <option value="">انتخاب کنید...</option>
            {games.map((g) => (
              <option key={g.id} value={g.id}>{g.title_fa || g.title}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm text-slate-400 mb-2">بازی دوم</label>
          <select
            value={gameBId}
            onChange={(e) => setGameBId(e.target.value)}
            className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500"
          >
            <option value="">انتخاب کنید...</option>
            {games.map((g) => (
              <option key={g.id} value={g.id}>{g.title_fa || g.title}</option>
            ))}
          </select>
        </div>
      </div>

      {!gameA || !gameB ? (
        <div className="text-center py-16">
          <GitCompare className="w-16 h-16 text-slate-700 mx-auto mb-4" />
          <p className="text-slate-400">دو بازی را انتخاب کنید تا مقایسه را ببینید.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Game headers */}
          <div className="grid grid-cols-[1fr_80px_1fr] gap-2 sm:gap-4 items-center">
            <Link to={`/games/${gameA.slug}`} className="block">
              <div className="flex items-center gap-3 bg-slate-800/50 rounded-xl p-3 border border-slate-700/50 hover:border-cyan-500/50 transition-all">
                {gameA.cover_url && (
                  <img src={gameA.cover_url} alt={gameA.title} className="w-12 h-16 object-cover rounded-lg flex-shrink-0" />
                )}
                <div className="min-w-0">
                  <h3 className="font-bold text-white text-sm truncate">{gameA.title_fa || gameA.title}</h3>
                  <p className="text-xs text-slate-500 truncate">{gameA.genre}</p>
                </div>
              </div>
            </Link>
            <div className="text-center text-slate-600 text-xs font-bold">VS</div>
            <Link to={`/games/${gameB.slug}`} className="block">
              <div className="flex items-center gap-3 bg-slate-800/50 rounded-xl p-3 border border-slate-700/50 hover:border-cyan-500/50 transition-all">
                {gameB.cover_url && (
                  <img src={gameB.cover_url} alt={gameB.title} className="w-12 h-16 object-cover rounded-lg flex-shrink-0" />
                )}
                <div className="min-w-0">
                  <h3 className="font-bold text-white text-sm truncate">{gameB.title_fa || gameB.title}</h3>
                  <p className="text-xs text-slate-500 truncate">{gameB.genre}</p>
                </div>
              </div>
            </Link>
          </div>

          {/* Comparison rows */}
          <div className="space-y-2">
            {compareRows().map((row) => {
              const Icon = row.icon;
              return (
                <div key={row.label} className="grid grid-cols-[1fr_80px_1fr] gap-2 sm:gap-4 items-center bg-slate-800/30 rounded-lg p-3">
                  <div className={`text-sm ${row.highlight === 'a' ? 'text-cyan-400 font-bold' : 'text-slate-300'} text-right truncate`}>
                    {row.a}
                  </div>
                  <div className="text-center">
                    <span className="inline-flex items-center gap-1 text-xs text-slate-500">
                      <Icon className="w-3 h-3" />
                      {row.label}
                    </span>
                  </div>
                  <div className={`text-sm ${row.highlight === 'b' ? 'text-cyan-400 font-bold' : 'text-slate-300'} text-left truncate`}>
                    {row.b}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
