import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';
import { useSEO } from '@/lib/useSEO';

export default function NotFound() {
  useSEO({ title: 'صفحه یافت نشد', description: 'صفحه مورد نظر یافت نشد' });
  return (
    <div className="max-w-md mx-auto px-4 py-24 text-center">
      <p className="text-7xl font-extrabold text-slate-700 mb-4">404</p>
      <h1 className="text-xl font-bold text-white mb-2">صفحه یافت نشد</h1>
      <p className="text-slate-400 mb-8">صفحه‌ای که دنبالش بودید وجود ندارد.</p>
      <Link
        to="/"
        className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-lg transition-all"
      >
        <Home className="w-4 h-4" />
        بازگشت به خانه
      </Link>
    </div>
  );
}
