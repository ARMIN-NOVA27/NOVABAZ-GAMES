import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Gamepad2, User as UserIcon, Lock, Loader2, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useSEO } from '@/lib/useSEO';

const USERNAME_REGEX = /^[a-z0-9_]{3,20}$/;

export default function Auth() {
  useSEO({ title: 'ورود / ثبت‌نام', description: 'با نام کاربری وارد شو یا حساب جدید بساز' });
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { user, loading: authLoading, signInWithUsername, signUpWithUsername } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user && !authLoading) navigate('/profile');
  }, [user, authLoading, navigate]);

  const resetFields = () => {
    setError('');
    setPassword('');
    setConfirmPassword('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const normalizedUsername = username.trim().toLowerCase();

    if (!USERNAME_REGEX.test(normalizedUsername)) {
      setError('نام کاربری باید ۳ تا ۲۰ کاراکتر و فقط شامل حروف انگلیسی، عدد و آندرلاین باشد.');
      return;
    }
    if (password.length < 6) {
      setError('رمز عبور باید حداقل ۶ کاراکتر باشد.');
      return;
    }
    if (mode === 'signup' && password !== confirmPassword) {
      setError('رمز عبور و تکرار آن یکسان نیستند.');
      return;
    }

    setLoading(true);
    const { error: err } =
      mode === 'login'
        ? await signInWithUsername(normalizedUsername, password)
        : await signUpWithUsername(normalizedUsername, password);
    setLoading(false);

    if (err) {
      setError(err);
    } else {
      navigate('/profile');
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="text-center mb-8">
        <div className="inline-flex w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 items-center justify-center mb-4">
          <Gamepad2 className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-white">
          {mode === 'login' ? 'ورود به حساب' : 'ساخت حساب جدید'}
        </h1>
        <p className="text-slate-400 text-sm mt-2">با نام کاربری و رمز عبور، بدون نیاز به شماره یا ایمیل</p>
      </div>

      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/50">
        <div className="flex bg-slate-900 rounded-lg p-1 mb-6">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              resetFields();
            }}
            className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${
              mode === 'login' ? 'bg-cyan-500 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            ورود
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              resetFields();
            }}
            className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${
              mode === 'signup' ? 'bg-cyan-500 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            ثبت‌نام
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">نام کاربری</label>
            <div className="relative">
              <UserIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="مثال: gamer_123"
                dir="ltr"
                autoComplete="username"
                className="w-full pr-11 pl-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 text-left"
              />
            </div>
            {mode === 'signup' && (
              <p className="text-slate-500 text-xs mt-1.5">فقط حروف انگلیسی کوچک، عدد و آندرلاین، ۳ تا ۲۰ کاراکتر</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">رمز عبور</label>
            <div className="relative">
              <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                dir="ltr"
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                className="w-full pr-11 pl-11 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 text-left"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {mode === 'signup' && (
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">تکرار رمز عبور</label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  dir="ltr"
                  autoComplete="new-password"
                  className="w-full pr-11 pl-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 text-left"
                />
              </div>
            </div>
          )}

          {error && (
            <div className="bg-rose-500/10 border border-rose-500/30 rounded-lg p-3 text-rose-400 text-sm">
              {error}
            </div>
          )}

          {mode === 'signup' && (
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 text-amber-300 text-xs">
              چون از ایمیل یا شماره استفاده نمی‌شود، در صورت فراموشی رمز عبور امکان بازیابی خودکار وجود ندارد. نام کاربری و رمز عبورت را در جای امنی نگه دار.
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl transition-all disabled:opacity-50"
          >
            {loading && <Loader2 className="w-5 h-5 animate-spin" />}
            {mode === 'login' ? 'ورود' : 'ساخت حساب'}
          </button>
        </form>
      </div>

      <div className="text-center mt-6">
        <Link to="/" className="text-sm text-slate-500 hover:text-slate-400">بازگشت به خانه</Link>
      </div>
    </div>
  );
}
