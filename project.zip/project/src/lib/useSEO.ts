import { useEffect } from 'react';

interface SEOOptions {
  title: string;
  description?: string;
  image?: string;
}

export function useSEO({ title, description, image }: SEOOptions) {
  useEffect(() => {
    const fullTitle = title ? `${title} | Gaming Hub` : 'Gaming Hub - پلتفرم گیمرهای فارسی';
    document.title = fullTitle;

    const setMeta = (name: string, content: string) => {
      let el = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute('name', name);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    const setOg = (property: string, content: string) => {
      let el = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute('property', property);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    const desc = description || 'پلتفرم همه‌کاره گیمرهای فارسی‌زبان - ابزارهای کاربردی، معرفی بازی‌ها، مطالب گیمینگ';
    setMeta('description', desc);
    setOg('og:title', fullTitle);
    setOg('og:description', desc);
    setOg('og:type', 'website');
    if (image) {
      setOg('og:image', image);
    }

    return () => {
      document.title = 'Gaming Hub - پلتفرم گیمرهای فارسی';
    };
  }, [title, description, image]);
}
