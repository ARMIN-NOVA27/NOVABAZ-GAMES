export interface NameConfig {
  key: string;
  label: string;
  prefixes: string[];
  suffixes: string[];
  middles: string[];
}

const GAMING_WORDS = [
  'Shadow', 'Frost', 'Blaze', 'Storm', 'Venom', 'Phantom', 'Viper', 'Rogue',
  'Titan', 'Ninja', 'Ghost', 'Falcon', 'Wolf', 'Dragon', 'Reaper', 'Hunter',
  'Cyber', 'Neon', 'Dark', 'Iron', 'Steel', 'Thunder', 'Nova', 'Apex',
  'Sniper', 'Blade', 'Cobra', 'Raven', 'Demon', 'Knight', 'Saber', 'Echo',
];

const TEAM_WORDS = [
  'Squad', 'Force', 'Legion', 'Crew', 'Syndicate', 'Order', 'Brigade',
  'Alliance', 'Union', 'Collective', 'Division', 'Unit', 'Clan', 'Elite',
];

const CLAN_WORDS = [
  'Bloodline', 'Dynasty', 'Reign', 'Throne', 'Crown', 'Empire', 'House',
  'Vanguard', 'Sentinel', 'Warden', 'Guardian', 'Sovereign', 'Heritage',
];

const ROBLOX_WORDS = [
  'Builder', 'Creator', 'Master', 'Pro', 'Legend', 'Hero', 'Star', 'King',
  'Queen', 'Lord', 'Champ', 'Boss', 'Ace', 'Max', 'Ultra', 'Super',
];

const DISCORD_WORDS = [
  'Server', 'Lounge', 'Hub', 'Zone', 'Den', 'Base', 'HQ', 'Cave',
  'Nest', 'Realm', 'Domain', 'Sanctuary', 'Hideout', 'Outpost', 'Station',
];

function shuffle<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export const NAME_CONFIGS: NameConfig[] = [
  {
    key: 'gaming',
    label: 'اسم گیمینگ',
    prefixes: GAMING_WORDS,
    middles: ['X', 'Pro', 'HD', 'TV', 'Live', 'GG', 'Play'],
    suffixes: GAMING_WORDS,
  },
  {
    key: 'team',
    label: 'اسم تیم',
    prefixes: GAMING_WORDS,
    middles: [],
    suffixes: TEAM_WORDS,
  },
  {
    key: 'clan',
    label: 'اسم کلن',
    prefixes: GAMING_WORDS,
    middles: [],
    suffixes: CLAN_WORDS,
  },
  {
    key: 'roblox',
    label: 'اسم روبلاکس',
    prefixes: ROBLOX_WORDS,
    middles: ['Roblo', 'Blox', 'Block'],
    suffixes: GAMING_WORDS,
  },
  {
    key: 'discord',
    label: 'اسم دیسکورد',
    prefixes: GAMING_WORDS,
    middles: [],
    suffixes: DISCORD_WORDS,
  },
];

export function generateNames(configKey: string, count = 8): string[] {
  const config = NAME_CONFIGS.find((c) => c.key === configKey);
  if (!config) return [];

  const results: string[] = [];
  const used = new Set<string>();

  let attempts = 0;
  while (results.length < count && attempts < count * 10) {
    attempts++;
    const prefix = shuffle(config.prefixes)[0];
    const suffix = shuffle(config.suffixes)[0];
    const middle =
      config.middles.length > 0 && Math.random() > 0.5
        ? shuffle(config.middles)[0]
        : '';

    const name = [prefix, middle, suffix].filter(Boolean).join('');

    if (!used.has(name)) {
      used.add(name);
      results.push(name);
    }
  }

  return results;
}
