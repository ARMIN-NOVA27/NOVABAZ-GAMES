import type { ToolMeta } from './types';

export const TOOLS: ToolMeta[] = [
  {
    slug: 'idea-generator',
    title: 'ایده‌ساز گیمینگ',
    description: 'ایده‌های ویدئو، شورتس، استریم، چالش و کانال تولید کن',
    icon: 'Lightbulb',
    color: 'from-amber-500 to-orange-600',
  },
  {
    slug: 'name-generator',
    title: 'سازنده اسم گیمینگ',
    description: 'اسم گیمینگ، تیم، کلن، روبلاکس و دیسکورد بساز',
    icon: 'Type',
    color: 'from-cyan-500 to-blue-600',
  },
  {
    slug: 'bio-generator',
    title: 'سازنده بیو گیمینگ',
    description: 'با چند اطلاعات ساده، بیوهای جذاب گیمینگ بساز',
    icon: 'FileText',
    color: 'from-emerald-500 to-green-600',
  },
  {
    slug: 'system-check',
    title: 'بررسی سیستم و پیشنهاد بازی',
    description: 'سیستم خود را وارد کن و بازی‌های مناسب بگیر',
    icon: 'Cpu',
    color: 'from-rose-500 to-red-600',
  },
  {
    slug: 'dpi-calculator',
    title: 'محاسبه DPI / eDPI',
    description: 'محاسبه دقیق DPI و eDPI برای تنظیمات موس',
    icon: 'MousePointer2',
    color: 'from-violet-500 to-purple-600',
  },
  {
    slug: 'download-time',
    title: 'محاسبه زمان دانلود',
    description: 'زمان دانلود بازی‌ها را بر اساس سرعت اینترنت محاسبه کن',
    icon: 'Download',
    color: 'from-sky-500 to-indigo-600',
  },
  {
    slug: 'fps-converter',
    title: 'ابزار FPS',
    description: 'تبدیل فریم‌ریت و محاسبه زمان فریم',
    icon: 'Gauge',
    color: 'from-fuchsia-500 to-pink-600',
  },
  {
    slug: 'unit-converter',
    title: 'تبدیل واحدهای گیمینگ',
    description: 'تبدیل واحدهای مرتبط با بازی و سخت‌افزار',
    icon: 'ArrowLeftRight',
    color: 'from-teal-500 to-cyan-600',
  },
  {
    slug: 'thumbnail-maker',
    title: 'سازنده تصویر بندانگشتی',
    description: 'تصویر بندانگشتی و جذاب برای ویدئوهای گیمینگ بساز',
    icon: 'Image',
    color: 'from-orange-500 to-red-600',
  },
  {
    slug: 'game-recommender',
    title: 'پیشنهاد بازی',
    description: 'بر اساس سلیقه و سیستمت، بازی مناسب پیدا کن',
    icon: 'Sparkles',
    color: 'from-cyan-500 to-teal-600',
  },
];
