export interface BioInput {
  gamingName: string;
  favoriteGame: string;
  platform: string;
  playStyle: string;
}

const STYLES = [
  'حمله‌گر', 'دفاعی', 'تاکتیکی', 'اگرسیو', 'استراتژیک', 'سرگرم‌کننده',
];

const EMOJIS = ['🎮', '🕹️', '⚔️', '🏆', '🔥', '💀', '🎯', '🚀'];

export function generateBios(input: BioInput): string[] {
  const { gamingName, favoriteGame, platform, playStyle } = input;
  const emoji = EMOJIS[Math.floor(Math.random() * EMOJIS.length)];
  const style = playStyle || STYLES[Math.floor(Math.random() * STYLES.length)];

  return [
    `${emoji} ${gamingName} | ${platform} گیمر | بازی محبوب: ${favoriteGame} | سبک: ${style}`,
    `🎮 سلام، من ${gamingName} هستم! ${platform} بازی می‌کنم و ${favoriteGame} عاشقشم. بیا بازی کنیم! 🔥`,
    `🕹️ ${gamingName}\n🎯 پلتفرم: ${platform}\n⚔️ بازی محبوب: ${favoriteGame}\n🏆 سبک بازی: ${style}\n💪 همیشه آماده چالش`,
    `${emoji} ${gamingName} | ${favoriteGame} فن‌بوی | ${platform} پلیر | ${style} گیمر`,
    `💀 ${gamingName} اینجاست\n🎮 ${platform} | ${favoriteGame} | ${style}\n🏆 هدف: بهترین بودن`,
    `🚀 ${gamingName}\n🎮 ${platform} گیمینگ از قلب\n⚔️ ${favoriteGame} اسطوره‌ست\n🎯 سبک: ${style}\n🔥 بیا رقابت کنیم`,
  ];
}
