import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from './supabase';

const EMAIL_DOMAIN = 'gaminghub.internal';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  loading: boolean;
  isAdmin: boolean;
  signUpWithUsername: (username: string, password: string) => Promise<{ error: string | null }>;
  signInWithUsername: (username: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  const checkAdminRole = async (userId: string | undefined) => {
    if (!userId) {
      setIsAdmin(false);
      return;
    }
    const { data } = await supabase.rpc('is_admin');
    setIsAdmin(!!data);
  };

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data, error }) => {
      if (!mounted) return;
      if (error) {
        setSession(null);
        setLoading(false);
        return;
      }
      setSession(data.session);
      checkAdminRole(data.session?.user?.id).finally(() => {
        if (mounted) setLoading(false);
      });
    });

    const { data: listener } = supabase.auth.onAuthStateChange((event, sess) => {
      if (!mounted) return;
      setSession(sess);
      if (event === 'SIGNED_OUT') {
        setIsAdmin(false);
        return;
      }
      checkAdminRole(sess?.user?.id);
    });

    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  const signUpWithUsername = async (username: string, password: string) => {
    const normalized = username.trim().toLowerCase();
    const { data: available, error: checkError } = await supabase.rpc('check_username_available', {
      p_username: normalized,
    });
    if (checkError) return { error: checkError.message };
    if (!available) return { error: 'این نام کاربری قبلاً گرفته شده است.' };

    const syntheticEmail = `${normalized}@${EMAIL_DOMAIN}`;
    const { error } = await supabase.auth.signUp({
      email: syntheticEmail,
      password,
      options: { data: { username: normalized } },
    });
    return { error: error?.message ?? null };
  };

  const signInWithUsername = async (username: string, password: string) => {
    const normalized = username.trim().toLowerCase();
    const { data: email, error: lookupError } = await supabase.rpc('get_auth_email_for_username', {
      p_username: normalized,
    });
    if (lookupError) return { error: lookupError.message };
    if (!email) return { error: 'نام کاربری یا رمز عبور اشتباه است.' };

    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { error: 'نام کاربری یا رمز عبور اشتباه است.' };
    return { error: null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setIsAdmin(false);
  };

  return (
    <AuthContext.Provider
      value={{
        session,
        user: session?.user ?? null,
        loading,
        isAdmin,
        signUpWithUsername,
        signInWithUsername,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
