import { supabase } from './supabase';
import type { Game, Article, Review, Ad, Achievement, UserAchievement, Report, AdminStats, Notification, GameImage } from './types';

// ===================== GAMES =====================
// Columns needed by list views (Games list, recommender, system-check).
// Deliberately excludes long text fields (description, description_fa,
// rec_cpu/gpu/os) that only the game-detail page needs — keeps the
// payload small as the catalog grows into the hundreds of games.
const GAME_LIST_COLUMNS =
  'id, slug, title, title_fa, cover_url, genre, genres, platforms, release_date, developer, publisher, min_ram, min_storage, rating, rating_count, is_popular, is_new, created_at';

export async function fetchGames(): Promise<Game[]> {
  const { data, error } = await supabase.from('games').select(GAME_LIST_COLUMNS).order('created_at', { ascending: true });
  if (error) throw error;
  return (data ?? []) as unknown as Game[];
}

export async function fetchGameBySlug(slug: string): Promise<Game | null> {
  const { data, error } = await supabase.from('games').select('*').eq('slug', slug).maybeSingle();
  if (error) throw error;
  return data;
}

export async function fetchGameImages(gameId: string): Promise<GameImage[]> {
  const { data, error } = await supabase
    .from('game_images')
    .select('image_url, thumbnail_url')
    .eq('game_id', gameId)
    .order('sort_order', { ascending: true });
  if (error) throw error;
  return (data ?? []).map((row) => ({
    image_url: row.image_url,
    thumbnail_url: row.thumbnail_url || row.image_url,
  }));
}

export async function fetchSimilarGames(game: Game, limit = 4): Promise<Game[]> {
  const { data, error } = await supabase
    .from('games')
    .select(GAME_LIST_COLUMNS)
    .neq('id', game.id)
    .overlaps('genres', game.genres)
    .limit(limit);
  if (error) throw error;
  return (data ?? []) as unknown as Game[];
}

export async function recordGameView(gameId: string): Promise<void> {
  await supabase.from('game_views').insert({ game_id: gameId });
}

// ===================== ARTICLES =====================
export async function fetchArticles(): Promise<Article[]> {
  const { data, error } = await supabase.from('articles').select('*').order('published_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function fetchArticleBySlug(slug: string): Promise<Article | null> {
  const { data, error } = await supabase.from('articles').select('*').eq('slug', slug).maybeSingle();
  if (error) throw error;
  return data;
}

export async function fetchSimilarArticles(article: Article, limit = 3): Promise<Article[]> {
  const { data, error } = await supabase
    .from('articles')
    .select('*')
    .eq('category', article.category)
    .neq('id', article.id)
    .order('published_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data ?? [];
}

// ===================== REVIEWS =====================
export async function fetchReviewsByGame(gameId: string): Promise<Review[]> {
  const { data, error } = await supabase
    .from('reviews')
    .select('*, profiles:user_profiles(display_name)')
    .eq('game_id', gameId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function fetchUserReview(gameId: string, userId: string): Promise<Review | null> {
  const { data, error } = await supabase
    .from('reviews')
    .select('*')
    .eq('game_id', gameId)
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function submitReview(gameId: string, userId: string, rating: number, comment: string): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('reviews')
    .upsert({ game_id: gameId, user_id: userId, rating, comment }, { onConflict: 'user_id,game_id' });
  if (error) return { error: error.message };
  await supabase.rpc('award_achievement', { p_user_id: userId, p_achievement_slug: 'first_review' });
  return { error: null };
}

export async function deleteReview(reviewId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.from('reviews').delete().eq('id', reviewId);
  return { error: error?.message ?? null };
}

// ===================== FAVORITES =====================
export async function checkFavorite(userId: string, gameId: string): Promise<boolean> {
  const { data } = await supabase
    .from('user_favorites')
    .select('id')
    .eq('user_id', userId)
    .eq('game_id', gameId)
    .maybeSingle();
  return !!data;
}

export async function toggleFavorite(userId: string, gameId: string, currentlyFavorited: boolean): Promise<boolean> {
  if (currentlyFavorited) {
    await supabase.from('user_favorites').delete().eq('user_id', userId).eq('game_id', gameId);
    return false;
  } else {
    await supabase.from('user_favorites').insert({ user_id: userId, game_id: gameId });
    await supabase.rpc('award_achievement', { p_user_id: userId, p_achievement_slug: 'first_favorite' });
    return true;
  }
}

export async function fetchFavoriteGameIds(userId: string): Promise<string[]> {
  const { data } = await supabase.from('user_favorites').select('game_id').eq('user_id', userId);
  return (data || []).map((f) => f.game_id);
}

// ===================== WATCHLIST =====================
export async function checkWatchlist(userId: string, gameId: string): Promise<boolean> {
  const { data } = await supabase
    .from('user_watchlist')
    .select('id')
    .eq('user_id', userId)
    .eq('game_id', gameId)
    .maybeSingle();
  return !!data;
}

export async function toggleWatchlist(userId: string, gameId: string, currentlyWatchlisted: boolean): Promise<boolean> {
  if (currentlyWatchlisted) {
    await supabase.from('user_watchlist').delete().eq('user_id', userId).eq('game_id', gameId);
    return false;
  } else {
    await supabase.from('user_watchlist').insert({ user_id: userId, game_id: gameId });
    await supabase.rpc('award_achievement', { p_user_id: userId, p_achievement_slug: 'first_watchlist' });
    return true;
  }
}

export async function fetchWatchlistGameIds(userId: string): Promise<string[]> {
  const { data } = await supabase.from('user_watchlist').select('game_id').eq('user_id', userId);
  return (data || []).map((w) => w.game_id);
}

// ===================== NOTIFICATIONS =====================
export async function fetchNotifications(userId: string): Promise<Notification[]> {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(20);
  if (error) throw error;
  return data ?? [];
}

export async function markNotificationRead(notificationId: string): Promise<void> {
  await supabase.from('notifications').update({ is_read: true }).eq('id', notificationId);
}

export async function markAllNotificationsRead(userId: string): Promise<void> {
  await supabase.from('notifications').update({ is_read: true }).eq('user_id', userId).eq('is_read', false);
}

// ===================== ADS =====================
export async function fetchAds(placement: string): Promise<Ad[]> {
  const now = new Date().toISOString();
  const { data, error } = await supabase
    .from('ads')
    .select('*')
    .eq('placement', placement)
    .eq('is_active', true)
    .or(`start_date.is.null,start_date.lte.${now}`)
    .or(`end_date.is.null,end_date.gte.${now}`);
  if (error) throw error;
  return data ?? [];
}

export async function recordAdImpression(adId: string): Promise<void> {
  try { await supabase.rpc('increment_ad_impressions', { p_ad_id: adId }); } catch { /* ignore */ }
}

export async function recordAdClick(adId: string): Promise<void> {
  try { await supabase.rpc('increment_ad_clicks', { p_ad_id: adId }); } catch { /* ignore */ }
}

// ===================== ACHIEVEMENTS =====================
export async function fetchAllAchievements(): Promise<Achievement[]> {
  const { data, error } = await supabase.from('achievements').select('*');
  if (error) throw error;
  return data ?? [];
}

export async function fetchUserAchievements(userId: string): Promise<UserAchievement[]> {
  const { data, error } = await supabase
    .from('user_achievements')
    .select('*, achievements(*)')
    .eq('user_id', userId);
  if (error) throw error;
  return data ?? [];
}

// ===================== REPORTS =====================
export async function submitReport(
  reporterId: string,
  targetType: 'game' | 'article' | 'review',
  targetId: string,
  reason: string
): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('reports')
    .insert({ reporter_id: reporterId, target_type: targetType, target_id: targetId, reason });
  return { error: error?.message ?? null };
}

// ===================== ADMIN =====================
export async function fetchAdminStats(): Promise<AdminStats> {
  const { data, error } = await supabase.rpc('get_admin_stats');
  if (error) throw error;
  return data as AdminStats;
}

export async function fetchAllReviewsAdmin(): Promise<Review[]> {
  const { data, error } = await supabase
    .from('reviews')
    .select('*, profiles:user_profiles(display_name)')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function fetchAllReports(): Promise<Report[]> {
  const { data, error } = await supabase.from('reports').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function updateReportStatus(
  reportId: string,
  status: 'resolved' | 'dismissed',
  adminNote: string | null
): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('reports')
    .update({ status, admin_note: adminNote, resolved_at: new Date().toISOString() })
    .eq('id', reportId);
  return { error: error?.message ?? null };
}

export async function fetchAllAdsAdmin(): Promise<Ad[]> {
  const { data, error } = await supabase.from('ads').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function createAd(ad: Partial<Ad>): Promise<{ error: string | null }> {
  const { error } = await supabase.from('ads').insert(ad);
  return { error: error?.message ?? null };
}

export async function updateAd(adId: string, updates: Partial<Ad>): Promise<{ error: string | null }> {
  const { error } = await supabase.from('ads').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', adId);
  return { error: error?.message ?? null };
}

export async function deleteAd(adId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.from('ads').delete().eq('id', adId);
  return { error: error?.message ?? null };
}

export async function createGame(game: Partial<Game>): Promise<{ error: string | null }> {
  const { error } = await supabase.from('games').insert(game);
  return { error: error?.message ?? null };
}

export async function updateGame(gameId: string, updates: Partial<Game>): Promise<{ error: string | null }> {
  const { error } = await supabase.from('games').update(updates).eq('id', gameId);
  return { error: error?.message ?? null };
}

export async function deleteGame(gameId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.from('games').delete().eq('id', gameId);
  return { error: error?.message ?? null };
}

export async function createArticle(article: Partial<Article>): Promise<{ error: string | null }> {
  const { error } = await supabase.from('articles').insert(article);
  return { error: error?.message ?? null };
}

export async function updateArticle(articleId: string, updates: Partial<Article>): Promise<{ error: string | null }> {
  const { error } = await supabase.from('articles').update(updates).eq('id', articleId);
  return { error: error?.message ?? null };
}

export async function deleteArticle(articleId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.from('articles').delete().eq('id', articleId);
  return { error: error?.message ?? null };
}

export async function fetchUserRoles(): Promise<{ user_id: string; role: string }[]> {
  const { data, error } = await supabase.from('user_roles').select('user_id, role');
  if (error) throw error;
  return data ?? [];
}
