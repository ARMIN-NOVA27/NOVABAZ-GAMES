export interface Game {
  id: string;
  slug: string;
  title: string;
  title_fa: string | null;
  cover_url: string | null;
  genre: string;
  genres: string[];
  platforms: string[];
  description: string | null;
  description_fa: string | null;
  release_date: string | null;
  developer: string | null;
  publisher: string | null;
  min_cpu: string | null;
  min_gpu: string | null;
  min_ram: string | null;
  min_storage: string | null;
  min_os: string | null;
  rec_cpu: string | null;
  rec_gpu: string | null;
  rec_ram: string | null;
  rec_storage: string | null;
  rec_os: string | null;
  rating: number;
  rating_count: number;
  trailer_url?: string | null;
  steam_appid?: number | null;
  is_free?: boolean;
  android_package_name?: string | null;
  ios_app_id?: string | null;
  is_popular: boolean;
  is_new: boolean;
  created_at?: string;
}

export interface Article {
  id: string;
  slug: string;
  title: string;
  title_fa: string | null;
  excerpt: string | null;
  excerpt_fa: string | null;
  content: string | null;
  content_fa: string | null;
  category: string;
  cover_url: string | null;
  author: string | null;
  published_at: string;
  created_at?: string;
}

export interface UserProfile {
  id: string;
  user_id: string;
  username: string;
  display_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface ToolMeta {
  slug: string;
  title: string;
  description: string;
  icon: string;
  color: string;
}

export interface Review {
  id: string;
  user_id: string;
  game_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  updated_at: string;
  profiles?: { display_name: string | null } | null;
}

export interface Ad {
  id: string;
  title: string;
  image_url: string | null;
  link_url: string | null;
  placement: string;
  is_active: boolean;
  start_date: string;
  end_date: string | null;
  impressions: number;
  clicks: number;
  created_at?: string;
  updated_at?: string;
}

export interface Achievement {
  id: string;
  slug: string;
  title: string;
  description: string;
  icon: string;
}

export interface UserAchievement {
  id: string;
  user_id: string;
  achievement_id: string;
  created_at: string;
  achievements?: Achievement;
}

export interface Report {
  id: string;
  reporter_id: string | null;
  target_type: 'game' | 'article' | 'review';
  target_id: string;
  reason: string;
  status: 'pending' | 'resolved' | 'dismissed';
  admin_note: string | null;
  created_at: string;
  resolved_at: string | null;
}

export interface GameImage {
  image_url: string;
  thumbnail_url: string;
}

export interface Notification {
  id: string;
  user_id: string;
  type: 'achievement' | 'report_update';
  title: string;
  body: string | null;
  url: string | null;
  is_read: boolean;
  created_at: string;
}

export interface AdminStats {
  games: number;
  articles: number;
  users: number;
  reviews: number;
  favorites: number;
  watchlist: number;
  ads: number;
  active_ads: number;
  reports: number;
  pending_reports: number;
  achievements_earned: number;
}
